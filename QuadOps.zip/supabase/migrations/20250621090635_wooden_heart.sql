/*
  # Create company-assets storage bucket

  1. Storage Setup
    - Create `company-assets` bucket for storing company logos and assets
    - Configure bucket to be publicly accessible for reading
    - Set up RLS policies for secure uploads

  2. Security
    - Allow authenticated users to upload files
    - Allow public read access to files
    - Restrict file types to images only
*/

-- Create the company-assets bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'company-assets',
  'company-assets',
  true,
  5242880, -- 5MB limit
  ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml']
);

-- Allow authenticated users to upload files
CREATE POLICY "Authenticated users can upload company assets"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'company-assets');

-- Allow authenticated users to update their uploads
CREATE POLICY "Authenticated users can update company assets"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'company-assets');

-- Allow authenticated users to delete company assets
CREATE POLICY "Authenticated users can delete company assets"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'company-assets');

-- Allow public read access to company assets
CREATE POLICY "Public read access to company assets"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'company-assets');
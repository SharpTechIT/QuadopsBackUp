import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Upload, Save, AlertCircle } from 'lucide-react';
import { supabase } from '../../config/supabase';

interface CompanySettingsData {
  company_name: string;
  logo_url: string;
}

interface CompanySettingsProps {
  onSettingsUpdate?: () => void;
}

export const CompanySettings: React.FC<CompanySettingsProps> = ({ onSettingsUpdate }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [currentSettingsId, setCurrentSettingsId] = useState<string | null>(null);
  const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm<CompanySettingsData>();

  const logoUrl = watch('logo_url');

  useEffect(() => {
    fetchCompanySettings();
  }, []);

  const fetchCompanySettings = async () => {
    try {
      const { data, error } = await supabase
        .from('company_settings')
        .select('*')
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setCurrentSettingsId(data.id);
        setValue('company_name', data.company_name);
        setValue('logo_url', data.logo_url || '');
      }
    } catch (error) {
      console.error('Error fetching company settings:', error);
      setMessage({ type: 'error', text: 'Failed to load company settings' });
    }
  };

  const onSubmit = async (data: CompanySettingsData) => {
    setIsLoading(true);
    setMessage(null);

    try {
      if (currentSettingsId) {
        // Update existing settings
        const { error } = await supabase
          .from('company_settings')
          .update({
            ...data,
            updated_at: new Date().toISOString(),
          })
          .eq('id', currentSettingsId);

        if (error) throw error;
      } else {
        // Check if any settings exist first
        const { data: existingSettings, error: checkError } = await supabase
          .from('company_settings')
          .select('id')
          .limit(1);

        if (checkError) throw checkError;

        if (existingSettings && existingSettings.length > 0) {
          // Update the first existing record
          const { error } = await supabase
            .from('company_settings')
            .update({
              ...data,
              updated_at: new Date().toISOString(),
            })
            .eq('id', existingSettings[0].id);

          if (error) throw error;
          setCurrentSettingsId(existingSettings[0].id);
        } else {
          // Insert new settings only if none exist
          const { data: newSettings, error } = await supabase
            .from('company_settings')
            .insert([{
              ...data,
            }])
            .select()
            .single();

          if (error) throw error;
          setCurrentSettingsId(newSettings.id);
        }
      }

      setMessage({ type: 'success', text: 'Company settings updated successfully!' });
      
      // Update document title
      document.title = `${data.company_name} - Automation Workflow Platform`;
      
      // Notify parent component about the update
      if (onSettingsUpdate) {
        onSettingsUpdate();
      }

      // Dispatch custom event for global updates
      window.dispatchEvent(new CustomEvent('companySettingsUpdated', {
        detail: { companyName: data.company_name, logoUrl: data.logo_url }
      }));
    } catch (error) {
      console.error('Error updating company settings:', error);
      setMessage({ type: 'error', text: 'Failed to update company settings' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `logo-${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('company-assets')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('company-assets')
        .getPublicUrl(fileName);

      setValue('logo_url', publicUrl);
      setMessage({ type: 'success', text: 'Logo uploaded successfully!' });
    } catch (error) {
      console.error('Error uploading logo:', error);
      setMessage({ type: 'error', text: 'Failed to upload logo' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 shadow-sm rounded-lg border border-gray-200 dark:border-gray-700">
      <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white">Company Settings</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Manage your company branding and appearance
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
        {message && (
          <div className={`p-4 rounded-md ${
            message.type === 'success' 
              ? 'bg-green-50 dark:bg-green-900/50 text-green-700 dark:text-green-400' 
              : 'bg-red-50 dark:bg-red-900/50 text-red-700 dark:text-red-400'
          }`}>
            <div className="flex">
              <AlertCircle className="h-5 w-5 mr-2" />
              <span className="text-sm">{message.text}</span>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Company Name
            </label>
            <input
              {...register('company_name', { required: 'Company name is required' })}
              type="text"
              className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              placeholder="Enter company name"
            />
            {errors.company_name && (
              <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.company_name.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Logo URL
            </label>
            <div className="flex space-x-2">
              <input
                {...register('logo_url')}
                type="url"
                className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                placeholder="Enter logo URL or upload file"
              />
              <label className="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 cursor-pointer">
                <Upload className="h-4 w-4 mr-1" />
                Upload
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
              </label>
            </div>
            {logoUrl && (
              <div className="mt-2">
                <img src={logoUrl} alt="Company Logo" className="h-12 w-auto object-contain" />
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isLoading}
            className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
          >
            {isLoading ? (
              <div className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full"></div>
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            Save Settings
          </button>
        </div>
      </form>
    </div>
  );
};
import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Bot, 
  Settings, 
  Workflow,
  ChevronRight
} from 'lucide-react';
import { supabase } from '../../config/supabase';

import { BotMessageSquare } from 'lucide-react';

const navigation = [
  { name: 'Dashboard', to: '/', icon: LayoutDashboard },
    { name: 'BOTs', to: '/agents', icon: Bot },
    { name: 'Infra Architect', to: '/infra-architect', icon: BotMessageSquare },

  { name: 'Tools', to: '/tools', icon: Settings },
];

export const Sidebar: React.FC = () => {
  const [companyName, setCompanyName] = useState('SharpTech');
  const [logoUrl, setLogoUrl] = useState<string | null>(null);

  useEffect(() => {
    fetchCompanySettings();
    
    // Listen for company settings updates
    const handleSettingsUpdate = (event: any) => {
      if (event.detail) {
        setCompanyName(event.detail.companyName);
        setLogoUrl(event.detail.logoUrl);
        // Update document title
        document.title = `${event.detail.companyName} - Automation Workflow Platform`;
      } else {
        fetchCompanySettings();
      }
    };
    
    window.addEventListener('companySettingsUpdated', handleSettingsUpdate);
    
    return () => {
      window.removeEventListener('companySettingsUpdated', handleSettingsUpdate);
    };
  }, []);

  const fetchCompanySettings = async () => {
    try {
      const { data, error } = await supabase
        .from('company_settings')
        .select('company_name, logo_url')
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setCompanyName(data.company_name);
        setLogoUrl(data.logo_url);
        // Update document title
        document.title = `${data.company_name} - Automation Workflow Platform`;
      }
    } catch (error) {
      console.error('Error fetching company settings:', error);
      // Keep default name if fetch fails
    }
  };

  return (
    <div className="hidden md:flex md:w-40 md:flex-col">
      <div className="flex flex-col flex-grow pt-5 pb-4 overflow-y-auto bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700">
        <div className="flex items-center flex-shrink-0 px-4 mb-8 gap-x-4">
          {logoUrl ? (
            <img src={logoUrl} alt={companyName} className="w-30 h-20 object-contain" />
          ) : (
            <Workflow className="w-8 h-8 text-blue-600" />
          )}
        </div>
        <div className="mt-5 flex-1 flex flex-col">
          <nav className="flex-1 px-2 space-y-1">
            {navigation.map((item) => (
              <NavLink
                key={item.name}
                to={item.to}
                className={({ isActive }) =>
                  `group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
                    isActive
                      ? 'bg-blue-50 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 border-r-2 border-blue-700 dark:border-blue-400'
                      : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-gray-900 dark:hover:text-white'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    <item.icon
                      className={`mr-3 flex-shrink-0 h-5 w-5 ${
                        isActive ? 'text-blue-500 dark:text-blue-400' : 'text-gray-400 dark:text-gray-500 group-hover:text-gray-500 dark:group-hover:text-gray-400'
                      }`}
                    />
                    {item.name}
                    {isActive && (
                      <ChevronRight className="ml-auto h-4 w-4 text-blue-500 dark:text-blue-400" />
                    )}
                  </>
                )}
              </NavLink>
            ))}
          </nav>
        </div>
      </div>
    </div>
  );
};
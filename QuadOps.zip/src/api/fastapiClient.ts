/**
 * @typedef {object} FastApiRequestPayload
 * @property {string} short_description - A brief summary for the ServiceNow request.
 * @property {string} description - A detailed description for the ServiceNow request.
 * // Add other properties here if your FastAPI endpoint's ServiceRequestPayload
 * // in main.py accepts more fields (e.g., requested_for, priority).
 * // For example:
 * // @property {string} [requested_for] - The requested for user.
 */

/**
 * @typedef {object} FastApiResponse
 * @property {string} message - A success message from the FastAPI.
 * @property {object} servicenow_response - The raw response from ServiceNow.
 */

export const fastApiClient = {
  /**
   * Makes an authenticated POST request to your FastAPI endpoint to create a ServiceNow request.
   * @param {string} url - The full URL of your FastAPI endpoint (e.g., "http://52.147.203.234:8000/create-servicenow-request").
   * @param {string} username - The username for FastAPI's Basic Authentication.
   * @param {string} password - The password for FastAPI's Basic Authentication.
   * @param {FastApiRequestPayload} payload - The data to send to FastAPI for ServiceNow request creation.
   * @returns {Promise<FastApiResponse>} A promise that resolves with the FastAPI's response.
   * @throws {Error} Throws an error if the request fails or authentication is unsuccessful.
   */
  createServiceNowRequest: async (
    url: string,
    payload: { short_description: string; description: string; [key: string]: any } // Allow additional dynamic fields
  ): Promise<any> => {
    // Encode username and password for Basic Authentication
    //const authString = btoa(`CloudAutomationNinja:P@$sW0rd#312`); // btoa for browser-side Base64 encoding
    //const authorizationHeader = `Basic ${authString}`;

    try {
      console.log(`Calling FastAPI endpoint: ${url}`);
      console.log('Payload for FastAPI:', JSON.stringify(payload, null, 2));

      const response = await fetch('http://52.147.203.234:8000/create-servicenow-request', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
          //'Authorization': authorizationHeader,
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        let errorData;
        try {
          errorData = await response.json();
        } catch (jsonError) {
          errorData = { detail: await response.text() }; // Fallback if response is not JSON
        }

        const errorMessage = errorData.detail || `HTTP error! Status: ${response.status}`;
        throw new Error(`FastAPI request failed: ${errorMessage}`);
      }

      const responseData = await response.json();
      return responseData;
    } catch (error) {
      console.error('Error in fastapiClient.createServiceNowRequest:', error);
      throw error;
    }
  },

  triggerGitAction: async (
    url: string,
    payload: { automationData:string, [key: string]: any } // Allow additional dynamic fields
  ): Promise<any> => {
    // Encode username and password for Basic Authentication
    //const authString = btoa(`CloudAutomationNinja:P@$sW0rd#312`); // btoa for browser-side Base64 encoding
    //const authorizationHeader = `Basic ${authString}`;

    try {
      console.log(`Calling FastAPI endpoint: ${url}`);
      console.log('Payload for FastAPI:', JSON.stringify(payload, null, 2));

      const response = await fetch('http://52.147.203.234:8000/trigger-git-action', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        let errorData;
        try {
          errorData = await response.json();
        } catch (jsonError) {
          errorData = { detail: await response.text() }; // Fallback if response is not JSON
        }

        const errorMessage = errorData.detail || `HTTP error! Status: ${response.status}`;
        throw new Error(`FastAPI request failed: ${errorMessage}`);
      }

      const responseData = await response.json();
      return responseData;
    } catch (error) {
      console.error('Error in fastapiClient.triggerGitAction:', error);
      throw error;
    }
  },

  /**
   * Formats a given form data object into a human-readable string.
   * This is a utility function, useful for generating descriptions for the requests.
   *
   * @param {object} formData - The key-value pairs representing the submitted form data.
   * @returns {string} A formatted description string.
   */
  formatFormDataDescription: (formData: Record<string, any>): string => {
    if (!formData) return 'No form data provided.';
    let description = 'Automation Request Details:\n\n';
    for (const key in formData) {
      if (Object.prototype.hasOwnProperty.call(formData, key)) {
        description += `${key.replace(/_/g, ' ')}: ${formData[key]}\n`;
      }
    }
    return description;
  }
};

/*
  # Custom Authentication and Enhanced Tickets

  1. New Tables
    - `users` - Custom user authentication table
    - Enhanced `tickets` table with approval workflow

  2. Security
    - Enable RLS on new tables
    - Add policies for user access control

  3. Updates
    - Add new ticket statuses for approval workflow
    - Add automation_data field to tickets
*/

-- Custom users table for authentication
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL, -- In production, this should be hashed
  full_name TEXT NOT NULL,
  avatar_url TEXT,
  theme TEXT DEFAULT 'light' CHECK (theme IN ('light', 'dark')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Drop existing tickets table and recreate with enhanced fields
DROP TABLE IF EXISTS tickets CASCADE;
CREATE TABLE IF NOT EXISTS tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_number TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_approval' CHECK (status IN ('open', 'in_progress', 'resolved', 'closed', 'pending_approval', 'approved', 'rejected')),
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
  workflow_run_id UUID REFERENCES workflow_runs(id),
  user_id UUID REFERENCES users(id),
  automation_data JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE tickets ENABLE ROW LEVEL SECURITY;

-- Users policies
CREATE POLICY "Users can read their own data"
  ON users
  FOR SELECT
  TO public
  USING (true); -- Allow reading for authentication

CREATE POLICY "Users can update their own data"
  ON users
  FOR UPDATE
  TO public
  USING (true); -- Allow updates for profile management

CREATE POLICY "Anyone can create user accounts"
  ON users
  FOR INSERT
  TO public
  WITH CHECK (true); -- Allow user registration

-- Tickets policies
CREATE POLICY "Users can read all tickets"
  ON tickets
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can create tickets"
  ON tickets
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Users can update their own tickets"
  ON tickets
  FOR UPDATE
  TO public
  USING (user_id IN (SELECT id FROM users WHERE email = current_setting('request.jwt.claims', true)::json->>'email'));

-- Insert a default admin user
INSERT INTO users (email, password, full_name, theme) VALUES
('admin@autoflow.com', 'admin123', 'System Administrator', 'light')
ON CONFLICT (email) DO NOTHING;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status);
CREATE INDEX IF NOT EXISTS idx_tickets_user_id ON tickets(user_id);
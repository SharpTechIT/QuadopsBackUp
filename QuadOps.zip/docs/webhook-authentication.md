# Webhook Authentication Guide

This document explains how to authenticate with the AutoFlow webhook API to approve or reject tickets.

## Authentication Methods

### 1. API Key Authentication (Recommended)

Use the `X-API-Key` header to authenticate with a pre-generated API key.

```bash
curl -X POST http://localhost:3001/api/webhook/servicenow/approval \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ak_your_api_key_here" \
  -d '{
    "itsm_reference": "REQ0010001",
    "status": "approved",
    "comments": "Approved via webhook",
    "approved_by": "admin@company.com"
  }'
```

### 2. Bearer Token Authentication

Use the `Authorization` header with a Bearer token (user email for simplicity).

```bash
curl -X POST http://localhost:3001/api/webhook/servicenow/approval \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer admin@autoflow.com" \
  -d '{
    "itsm_reference": "REQ0010001",
    "status": "approved"
  }'
```

## API Key Management

### Creating API Keys

Only authenticated admin users can create API keys:

```bash
# Create a new API key
curl -X POST http://localhost:3001/api/webhook/api-keys \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ak_existing_admin_key" \
  -d '{
    "name": "ServiceNow Integration",
    "expires_in_days": 365
  }'
```

Response:
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "name": "ServiceNow Integration",
    "api_key": "ak_new_generated_key_here",
    "created_at": "2024-01-15T10:30:00Z",
    "expires_at": "2025-01-15T10:30:00Z",
    "is_active": true
  },
  "warning": "Store this API key securely. It will not be shown again."
}
```

### Listing API Keys

```bash
curl -X GET http://localhost:3001/api/webhook/api-keys \
  -H "X-API-Key: ak_your_admin_key"
```

## Permission Requirements

- Only users with `admin` role can approve/reject tickets via webhook
- API keys are tied to specific users and inherit their permissions
- All webhook requests are logged for audit purposes

## Default API Key

For testing purposes, a default API key is created for the admin user:
- **API Key:** `ak_test_admin_key_12345678901234567890123456789012`
- **User:** admin@autoflow.com
- **Note:** Change this in production!

## Security Best Practices

### For Production Deployment:

1. **Use HTTPS:** All webhook endpoints should use SSL/TLS
2. **Rotate API Keys:** Regularly rotate API keys and set expiration dates
3. **IP Whitelisting:** Restrict access to known ServiceNow/Jira IP addresses
4. **Monitor Usage:** Review audit logs regularly for suspicious activity
5. **Secure Storage:** Store API keys securely in your ITSM system
6. **Rate Limiting:** Implement rate limiting to prevent abuse

### ServiceNow Configuration

Update your ServiceNow Business Rule to include authentication:

```javascript
(function executeRule(current, previous) {
    if (current.approval.changesTo('approved') || current.approval.changesTo('rejected')) {
        
        var status = current.approval == 'approved' ? 'approved' : 'rejected';
        var payload = {
            itsm_reference: current.number.toString(),
            status: status,
            comments: current.comments || '',
            approved_by: current.sys_updated_by || ''
        };
        
        var request = new sn_ws.RESTMessageV2();
        request.setEndpoint('https://your-autoflow-domain.com:3001/api/webhook/servicenow/approval');
        request.setHttpMethod('POST');
        request.setRequestHeader('Content-Type', 'application/json');
        request.setRequestHeader('X-API-Key', 'ak_your_servicenow_api_key_here');
        request.setRequestBody(JSON.stringify(payload));
        
        var response = request.execute();
        gs.log('AutoFlow webhook response: ' + response.getBody(), 'AutoFlow Integration');
    }
})(current, previous);
```

### Jira Configuration

Update your Jira Automation Rule to include authentication:

**Web Request Configuration:**
- URL: `https://your-autoflow-domain.com:3001/api/webhook/jira/approval`
- HTTP Method: POST
- Headers: 
  - `Content-Type: application/json`
  - `X-API-Key: ak_your_jira_api_key_here`

## Error Responses

### 401 Unauthorized
```json
{
  "success": false,
  "error": "Authentication required. Provide Authorization header or X-API-Key header."
}
```

### 403 Forbidden
```json
{
  "success": false,
  "error": "Insufficient permissions. Only admin users can approve/reject tickets via webhook."
}
```

### 401 Invalid Credentials
```json
{
  "success": false,
  "error": "Invalid authentication credentials"
}
```

### 401 Expired API Key
```json
{
  "success": false,
  "error": "API key has expired"
}
```

## Audit Logging

All webhook requests are automatically logged with:
- Endpoint and HTTP method
- Authenticated user information
- Request payload
- IP address and user agent
- Timestamp

Audit logs can be reviewed for compliance and debugging purposes.

## Testing Authentication

### Test with Default API Key
```bash
curl -X POST http://localhost:3001/api/webhook/servicenow/approval \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ak_test_admin_key_12345678901234567890123456789012" \
  -d '{
    "itsm_reference": "REQ0010001",
    "status": "approved",
    "comments": "Test approval with authentication"
  }'
```

### Test with Bearer Token
```bash
curl -X POST http://localhost:3001/api/webhook/servicenow/approval \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer admin@autoflow.com" \
  -d '{
    "itsm_reference": "REQ0010001",
    "status": "approved"
  }'
```

### Test Invalid Authentication
```bash
curl -X POST http://localhost:3001/api/webhook/servicenow/approval \
  -H "Content-Type: application/json" \
  -d '{
    "itsm_reference": "REQ0010001",
    "status": "approved"
  }'
```

Expected response: 401 Unauthorized
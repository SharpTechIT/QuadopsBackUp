import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Settings, Workflow, Bot, AlertCircle, Database } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { CompanySettings } from '../components/admin/CompanySettings';
import { WorkflowConfiguration } from '../components/admin/WorkflowConfiguration';
import { AIAgentCreator } from '../components/admin/AIAgentCreator';
import { DataSourceManager } from '../components/admin/DataSourceManager';
import { supabase } from '../config/supabase';

type AdminTab = 'company' | 'workflows' | 'BOTs' | 'datasources';

interface AutomationTemplate {
    id: string;
    name: string;
    tower: string;
    automation_type: string;
    description?: string;
    is_active: boolean;
    created_at: string;
    updated_at: string;
}

export const Admin: React.FC = () => {
    const [activeTab, setActiveTab] = useState<AdminTab>('company');
    const [automationTemplates, setAutomationTemplates] = useState<AutomationTemplate[]>([]);
    const [refreshKey, setRefreshKey] = useState(0);
    const { isAdmin, isLoadingRole } = useAuth();
    const navigate = useNavigate();

    useEffect(() => {
        if (!isLoadingRole && !isAdmin) {
            navigate('/');
            return;
        }

        if (isAdmin) {
            fetchAutomationTemplates();
        }
    }, [isAdmin, isLoadingRole, navigate]);

    const fetchAutomationTemplates = async () => {
        try {
            const { data, error } = await supabase
                .from('automation_templates')
                .select('*')
                .order('tower', { ascending: true });

            if (error) throw error;
            setAutomationTemplates(data || []);
        } catch (error) {
            console.error('Error fetching automation templates:', error);
        }
    };

    const handleSettingsUpdate = () => {
        // Force a refresh of the entire app to update the sidebar
        setRefreshKey(prev => prev + 1);
        // You could also emit a custom event here if needed
        window.dispatchEvent(new CustomEvent('companySettingsUpdated'));
    };

    const handleDataSourceCreated = () => {
        // Refresh automation templates when data sources are updated
        fetchAutomationTemplates();
    };

    if (isLoadingRole) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
                <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    if (!isAdmin) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
                <div className="text-center">
                    <AlertCircle className="mx-auto h-12 w-12 text-red-500" />
                    <h2 className="mt-2 text-lg font-medium text-gray-900 dark:text-white">Access Denied</h2>
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                        You don't have permission to access the admin console.
                    </p>
                </div>
            </div>
        );
    }

    const tabs = [
        { id: 'company' as AdminTab, name: 'Company Settings', icon: Settings },
        { id: 'datasources' as AdminTab, name: 'Data Sources', icon: Database },
        { id: 'BOTs' as AdminTab, name: 'BOTs', icon: Bot },
        { id: 'workflows' as AdminTab, name: 'Workflow Configuration', icon: Workflow },
    ];

    return (
        <div className="space-y-6" key={refreshKey}>
            <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Console</h1>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    Manage company settings, data sources, BOTs, and workflows
                </p>
            </div>

            {/* Tab Navigation */}
            <div className="border-b border-gray-200 dark:border-gray-700">
                <nav className="-mb-px flex space-x-8">
                    {tabs.map((tab) => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`flex items-center py-2 px-1 border-b-2 font-medium text-sm ${activeTab === tab.id
                                    ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                                    : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                                }`}
                        >
                            <tab.icon className="h-5 w-5 mr-2" />
                            {tab.name}
                        </button>
                    ))}
                </nav>
            </div>

            {/* Tab Content */}
            <div className="mt-6">
                {activeTab === 'company' && <CompanySettings onSettingsUpdate={handleSettingsUpdate} />}

                {activeTab === 'datasources' && <DataSourceManager onDataSourceCreated={handleDataSourceCreated} />}

                {activeTab === 'BOTs' && (
                    <AIAgentCreator onAgentCreated={fetchAutomationTemplates} />
                )}

                {activeTab === 'workflows' && (
                    <WorkflowConfiguration automationTemplates={automationTemplates} />
                )}
            </div>
        </div>
    );
};
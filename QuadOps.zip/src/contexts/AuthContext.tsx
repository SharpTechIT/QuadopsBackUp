import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../config/supabase';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, fullName: string) => Promise<void>;
  signOut: () => Promise<void>;
  updateProfile: (data: { full_name?: string; avatar_url?: string }) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is already logged in
    checkUser();
  }, []);

  const checkUser = async () => {
    try {
      // Check if there's a stored user session
      const storedUser = localStorage.getItem('sharptech_user');
      if (storedUser) {
        const userData = JSON.parse(storedUser);
        
        // Verify user still exists in database
        const { data, error } = await supabase
          .from('users')
          .select('*')
          .eq('id', userData.id)
          .single();

        if (!error && data) {
          setUser(data);
        } else {
          localStorage.removeItem('sharptech_user');
        }
      }
    } catch (error) {
      console.error('Error checking user:', error);
      localStorage.removeItem('sharptech_user');
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      // Check if user exists and password matches
      const { data: users, error } = await supabase
        .from('users')
        .select('*')
        .eq('email', email)
        .eq('password', password);

      if (error) throw error;

      if (!users || users.length === 0) {
        throw new Error('Invalid email or password');
      }

      const user = users[0];
      
      // Store user session
      localStorage.setItem('sharptech_user', JSON.stringify(user));
      setUser(user);
    } catch (error) {
      throw error;
    }
  };

  const signUp = async (email: string, password: string, fullName: string) => {
    try {
      // Check if user already exists
      const { data: existingUsers, error: checkError } = await supabase
        .from('users')
        .select('email')
        .eq('email', email);

      if (checkError) throw checkError;

      if (existingUsers && existingUsers.length > 0) {
        throw new Error('User with this email already exists');
      }

      // Create new user
      const { data: newUser, error } = await supabase
        .from('users')
        .insert([{
          email,
          password, // In production, this should be hashed
          full_name: fullName,
          theme: 'light'
        }])
        .select()
        .single();

      if (error) throw error;

      // Store user session
      localStorage.setItem('sharptech_user', JSON.stringify(newUser));
      setUser(newUser);
    } catch (error) {
      throw error;
    }
  };

  const signOut = async () => {
    localStorage.removeItem('sharptech_user');
    setUser(null);
  };

  const updateProfile = async (data: { full_name?: string; avatar_url?: string }) => {
    if (!user) throw new Error('No user logged in');

    try {
      const { data: updatedUser, error } = await supabase
        .from('users')
        .update({
          ...data,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id)
        .select()
        .single();

      if (error) throw error;

      // Update stored user session
      localStorage.setItem('sharptech_user', JSON.stringify(updatedUser));
      setUser(updatedUser);
    } catch (error) {
      throw error;
    }
  };

  const value = {
    user,
    loading,
    signIn,
    signUp,
    signOut,
    updateProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
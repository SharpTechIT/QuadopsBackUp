import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { handleServiceNowWebhook, handleJiraWebhook, handleUpdateServiceNowWebhook } from './src/server/api/webhook.js';
import { fetchDataSourceOptions } from './src/server/api/dataSource.js';
import { fastApiClient } from './src/server/api/fastapiClient.js';

const { createClient } = await import('@supabase/supabase-js');
const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://riwtnauneyebqhhpfjya.supabase.co';
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJpd3RuYXVuZXllYnFoaHBmanlhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA0NDA1NzEsImV4cCI6MjA2NjAxNjU3MX0.xgyciQdfduR6SPBkUt1c6OapY_a8jHDIHzETRZW9U6E';

const supabase = createClient(supabaseUrl, supabaseKey);

// Get current directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(express.json());

// server.js
// ... existing code

// In-memory store for pending user responses
const pendingResponses = new Map();

// Endpoint for the agent to GET user responses (polling endpoint)
app.get('/api/agent/get-answer', async (req, res) => {
  const { sessionId } = req.query;

  if (!sessionId) {
    return res.status(400).json({ success: false, message: 'sessionId is required.' });
  }

  try {
    // Check if there's a pending response for this session
    const response = pendingResponses.get(sessionId);
    
    if (response) {
      return res.json({ success: true, answer: response });
    } else {
      return res.json({ success: true, answer: null });
    }

  } catch (error) {
    console.error('Error getting user answer:', error);
    res.status(500).json({ success: false, message: 'Failed to get user answer.' });
  }
});

// Endpoint for the webapp to POST user responses when user replies
app.post('/api/agent/user-response', async (req, res) => {
  const { sessionId, answer } = req.body;

  if (!sessionId || !answer) {
    return res.status(400).json({ success: false, message: 'sessionId and answer are required.' });
  }

  try {
    // Store the user's response in memory for the agent to poll
    pendingResponses.set(sessionId, answer);
    
    console.log(`User response stored for session ${sessionId}: ${answer}`);
    res.json({ success: true, message: 'User response stored successfully.' });

  } catch (error) {
    console.error('Error storing user response:', error);
    res.status(500).json({ success: false, message: 'Failed to store user response.' });
  }
});

// Endpoint to clear the user's answer after the agent has retrieved it
app.post('/api/agent/clear-user-answer', async (req, res) => {
  const { sessionId } = req.body;

  if (!sessionId) {
    return res.status(400).json({ success: false, message: 'sessionId is required.' });
  }

  try {
    // Remove the response from memory
    pendingResponses.delete(sessionId);
    
    console.log(`Cleared user response for session ${sessionId}`);
    res.json({ success: true, message: 'User response cleared successfully.' });

  } catch (error) {
    console.error('Error clearing user response:', error);
    res.status(500).json({ success: false, message: 'Failed to clear user response.' });
  }
});

// Optional: Endpoint to check if agent is waiting for user input
app.get('/api/agent/waiting-status/:sessionId', async (req, res) => {
  const { sessionId } = req.params;
  
  try {
    const isWaiting = pendingResponses.has(sessionId);
    res.json({ success: true, isWaitingForUser: !isWaiting });
  } catch (error) {
    console.error('Error checking waiting status:', error);
    res.status(500).json({ success: false, message: 'Failed to check waiting status.' });
  }
});

// Endpoint for the agent to post messages TO THE USER
app.post('/api/agent/message', async (req, res) => {
  const { sessionId, text, files } = req.body;

  if (!sessionId || !text) {
    return res.status(400).json({ success: false, message: 'sessionId and text are required.' });
  }

  try {
    // Insert the agent's message into the database.
    // This will trigger the realtime subscription on the client.
    const messageData = {
      session_id: sessionId,
      sender: 'agent', // The message is from the agent
      text: text,
    };

    // Add file information if provided
    if (files) {
      messageData.metadata = JSON.stringify({ files });
    }

    const { data, error } = await supabase
      .from('chat_messages')
      .insert(messageData);

    if (error) {
      throw error;
    }
    
    console.log('Message from agent received and stored:', data);
    res.json({ success: true, message: 'Message received and stored successfully.' });

  } catch (error) {
    console.error('Error storing agent message:', error);
    res.status(500).json({ success: false, message: 'Failed to store agent message.' });
  }
});

// NEW: Endpoint to get available files for a session
app.get('/api/files/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const filesDir = path.join(__dirname, 'generated_terraform_files', sessionId);
    
    if (!fs.existsSync(filesDir)) {
      return res.json({ success: true, files: [] });
    }

    const files = fs.readdirSync(filesDir).map(filename => ({
      filename,
      downloadUrl: `/api/download/${sessionId}/${filename}`,
      size: fs.statSync(path.join(filesDir, filename)).size
    }));

    res.json({ success: true, files });
  } catch (error) {
    console.error('Error listing files:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// NEW: Endpoint to download individual files
app.get('/api/download/:sessionId/:filename', async (req, res) => {
  try {
    const { sessionId, filename } = req.params;
    const filePath = path.join(__dirname, 'generated_terraform_files', sessionId, filename);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ success: false, message: 'File not found' });
    }

    // Validate filename to prevent directory traversal
    if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      return res.status(400).json({ success: false, message: 'Invalid filename' });
    }

    // Set appropriate headers
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'text/plain');

    // Stream the file
    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);

  } catch (error) {
    console.error('Error downloading file:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// NEW: Endpoint to download all files as a zip
app.get('/api/download-all/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const filesDir = path.join(__dirname, 'generated_terraform_files', sessionId);
    
    if (!fs.existsSync(filesDir)) {
      return res.status(404).json({ success: false, message: 'No files found for this session' });
    }

    const archiver = await import('archiver');
    const archive = archiver.default('zip', { zlib: { level: 9 } });

    res.setHeader('Content-Disposition', `attachment; filename="terraform-${sessionId}.zip"`);
    res.setHeader('Content-Type', 'application/zip');

    archive.pipe(res);

    // Add all files in the session directory to the zip
    const files = fs.readdirSync(filesDir);
    files.forEach(filename => {
      const filePath = path.join(filesDir, filename);
      archive.file(filePath, { name: filename });
    });

    await archive.finalize();

  } catch (error) {
    console.error('Error creating zip archive:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Endpoint to invoke the agent
app.post('/api/agent/invoke', async (req, res) => {
    try {
        const { user_query, sessionId } = req.body; 
        console.log(req.body)
        const result = await fastApiClient.triggerAgent(
            'http://52.147.203.234:8000/invoke-agent',
            { user_query, sessionId }
        );
        res.json(result);
    } catch (error) {
        console.error('Error invoking agent:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to invoke agent'
        });
    }
});

// Data source API endpoint with proper error handling
app.get('/api/data-sources/:id/options', async (req, res) => {
  try {
    const { id } = req.params;
    const filters = req.query;
    
    console.log(`Fetching options for data source ${id} with filters:`, filters);
    
    const options = await fetchDataSourceOptions(id, filters);
    
    // Ensure we always return a valid JSON response
    res.json({ 
      success: true, 
      data: Array.isArray(options) ? options : [] 
    });
  } catch (error) {
    console.error('Error fetching data source options:', error);
    
    // Always return valid JSON, even on error
    res.status(500).json({ 
      success: false, 
      error: error.message || 'Internal server error',
      data: [] // Provide empty array as fallback
    });
  }
});

// Git action trigger endpoint
app.post('/api/trigger-git-action', async (req, res) => {
    try {
        const { workflowID, automationData, servicenowData } = req.body;

        if (!automationData) {
            return res.status(400).json({
                success: false,
                error: 'Missing required field: automationData is required'
            });
        }

        console.log('req body data:', req.body);

        // Call FastAPI to trigger git action
        const payload = {
            workflowID,
            automationData,
            servicenowData
        };
        console.log('payload data:', payload);
        const result = await fastApiClient.triggerGitAction(
            'http://52.147.203.234:8000/trigger-git-action',
            req.body
        );

        res.json({
            success: true,
            message: 'Git action triggered successfully',
            data: result
        });

    } catch (error) {
        console.error('Error triggering git action:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to trigger git action'
        });
    }
});

// ServiceNow ticket create
app.post('/api/servicenow/create_service_request', async (req, res) => {
    console.log('ServiceNow webhook received:', req.body);
    try {
        const { short_description, description } = req.body;
        
        if (!short_description) {
            return res.status(400).json({
                success: false,
                error: 'Missing required field: short_description is required'
            });
        }

        console.log('short_description data:', short_description);

        // Call FastAPI to trigger git action
        const payload = {
            short_description,
            description
        };
        console.log('payload data:', payload);
        const result = await fastApiClient.createServiceRequest(
            'http://52.147.203.234:8000/create-servicenow-request',
            req.body
        );

        console.log("##################################################### \n ", result);
        res.json({
            success: true,
            message: 'snow action triggered successfully',
            data: result
        });
        return "result";

    } catch (error) {
        console.error('Error triggering git action:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to trigger git action'
        });
    }
});

// ServiceNow ticket update endpoint
app.post('/api/servicenow/update-ticket', async (req, res) => {
  try {
    const { sys_id, snow_data } = req.body;

    if (!sys_id || !snow_data) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: sys_id and snow_data are required'
      });
    }

    console.log('Updating ServiceNow ticket:', sys_id);
    console.log('Update data:', snow_data);

    // Call FastAPI to update ServiceNow ticket
    const result = await fastApiClient.updateServiceNowRequest("http://52.147.203.234:8000/update-servicenow-request",  req.body);

    res.json({
      success: true,
      message: 'ServiceNow ticket updated successfully',
      data: result
    });

  } catch (error) {
    console.error('Error updating ServiceNow ticket:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to update ServiceNow ticket'
    });
  }
});

// Webhook endpoints for ITSM systems to update ticket status
app.post('/api/webhook/servicenow/approval', async (req, res) => {
  console.log('ServiceNow webhook received:', req.body);
  await handleServiceNowWebhook(req, res);
});

app.post('/api/webhook/servicenow/close_ticket', async (req, res) => {
  console.log('ServiceNow webhook received:', req.body);
  await handleUpdateServiceNowWebhook(req, res);
});

app.post('/api/webhook/jira/approval', async (req, res) => {
  console.log('Jira webhook received:', req.body);
  await handleJiraWebhook(req, res);
});

// Generic webhook endpoint that can handle both ServiceNow and Jira
app.post('/api/webhook/itsm/approval', async (req, res) => {
  try {
    const { itsm_type, ...webhookData } = req.body;
    
    if (!itsm_type) {
      return res.status(400).json({
        success: false,
        error: 'Missing itsm_type field. Must specify "servicenow" or "jira"'
      });
    }

    console.log(`Generic ITSM webhook received for ${itsm_type}:`, webhookData);

    // Route to appropriate handler based on ITSM type
    if (itsm_type === 'servicenow') {
      req.body = webhookData; // Remove itsm_type from body
      await handleServiceNowWebhook(req, res);
    } else if (itsm_type === 'jira') {
      req.body = webhookData; // Remove itsm_type from body
      await handleJiraWebhook(req, res);
    } else {
      return res.status(400).json({
        success: false,
        error: 'Invalid itsm_type. Must be "servicenow" or "jira"'
      });
    }
  } catch (error) {
    console.error('Error in generic ITSM webhook:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Webhook health check
app.get('/api/webhook/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'Webhook endpoints are ready',
    endpoints: [
      'POST /api/webhook/servicenow/approval',
      'POST /api/webhook/jira/approval', 
      'POST /api/webhook/itsm/approval'
    ],
    timestamp: new Date().toISOString() 
  });
});

// Global error handler
app.use((error, req, res, next) => {
  console.error('Unhandled error:', error);
  res.status(500).json({
    success: false,
    error: 'Internal server error',
    data: []
  });
});

app.listen(PORT, () => {
  console.log(`API server running on http://localhost:${PORT}`);
  console.log('Available webhook endpoints:');
  console.log(`  - ServiceNow: POST http://localhost:${PORT}/api/webhook/servicenow/approval`);
  console.log(`  - Jira: POST http://localhost:${PORT}/api/webhook/jira/approval`);
  console.log(`  - Generic: POST http://localhost:${PORT}/api/webhook/itsm/approval`);
  console.log(`  - Data Sources: GET http://localhost:${PORT}/api/data-sources/:id/options`);
  console.log(`  - Download Files: GET http://localhost:${PORT}/api/download/:sessionId/:filename`);
  console.log(`  - Download All: GET http://localhost:${PORT}/api/download-all/:sessionId`);
});
import React, { useState } from 'react';
import ChatWindow from "../components/chat/ChatWindow"
import { ChatHistorySidebar } from '../components/chat/ChatHistorySidebar';

export const InfraArchitectAgent: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [refreshHistory, setRefreshHistory] = useState(false);

  const handleSessionSelect = (sessionId: string) => {
    setCurrentSessionId(sessionId);
  };
  
  const handleNewChat = () => {
    setCurrentSessionId(null);
  };
  
  const onNewSessionCreated = (newSessionId: string) => {
    setCurrentSessionId(newSessionId);
    setRefreshHistory(prev => !prev); // Toggle to trigger refresh in sidebar
  };

  return (
    <div className="flex h-[calc(100vh-4rem)] gap-4">
      <ChatWindow 
        sessionId={currentSessionId}
        onNewSession={onNewSessionCreated} 
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} 
      />
      <ChatHistorySidebar 
        isOpen={isSidebarOpen} 
        onClose={() => setIsSidebarOpen(false)} 
        onSelectSession={handleSessionSelect}
        onNewChat={handleNewChat}
        refreshTrigger={refreshHistory}
        activeSessionId={currentSessionId}
      />
    </div>
  );
};
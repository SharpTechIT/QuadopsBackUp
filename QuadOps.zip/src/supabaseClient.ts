import { createClient } from "@supabase/supabase-js";

// 🔑 Replace with your actual Supabase values (or load from .env)
const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://hkmzhtqtqhositdhvrlx.supabase.co';
const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhrbXpodHF0cWhvc2l0ZGh2cmx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc0Mjk5NTksImV4cCI6MjA3MzAwNTk1OX0.iUAhFEY1X0RaBodI-E4SCtk2KfnFSWNDE5Iowt_Fnv4';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Message type
export interface ChatMessage {
  id: string;
  session_id: string;
  sender: "user" | "agent";
  text: string;
  created_at: string;
}

// 📌 Fetch messages for a session
export async function getMessages(sessionId: string): Promise<ChatMessage[]> {
  const { data, error } = await supabase
    .from("chat_messages")
    .select("*")
    .eq("session_id", sessionId)
    .order("created_at", { ascending: true });

  if (error) {
    console.error("Error fetching messages:", error);
    return [];
  }

  return (data as ChatMessage[]) || [];
}

// 📌 Add a new message
export async function addMessage(
  sessionId: string,
  sender: "user" | "agent",
  text: string
): Promise<void> {
  const { error } = await supabase.from("chat_messages").insert([
    {
      session_id: sessionId,
      sender,
      text,
    },
  ]);

  if (error) {
    console.error("Error adding message:", error);
  }
}

// 📌 Subscribe to new messages in realtime
export function subscribeToMessages(
  sessionId: string,
  onMessage: (message: ChatMessage) => void
) {
  const channel = supabase
    .channel(`chat:${sessionId}`)
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "chat_messages",
        filter: `session_id=eq.${sessionId}`,
      },
      (payload) => {
        const newMessage = payload.new as ChatMessage;
        onMessage(newMessage);
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}

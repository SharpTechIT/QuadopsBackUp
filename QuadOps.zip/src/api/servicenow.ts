/**
 * Client-side ServiceNow API wrapper that communicates with our backend
 */

export interface ServiceNowConfig {
  instance_url: string;
  username: string;
  password: string;
}

export interface ServiceRequestData {
  short_description: string;
  description: string;
  requested_for: string;
  variables: any;
}

export const serviceNowClient = {
  /**
   * Tests ServiceNow connection via our backend API
   */
  testConnection: async (config: ServiceNowConfig): Promise<boolean> => {
    try {
      const response = await fetch('/api/servicenow/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(config),
      });

      const result = await response.json();
      return result.success || false;
    } catch (error) {
      console.error('Error testing ServiceNow connection:', error);
      return false;
    }
  },

  /**
   * Creates a service request via our backend API
   */
  createServiceRequest: async (config: ServiceNowConfig, requestData: ServiceRequestData): Promise<any> => {
    try {
      const response = await fetch('/api/servicenow/create-request', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          config,
          requestData,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();
      return result.data;
    } catch (error) {
      console.error('Error creating ServiceNow service request:', error);
      throw error;
    }
  },

  /**
   * Formats form data into a readable description
   */
  formatFormDataDescription: (formData: any): string => {
    if (!formData || typeof formData !== 'object') {
      return 'No form data provided.';
    }
    
    let description = 'Automation Request Details:\n\n';
    for (const [key, value] of Object.entries(formData)) {
      const formattedKey = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
      description += `${formattedKey}: ${value}\n`;
    }
    return description;
  },
};
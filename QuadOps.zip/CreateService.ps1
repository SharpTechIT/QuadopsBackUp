﻿# PowerShell script to install SharpTech backend as Windows Service
param(
    [Parameter(Mandatory=$false)]
    [string]$ServicePath = "C:\QuadOps\QuadOpsBackend"
)

Write-Host "Installing QuadOps Backend as Windows Service..." -ForegroundColor Green

# Check if running as administrator
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Error "This script must be run as Administrator!"
    exit 1
}

# Create service directory
Write-Host "Creating service directory..." -ForegroundColor Yellow
if (-not (Test-Path $ServicePath)) {
    New-Item -ItemType Directory -Path $ServicePath -Force
}

# Copy backend files
Write-Host "Copying backend files..." -ForegroundColor Yellow
Copy-Item -Path "server.js" -Destination $ServicePath -Force
Copy-Item -Path "src\server\*" -Destination "$ServicePath\src\server\" -Recurse -Force
Copy-Item -Path "package.json" -Destination $ServicePath -Force
Copy-Item -Path "backend-service.cjs" -Destination $ServicePath -Force
Copy-Item -Path "production.env" -Destination "$ServicePath\.env" -Force

# Install dependencies
Write-Host "Installing Node.js dependencies..." -ForegroundColor Yellow
Set-Location $ServicePath
npm install --production

# Install node-windows for service management
npm install node-windows

# Install the service
Write-Host "Installing Windows Service..." -ForegroundColor Yellow
node backend-service.cjs install

Write-Host "QuadOps Backend Service installed successfully!" -ForegroundColor Green
Write-Host "Service Name: QuadOps API Service" -ForegroundColor Cyan
Write-Host "Service will start automatically on system boot" -ForegroundColor Cyan
Write-Host ""
Write-Host "Service Management Commands:" -ForegroundColor Yellow
Write-Host "Start:   node backend-service.cjs start" -ForegroundColor White
Write-Host "Stop:    node backend-service.cjs stop" -ForegroundColor White
Write-Host "Remove:  node backend-service.cjs uninstall" -ForegroundColor White
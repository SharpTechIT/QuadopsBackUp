/*
  # Webhook Authentication Tables

  1. New Tables
    - `webhook_api_keys` - Store API keys for webhook authentication
    - `webhook_audit_logs` - Log all webhook requests for audit purposes

  2. Security
    - Enable RLS on new tables
    - Add policies for secure access

  3. Features
    - API key management for webhook authentication
    - Audit logging for compliance and debugging
*/

-- Webhook API keys table
CREATE TABLE IF NOT EXISTS webhook_api_keys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  api_key TEXT UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  last_used_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT true
);

-- Webhook audit logs table
CREATE TABLE IF NOT EXISTS webhook_audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  endpoint TEXT NOT NULL,
  method TEXT NOT NULL,
  user_id UUID REFERENCES users(id),
  user_email TEXT,
  auth_method TEXT,
  request_body JSONB,
  ip_address TEXT,
  user_agent TEXT,
  timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE webhook_api_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhook_audit_logs ENABLE ROW LEVEL SECURITY;

-- API keys policies
CREATE POLICY "Users can manage their own API keys"
  ON webhook_api_keys
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

-- Audit logs policies (read-only for users, admins can see all)
CREATE POLICY "Users can read audit logs"
  ON webhook_audit_logs
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "System can insert audit logs"
  ON webhook_audit_logs
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_webhook_api_keys_user_id ON webhook_api_keys(user_id);
CREATE INDEX IF NOT EXISTS idx_webhook_api_keys_api_key ON webhook_api_keys(api_key);
CREATE INDEX IF NOT EXISTS idx_webhook_api_keys_active ON webhook_api_keys(is_active);
CREATE INDEX IF NOT EXISTS idx_webhook_audit_logs_user_id ON webhook_audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_webhook_audit_logs_timestamp ON webhook_audit_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_webhook_audit_logs_endpoint ON webhook_audit_logs(endpoint);

-- Insert a default API key for the admin user for testing
INSERT INTO webhook_api_keys (user_id, name, api_key, is_active)
SELECT 
  u.id,
  'Default Admin API Key',
  'ak_test_admin_key_12345678901234567890123456789012',
  true
FROM users u
WHERE u.email = 'admin@autoflow.com'
ON CONFLICT (api_key) DO NOTHING;
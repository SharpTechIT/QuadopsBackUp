/**
 * Authentication middleware for webhook endpoints
 */

export async function authenticateWebhook(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    const apiKey = req.headers['x-api-key'];

    // Check for API key in header
    if (!authHeader && !apiKey) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required. Provide Authorization header or X-API-Key header.'
      });
    }

    let isAuthenticated = false;
    let userInfo = null;

    // Import Supabase client
    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://riwtnauneyebqhhpfjya.supabase.co';
    const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJpd3RuYXVuZXllYnFoaHBmanlhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA0NDA1NzEsImV4cCI6MjA2NjAxNjU3MX0.xgyciQdfduR6SPBkUt1c6OapY_a8jHDIHzETRZW9U6E';
    
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Method 1: API Key authentication
    if (apiKey) {
      // Check if API key exists in webhook_api_keys table
      const { data: apiKeyData, error: apiKeyError } = await supabase
        .from('webhook_api_keys')
        .select('*, users(*)')
        .eq('api_key', apiKey)
        .eq('is_active', true)
        .single();

      if (!apiKeyError && apiKeyData) {
        // Check if API key is expired
        if (apiKeyData.expires_at && new Date(apiKeyData.expires_at) < new Date()) {
          return res.status(401).json({
            success: false,
            error: 'API key has expired'
          });
        }

        isAuthenticated = true;
        userInfo = {
          id: apiKeyData.users.id,
          email: apiKeyData.users.email,
          full_name: apiKeyData.users.full_name,
          auth_method: 'api_key',
          api_key_name: apiKeyData.name
        };

        // Update last_used timestamp
        await supabase
          .from('webhook_api_keys')
          .update({ last_used_at: new Date().toISOString() })
          .eq('id', apiKeyData.id);
      }
    }

    // Method 2: Bearer token authentication (user session)
    if (!isAuthenticated && authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      
      // For simplicity, we'll treat the token as a user email for now
      // In production, you'd validate JWT tokens or session tokens
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('*')
        .eq('email', token)
        .single();

      if (!userError && userData) {
        isAuthenticated = true;
        userInfo = {
          id: userData.id,
          email: userData.email,
          full_name: userData.full_name,
          auth_method: 'bearer_token'
        };
      }
    }

    if (!isAuthenticated) {
      return res.status(401).json({
        success: false,
        error: 'Invalid authentication credentials'
      });
    }

    // Check if user has permission to approve tickets
    const { data: roleData, error: roleError } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', userInfo.id)
      .single();

    if (roleError || !roleData || roleData.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions. Only admin users can approve/reject tickets via webhook.'
      });
    }

    // Add user info to request for use in handlers
    req.authenticatedUser = userInfo;
    next();

  } catch (error) {
    console.error('Authentication error:', error);
    return res.status(500).json({
      success: false,
      error: 'Authentication service error'
    });
  }
}

/**
 * Middleware to log webhook requests for audit purposes
 */
export async function logWebhookRequest(req, res, next) {
  try {
    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://riwtnauneyebqhhpfjya.supabase.co';
    const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJpd3RuYXVuZXllYnFoaHBmanlhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA0NDA1NzEsImV4cCI6MjA2NjAxNjU3MX0.xgyciQdfduR6SPBkUt1c6OapY_a8jHDIHzETRZW9U6E';
    
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Log the webhook request
    const logData = {
      endpoint: req.path,
      method: req.method,
      user_id: req.authenticatedUser?.id,
      user_email: req.authenticatedUser?.email,
      auth_method: req.authenticatedUser?.auth_method,
      request_body: req.body,
      ip_address: req.ip || req.connection.remoteAddress,
      user_agent: req.headers['user-agent'],
      timestamp: new Date().toISOString()
    };

    await supabase
      .from('webhook_audit_logs')
      .insert([logData]);

    next();
  } catch (error) {
    console.error('Logging error:', error);
    // Don't fail the request if logging fails
    next();
  }
}
import sys
import locale

# Force UTF-8 globally
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')
import os

os.environ["PYTHONUTF8"] = "1"

from .tasks import create_terraform_generation_tasks, create_generic_question_tasks, \
    create_intent_classification_task
from .agents import user_interaction_agent, search_agent, cloud_architect_agent, terraform_code_generator_agent, \
    Quality_reviewer_agent, intent_classifier_agent
from .tools import clear_session_interaction_state  # ADD THIS IMPORT
from crewai import Crew, Process
import os
import shutil
import uvicorn

from dotenv import load_dotenv
from pydantic import BaseModel
from fastapi import FastAPI, HTTPException, Request, Depends, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.middleware.cors import CORSMiddleware
import logging
import re

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
load_dotenv()

app = FastAPI(
    title="Terraform architect agent Backend Service",
    description="This service triggers the full multi-agent terraform agent workflow.",
    version="1.0.0"
)
origins = [
    "http://localhost:5173",  # The origin of your React frontend
    # You can add other origins here if needed
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)


# # --- Basic Authentication Configuration for FastAPI itself ---
# security = HTTPBasic()
#
# FASTAPI_USERNAME = os.getenv("FASTAPI_USERNAME")
# FASTAPI_PASSWORD = os.getenv("FASTAPI_PASSWORD")
#
# if not FASTAPI_USERNAME or not FASTAPI_PASSWORD:
#     logger.error("FASTAPI_USERNAME and FASTAPI_PASSWORD must be set in the .env file for API authentication.")
#     raise ValueError("FASTAPI_USERNAME and FASTAPI_PASSWORD must be set in the .env file for API authentication.")
#
# def authenticate_fastapi_user(credentials: HTTPBasicCredentials = Depends(security)):
#     """
#     Dependency to authenticate users accessing this FastAPI application.
#     """
#     if not (credentials.username == FASTAPI_USERNAME and credentials.password == FASTAPI_PASSWORD):
#         logger.warning(f"Failed authentication attempt for user: {credentials.username}")
#         raise HTTPException(
#             status_code=status.HTTP_401_UNAUTHORIZED,
#             detail="Incorrect username or password for FastAPI",
#             headers={"WWW-Authenticate": "Basic"},
#         )
#     logger.info(f"User '{credentials.username}' authenticated successfully.")
#     return credentials.username

class UserRequestPayload(BaseModel):
    user_query: str
    sessionId: str


def check_terraform_code_required(result_text: str) -> bool:
    """
    Check if the generic question result indicates Terraform code generation is required.

    Args:
        result_text (str): The result text from the generic question task

    Returns:
        bool: True if Terraform code generation is required, False otherwise
    """
    # Look for the specific pattern in the result text
    terraform_match = re.search(r'\*\*TERRAFORM_CODE_REQUIRED:\s*(YES|NO)\*\*', str(result_text), re.IGNORECASE)

    if terraform_match:
        answer = terraform_match.group(1).upper()
        print(f"Found terraform requirement determination: {answer}")
        return answer == "YES"

    # Fallback: if the pattern is not found, assume no Terraform code is needed
    print("No terraform requirement determination found in result. Assuming NO.")
    return False


def run_workflow(user_query: str, sessionId: str):
    """
    Run the sequential workflow for IT issue resolution using the full multi-agent crew.
    """
    user_query = str(user_query).encode("utf-8", "ignore").decode("utf-8")
    print(f"Starting full workflow for: {user_query}")

    # CLEAR SESSION STATE AT THE BEGINNING OF EACH WORKFLOW
    clear_session_interaction_state(sessionId)
    print(f"Cleared interaction state for session: {sessionId}")

    intent_task = create_intent_classification_task(user_query, sessionId)
    intent_crew = Crew(
        agents=[intent_classifier_agent],
        tasks=[intent_task],
        process=Process.sequential,
        verbose=True
    )
    intent_result = intent_crew.kickoff()
    print(f"Intent classification result: {intent_result}")

    if "terraform_generation" in str(intent_result).lower():
        print("Intent is 'terraform_generation'. Starting Terraform generation workflow.")
        tasks = create_terraform_generation_tasks(user_query, sessionId)
        crew = Crew(
            agents=[user_interaction_agent, search_agent, cloud_architect_agent, terraform_code_generator_agent,
                    Quality_reviewer_agent],
            tasks=tasks,
            process=Process.sequential,
            verbose=True
        )

        # Execute the terraform generation workflow
        try:
            result = crew.kickoff()
            print("\n" + "=" * 50)
            print("TERRAFORM GENERATION WORKFLOW COMPLETED SUCCESSFULLY")
            print("=" * 50)
            print(f"Final Result: {result}")
            return result
        except Exception as e:
            print(f"Terraform generation workflow failed with error: {str(e)}")
            return None

    else:  # Default to generic question
        print("Intent is 'generic_question'. Starting generic question workflow.")
        tasks = create_generic_question_tasks(user_query, sessionId)
        crew = Crew(
            agents=[user_interaction_agent, search_agent],
            tasks=tasks,
            process=Process.sequential,
            verbose=True
        )

        # Execute the generic question workflow
        try:
            generic_result = crew.kickoff()
            print("\n" + "=" * 50)
            print("GENERIC QUESTION WORKFLOW COMPLETED")
            print("=" * 50)
            print(f"Generic Result: {generic_result}")

            # Check if Terraform code generation is required
            terraform_required = check_terraform_code_required(str(generic_result))

            if terraform_required:
                print("\n" + "=" * 50)
                print("TERRAFORM CODE GENERATION REQUIRED - STARTING TERRAFORM WORKFLOW")
                print("=" * 50)

                # Execute terraform generation workflow
                terraform_tasks = create_terraform_generation_tasks(user_query, sessionId)
                terraform_crew = Crew(
                    agents=[user_interaction_agent, search_agent, cloud_architect_agent,
                            terraform_code_generator_agent, Quality_reviewer_agent],
                    tasks=terraform_tasks,
                    process=Process.sequential,
                    verbose=True
                )

                try:
                    terraform_result = terraform_crew.kickoff()
                    print("\n" + "=" * 50)
                    print("TERRAFORM GENERATION WORKFLOW COMPLETED SUCCESSFULLY")
                    print("=" * 50)
                    print(f"Final Terraform Result: {terraform_result}")
                    return terraform_result
                except Exception as e:
                    print(f"Terraform generation workflow failed with error: {str(e)}")
                    return generic_result  # Return the generic result if terraform fails
            else:
                print("No Terraform code generation required. Workflow complete.")
                return generic_result

        except Exception as e:
            print(f"Generic question workflow failed with error: {str(e)}")
            return None


@app.post("/invoke-agent")
async def trigger_agent(
        request_payload: UserRequestPayload,
        http_request: Request,
):
    """
    This is the main endpoint that the Streamlit UI calls to start the agent workflow.
    """
    try:
        print(f"Received request to trigger agent for: {request_payload.user_query}")
        # The workflow runs in the background. The UI will interact via the webhook.
        run_workflow(request_payload.user_query, request_payload.sessionId)
        return {
            "message": "Successfully triggered AI agent workflow. The agent will ask questions in the chat if more information is needed."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


#
# from fastapi.responses import FileResponse
# from tools import GENERATED_FILES_DIR  # Import the constant
#
#
# # ... (keep existing app setup and other endpoints) ...
#
# @app.get("/download/{session_id}/{filename}")
# async def download_file(session_id: str, filename: str):
#     """
#     Endpoint to download a generated Terraform file.
#     """
#     file_path = os.path.join(GENERATED_FILES_DIR, session_id, filename)
#
#     # Security check: Ensure the path is within the intended directory
#     if not os.path.commonpath([os.path.abspath(file_path), os.path.abspath(GENERATED_FILES_DIR)]) == os.path.abspath(
#             GENERATED_FILES_DIR):
#         raise HTTPException(status_code=403, detail="Forbidden")
#
#     if os.path.exists(file_path):
#         return FileResponse(path=file_path, filename=filename, media_type='application/octet-stream')
#     else:
#         raise HTTPException(status_code=404, detail="File not found")

# Example usage for direct testing
if __name__ == "__main__":
    # This allows you to run the FastAPI server directly for testing purposes.
    # Use the command: uvicorn main:app --reload --port 8002
    print("Starting ITSM Agent Backend Service...")
    uvicorn.run(app, host="127.0.0.1", port=8002)
import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Eye, EyeOff, AlertTriangle } from 'lucide-react'; // Shield icon removed
import { Tool } from '../../types';
// Removed: import { maskToolConfig, getSensitiveFields } from '../../utils/toolEncryption';

interface ToolConfigFormProps {
    type: 'notification' | 'itsm' | 'version_control' | 'cloud_provider';
    provider: string;
    editingTool?: Tool | null;
    onSubmit: (data: any) => void;
    onBack: () => void;
    onClose: () => void;
}

export const ToolConfigForm: React.FC<ToolConfigFormProps> = ({
    type,
    provider,
    editingTool,
    onSubmit,
    onBack,
    onClose
}) => {
    const [showPassword, setShowPassword] = useState(false);
    const [authType, setAuthType] = useState('basic');
    // Removed: const [showEncryptionWarning, setShowEncryptionWarning] = useState(false);
    const { register, handleSubmit, setValue, reset, formState: { errors } } = useForm();

    // Removed: Get sensitive fields for this provider
    // Removed: const sensitiveFields = getSensitiveFields(provider);

    // Pre-populate form if editing
    useEffect(() => {
        console.log('ToolConfigForm - editingTool:', editingTool); // Debug log

        if (editingTool) {
            // Set the tool name
            setValue('name', editingTool.name);

            // Directly set config fields (no masking)
            const configToSet = editingTool.config;
            if (configToSet) {
                console.log('Setting config values directly:', configToSet); // Debug log

                Object.keys(configToSet).forEach(key => {
                    if (key !== 'auth_type') {
                        setValue(key, configToSet[key]);
                    }
                });

                // Set auth type if it exists
                if (configToSet.auth_type) {
                    setAuthType(configToSet.auth_type);
                }
            }

            // Removed: setShowEncryptionWarning(true);
        } else {
            // Reset form for new tool
            reset();
            setAuthType('basic');
            // Removed: setShowEncryptionWarning(false);
        }
    }, [editingTool, setValue, reset]);

    const providerNames: Record<string, string> = {
        slack: 'Slack',
        email: 'Email',
        servicenow: 'ServiceNow',
        jira: 'Jira',
        github: 'GitHub',
        azure_devops: 'Azure DevOps',
        azure: 'Microsoft Azure',
        aws: 'Amazon Web Services',
        gcp: 'Google Cloud Platform',
    };

    const getFormFields = () => {
        switch (provider) {
            case 'slack':
                return [
                    { name: 'name', label: 'Configuration Name', type: 'text', required: true },
                    { name: 'webhook_url', label: 'Webhook URL', type: 'url', required: true /* sensitive: true */ },
                    { name: 'channel', label: 'Default Channel', type: 'text', required: false },
                ];

            case 'email':
                return [
                    { name: 'name', label: 'Configuration Name', type: 'text', required: true },
                    { name: 'smtp_server', label: 'SMTP Server', type: 'text', required: true },
                    { name: 'smtp_port', label: 'SMTP Port', type: 'number', required: true },
                    { name: 'username', label: 'Username', type: 'email', required: true },
                    { name: 'password', label: 'Password', type: 'password', required: true /* sensitive: true */ },
                    { name: 'from_email', label: 'From Email', type: 'email', required: true },
                ];

            case 'servicenow':
                return [
                    { name: 'name', label: 'Configuration Name', type: 'text', required: true },
                    { name: 'instance_url', label: 'Instance URL', type: 'url', required: true },
                    ...(authType === 'basic' ? [
                        { name: 'username', label: 'Username', type: 'text', required: true },
                        { name: 'password', label: 'Password', type: 'password', required: true /* sensitive: true */ },
                    ] : [
                        { name: 'client_id', label: 'Client ID', type: 'text', required: true },
                        { name: 'client_secret', label: 'Client Secret', type: 'password', required: true /* sensitive: true */ },
                    ]),
                ];

            case 'jira':
                return [
                    { name: 'name', label: 'Configuration Name', type: 'text', required: true },
                    { name: 'base_url', label: 'Base URL', type: 'url', required: true },
                    { name: 'username', label: 'Username', type: 'email', required: true },
                    { name: 'api_token', label: 'API Token', type: 'password', required: true /* sensitive: true */ },
                    { name: 'project_key', label: 'Default Project Key', type: 'text', required: false },
                ];

            case 'github':
                return [
                    { name: 'name', label: 'Configuration Name', type: 'text', required: true },
                    { name: 'base_url', label: 'Base URL', type: 'url', required: false, placeholder: 'https://api.github.com (leave empty for GitHub.com)' },
                    { name: 'access_token', label: 'Personal Access Token', type: 'password', required: true /* sensitive: true */ },
                    { name: 'organization', label: 'Organization', type: 'text', required: false },
                ];

            case 'azure_devops':
                return [
                    { name: 'name', label: 'Configuration Name', type: 'text', required: true },
                    { name: 'organization', label: 'Organization', type: 'text', required: true },
                    { name: 'project', label: 'Project', type: 'text', required: true },
                    { name: 'personal_access_token', label: 'Personal Access Token', type: 'password', required: true /* sensitive: true */ },
                ];

            case 'azure':
                return [
                    { name: 'name', label: 'Configuration Name', type: 'text', required: true },
                    { name: 'tenant_id', label: 'Tenant ID', type: 'text', required: true },
                    { name: 'client_id', label: 'Client ID (Application ID)', type: 'text', required: true },
                    { name: 'client_secret', label: 'Client Secret', type: 'password', required: true /* sensitive: true */ },
                    { name: 'subscription_id', label: 'Subscription ID', type: 'text', required: true },
                ];

            case 'aws':
                return [
                    { name: 'name', label: 'Configuration Name', type: 'text', required: true },
                    { name: 'access_key_id', label: 'Access Key ID', type: 'text', required: true },
                    { name: 'secret_access_key', label: 'Secret Access Key', type: 'password', required: true /* sensitive: true */ },
                    { name: 'region', label: 'Default Region', type: 'text', required: true, placeholder: 'us-east-1' },
                ];

            case 'gcp':
                return [
                    { name: 'name', label: 'Configuration Name', type: 'text', required: true },
                    { name: 'project_id', label: 'Project ID', type: 'text', required: true },
                    { name: 'service_account_key', label: 'Service Account Key (JSON)', type: 'textarea', required: true /* sensitive: true */ },
                ];

            default:
                return [];
        }
    };

    const formFields = getFormFields();

    const handleFormSubmit = (data: any) => {
        console.log('Form submitted with data:', data); // Debug log

        const config = {
            ...data,
            auth_type: provider === 'servicenow' ? authType : undefined,
        };

        // Remove the name from config since it's a separate field
        const { name, ...configData } = config;

        onSubmit({
            type,
            provider: providerNames[provider],
            name: data.name,
            config: configData,
        });
    };

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-10 mx-auto p-5 border w-2/3 max-w-2xl shadow-lg rounded-md bg-white dark:bg-gray-800 max-h-[90vh] overflow-y-auto">
                <div className="mt-3">
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-6">
                        {editingTool ? 'Edit' : 'Configure'} {providerNames[provider]}
                    </h3>

                    {/* Removed: Encryption Notice */}

                    {/* Cloud Provider Notice */}
                    {type === 'cloud_provider' && (
                        <div className="mb-6 p-4 bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-md">
                            <div className="flex items-start">
                                <AlertTriangle className="h-5 w-5 text-orange-600 dark:text-orange-400 mt-0.5 mr-3" />
                                <div>
                                    <h4 className="text-sm font-medium text-orange-800 dark:text-orange-300">
                                        Cloud Provider Integration
                                    </h4>
                                    <p className="text-sm text-orange-700 dark:text-orange-400 mt-1">
                                        This configuration will be used to authenticate with {providerNames[provider]} APIs for dynamic data sources like resource groups, regions, and other cloud resources.
                                    </p>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Removed: Editing Warning */}

                    <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
                        {provider === 'servicenow' && (
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    Authentication Type
                                </label>
                                <div className="flex space-x-4">
                                    <label className="flex items-center">
                                        <input
                                            type="radio"
                                            value="basic"
                                            checked={authType === 'basic'}
                                            onChange={(e) => setAuthType(e.target.value)}
                                            className="mr-2"
                                        />
                                        <span className="text-sm text-gray-700 dark:text-gray-300">Basic Auth</span>
                                    </label>
                                    <label className="flex items-center">
                                        <input
                                            type="radio"
                                            value="oauth"
                                            checked={authType === 'oauth'}
                                            onChange={(e) => setAuthType(e.target.value)}
                                            className="mr-2"
                                        />
                                        <span className="text-sm text-gray-700 dark:text-gray-300">OAuth</span>
                                    </label>
                                </div>
                            </div>
                        )}

                        {formFields.map((field) => (
                            <div key={field.name}>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                    {field.label}
                                    {field.required && <span className="text-red-500 ml-1">*</span>}
                                    {/* Removed: Sensitive field tag */}
                                </label>

                                {field.type === 'password' ? (
                                    <div className="relative">
                                        <input
                                            {...register(field.name, {
                                                required: field.required && !editingTool // Don't require if editing and not a new field
                                            })}
                                            type={showPassword ? 'text' : 'password'}
                                            className="block w-full px-3 py-2 pr-10 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                            placeholder={editingTool ? 'Leave blank to keep existing value' : field.placeholder}
                                        />
                                        <button
                                            type="button"
                                            className="absolute inset-y-0 right-0 pr-3 flex items-center"
                                            onClick={() => setShowPassword(!showPassword)}
                                        >
                                            {showPassword ? (
                                                <EyeOff className="h-4 w-4 text-gray-400" />
                                            ) : (
                                                <Eye className="h-4 w-4 text-gray-400" />
                                            )}
                                        </button>
                                    </div>
                                ) : field.type === 'textarea' ? (
                                    <textarea
                                        {...register(field.name, { required: field.required })}
                                        rows={4}
                                        className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm font-mono"
                                        placeholder={field.placeholder}
                                    />
                                ) : (
                                    <input
                                        type={field.type}
                                        {...register(field.name, { required: field.required })}
                                        className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                        placeholder={field.placeholder}
                                    />
                                )}

                                {errors[field.name] && (
                                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                                        This field is required
                                    </p>
                                )}
                            </div>
                        ))}

                        <div className="flex justify-end space-x-2 pt-4">
                            <button
                                type="button"
                                onClick={onBack}
                                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                            >
                                Back
                            </button>
                            <button
                                type="button"
                                onClick={onClose}
                                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                            >
                                Cancel
                            </button>
                            <button
                                type="submit"
                                className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700"
                            >
                                {editingTool ? 'Update' : 'Save'} Configuration
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
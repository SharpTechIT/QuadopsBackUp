/**
 * Data Source API for fetching dynamic dropdown options
 */

// Add AWS SDK imports
import {
    EC2Client,
    DescribeRegionsCommand,
    DescribeVpcsCommand,
    DescribeSubnetsCommand,
    DescribeRouteTablesCommand,
    DescribeSecurityGroupsCommand,
    DescribeInternetGatewaysCommand
} from "@aws-sdk/client-ec2";


export async function fetchDataSourceOptions(dataSourceId, filters = {}) {
    try {
        // Import Supabase client
        const {
            createClient
        } = await import('@supabase/supabase-js');
        const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://riwtnauneyebqhhpfjya.supabase.co';
        const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJpd3RuYXVuZXllYnFoaHBmanlhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA0NDA1NzEsImV4cCI6MjA2NjAxNjU3MX0.xgyciQdfduR6SPBkUt1c6OapY_a8jHDIHzETRZW9U6E';

        const supabase = createClient(supabaseUrl, supabaseKey);

        console.log('Fetching data source options for ID:', dataSourceId);

        // Get data source configuration
        const {
            data: dataSource,
            error: dsError
        } = await supabase
            .from('data_sources')
            .select('*')
            .eq('id', dataSourceId)
            .eq('is_active', true)
            .single();

        if (dsError || !dataSource) {
            console.error('Data source not found:', dsError);
            throw new Error(`Data source not found: ${dataSourceId}`);
        }

        console.log('Found data source:', dataSource);

        // Check cache first
        const cacheKey = JSON.stringify({
            dataSourceId,
            filters
        });
        const {
            data: cachedData
        } = await supabase
            .from('data_source_cache')
            .select('cached_data')
            .eq('data_source_id', dataSourceId)
            .eq('cache_key', cacheKey)
            .gt('expires_at', new Date().toISOString())
            .single();

        if (cachedData) {
            console.log('Returning cached data for data source:', dataSourceId);
            return cachedData.cached_data;
        }

        let options = [];

        switch (dataSource.type) {
            case 'static':
                console.log('Processing static data source');
                options = dataSource.query_config?.data || [];
                break;

            case 'postgresql':
            case 'mysql':
            case 'sqlserver':
            case 'oracle':
            case 'sqlite':
                console.log('Processing database data source');
                options = await fetchDatabaseOptions(dataSource, filters);
                break;

            case 'api':
                console.log('Processing API data source');
                options = await fetchApiOptions(dataSource, filters);
                break;

            case 'azure_api':
                console.log('Processing Azure API data source');
                options = await fetchAzureApiOptions(dataSource, filters, supabase);
                break;

            case 'aws_api':
                console.log('Processing AWS API data source');
                options = await fetchAwsApiOptions(dataSource, filters, supabase);
                break;

            case 'gcp_api':
                console.log('Processing GCP API data source');
                options = await fetchGcpApiOptions(dataSource, filters, supabase);
                break;

            default:
                throw new Error(`Unsupported data source type: ${dataSource.type}`);
        }

        console.log('Generated options:', options);

        // Ensure options is always an array
        if (!Array.isArray(options)) {
            options = [];
        }

        // Cache the results
        const expiresAt = new Date(Date.now() + (dataSource.cache_duration || 300) * 1000).toISOString();
        try {
            await supabase
                .from('data_source_cache')
                .upsert({
                    data_source_id: dataSourceId,
                    cache_key: cacheKey,
                    cached_data: options,
                    expires_at: expiresAt
                });
        } catch (cacheError) {
            console.warn('Failed to cache results:', cacheError);
            // Don't fail the request if caching fails
        }

        return options;

    } catch (error) {
        console.error('Error fetching data source options:', error);
        throw error;
    }
}

async function fetchDatabaseOptions(dataSource, filters) {
    try {
        console.log('Fetching database options for:', dataSource.name);
        console.log('Query:', dataSource.query_config?.query);
        console.log('Filters:', filters);

        // Mock data based on the data source name
        if (dataSource.name.toLowerCase().includes('resource group')) {
            return [{
                value: 'rg-prod-001',
                label: 'Production Resource Group 001'
            }, {
                value: 'rg-dev-001',
                label: 'Development Resource Group 001'
            }, {
                value: 'rg-test-001',
                label: 'Testing Resource Group 001'
            }, {
                value: 'rg-staging-001',
                label: 'Staging Resource Group 001'
            },];
        }

        if (dataSource.name.toLowerCase().includes('location')) {
            return [{
                value: 'eastus',
                label: 'East US'
            }, {
                value: 'westus2',
                label: 'West US 2'
            }, {
                value: 'northeurope',
                label: 'North Europe'
            }, {
                value: 'westeurope',
                label: 'West Europe'
            },];
        }

        return [{
            value: 'option1',
            label: 'Database Option 1'
        }, {
            value: 'option2',
            label: 'Database Option 2'
        },];
    } catch (error) {
        console.error('Error in fetchDatabaseOptions:', error);
        return [];
    }
}

async function fetchApiOptions(dataSource, filters) {
    try {
        const baseUrl = dataSource.connection_config?.base_url;
        const endpoint = dataSource.query_config?.endpoint;
        const apiKey = dataSource.connection_config?.api_key;

        if (!baseUrl || !endpoint) {
            throw new Error('API data source missing base_url or endpoint');
        }

        const url = `${baseUrl}${endpoint}`;
        const headers = {
            'Content-Type': 'application/json',
        };

        if (apiKey) {
            headers['Authorization'] = `Bearer ${apiKey}`;
        }

        // Add filters as query parameters
        const queryParams = new URLSearchParams(filters);
        const fullUrl = queryParams.toString() ? `${url}?${queryParams}` : url;

        console.log('Making API request to:', fullUrl);

        const response = await fetch(fullUrl, {
            headers
        });

        if (!response.ok) {
            throw new Error(`API request failed: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();

        // Extract value and label fields based on configuration
        const valueField = dataSource.query_config?.value_field || 'value';
        const labelField = dataSource.query_config?.label_field || 'label';

        if (Array.isArray(data)) {
            return data.map(item => ({
                value: item[valueField],
                label: item[labelField]
            }));
        }

        // If data is wrapped in a property, try to extract it
        const dataArray = data.data || data.results || data.items;
        if (Array.isArray(dataArray)) {
            return dataArray.map(item => ({
                value: item[valueField],
                label: item[labelField]
            }));
        }

        throw new Error('API response is not in expected format');

    } catch (error) {
        console.error('Error fetching API options:', error);
        return [];
    }
}

async function fetchAzureApiOptions(dataSource, filters, supabase) {
    try {
        console.log('Fetching Azure API options for:', dataSource.name);

        // Get Azure cloud provider configuration
        const cloudProviderId = dataSource.connection_config?.cloud_provider_id;
        if (!cloudProviderId) {
            console.warn('Azure data source missing cloud_provider_id, returning mock data');
            return getMockAzureData(dataSource);
        }

        const {
            data: cloudProvider,
            error: cpError
        } = await supabase
            .from('tools')
            .select('*')
            .eq('id', cloudProviderId)
            .eq('type', 'cloud_provider')
            .single();

        if (cpError || !cloudProvider) {
            console.warn('Azure cloud provider configuration not found, returning mock data');
            return getMockAzureData(dataSource);
        }

        // Use the cloud provider config directly (assuming it's no longer encrypted)
        const config = cloudProvider.config;
        if (!config.tenant_id || !config.client_id || !config.client_secret || !config.subscription_id) {
            console.warn('Azure cloud provider missing required configuration, returning mock data');
            return getMockAzureData(dataSource);
        }

        // Get Azure access token
        const accessToken = await getAzureAccessToken(config);

        // Determine the API endpoint based on the resource type
        const resourceType = dataSource.query_config?.resource_type || 'resourceGroups';
        console.log('Fetching Azure API for:', resourceType);
        const subscriptionId = config.subscription_id;

        let apiUrl;
        switch (resourceType) {
            case 'resourceGroups':
                apiUrl = `https://management.azure.com/subscriptions/${subscriptionId}/resourcegroups?api-version=2021-04-01`;
                break;
            case 'locations':
                apiUrl = `https://management.azure.com/subscriptions/${subscriptionId}/locations?api-version=2021-04-01`;
                break;
            case 'vmSizes':
                apiUrl = `https://management.azure.com/subscriptions/b5798052-d6a8-41a4-830d-2a18f3ade0ec/resourceGroups/Infra/providers/Microsoft.Compute/virtualMachines/SharpTechVM/vmSizes?api-version=2024-11-01`;
                break;
            case 'subscriptions':
                apiUrl = `https://management.azure.com/subscriptions?api-version=2022-12-01`;
                break;
            case 'virtualMachines':
                const VMresourceGroup = filters.resourceGroup || '';
                if (VMresourceGroup) {
                    apiUrl = `https://management.azure.com/subscriptions/${subscriptionId}/resourceGroups/${VMresourceGroup}/providers/Microsoft.Compute/virtualMachines?api-version=2021-07-01`;
                } else {
                    apiUrl = `https://management.azure.com/subscriptions/${subscriptionId}/providers/Microsoft.Compute/virtualMachines?api-version=2021-07-01`;
                }
                break;
            default:
                console.warn(`Unsupported Azure resource type: ${resourceType}, returning mock data`);
                return getMockAzureData(dataSource);
        }

        console.log('Making Azure API request to:', apiUrl);

        const response = await fetch(apiUrl, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            }
        });
        console.log('response : ', response);
        if (!response.ok) {
            console.warn(`Azure API request failed: ${response.status} ${response.statusText}, returning mock data`);
            return getMockAzureData(dataSource);
        }

        const data = await response.json();
        console.log('response: ', data);

        // Transform Azure API response to our format
        if (data.value && Array.isArray(data.value)) {
            return data.value.map(item => {
                switch (resourceType) {
                    case 'resourceGroups':
                        return {
                            value: item.name,
                            label: `${item.name} (${item.location})`
                        };
                    case 'subscriptions':
                        return {
                            value: item.subscriptionId,
                            label: `${item.displayName} (${item.subscriptionId})`
                        };
                    case 'vmSizes':
                        return {
                            value: item.name,
                            label: `${item.name} (Cores: ${item.numberOfCores}, Memory(MB): ${item.memoryInMB})`
                        };
                    case 'locations':
                        return {
                            value: item.name,
                            label: item.displayName || item.name
                        };
                    case 'virtualMachines':
                        return {
                            value: item.name,
                            label: `${item.name} (${item.properties?.hardwareProfile?.vmSize || 'Unknown size'})`
                        };
                    default:
                        return {
                            value: item.name || item.id,
                            label: item.displayName || item.name || item.id
                        };
                }
            });
        }

        return getMockAzureData(dataSource);

    } catch (error) {
        console.error('Error fetching Azure API options:', error);
        return getMockAzureData(dataSource);
    }
}

function getMockAzureData(dataSource) {
    const resourceType = dataSource.query_config?.resource_type || 'resourceGroups';

    switch (resourceType) {
        case 'resourceGroups':
            return [{
                value: 'rg-production',
                label: 'rg-production (East US)'
            }, {
                value: 'rg-development',
                label: 'rg-development (West US 2)'
            }, {
                value: 'rg-testing',
                label: 'rg-testing (North Europe)'
            },];
        case 'locations':
            return [{
                value: 'eastus',
                label: 'East US'
            }, {
                value: 'westus2',
                label: 'West US 2'
            }, {
                value: 'northeurope',
                label: 'North Europe'
            }, {
                value: 'westeurope',
                label: 'West Europe'
            },];
        case 'virtualMachines':
            return [{
                value: 'vm-web-01',
                label: 'vm-web-01 (Standard_D2s_v3)'
            }, {
                value: 'vm-db-01',
                label: 'vm-db-01 (Standard_D4s_v3)'
            },];
        default:
            return [{
                value: 'azure-resource-1',
                label: 'Azure Resource 1'
            }, {
                value: 'azure-resource-2',
                label: 'Azure Resource 2'
            },];
    }
}

async function getAzureAccessToken(azureConfig) {
    try {
        const tokenUrl = `https://login.microsoftonline.com/${azureConfig.tenant_id}/oauth2/v2.0/token`;

        const params = new URLSearchParams();
        params.append('client_id', azureConfig.client_id);
        params.append('client_secret', azureConfig.client_secret);
        params.append('scope', 'https://management.azure.com/.default');
        params.append('grant_type', 'client_credentials');

        const response = await fetch(tokenUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: params
        });

        if (!response.ok) {
            throw new Error(`Azure token request failed: ${response.status} ${response.statusText}`);
        }

        const tokenData = await response.json();
        return tokenData.access_token;

    } catch (error) {
        console.error('Error getting Azure access token:', error);
        throw error;
    }
}

// ================================================================= //
// =================== NEW AWS INTEGRATION START =================== //
// ================================================================= //

async function fetchAwsApiOptions(dataSource, filters, supabase) {
    try {
        console.log('Fetching AWS API options for:', dataSource.name);

        const cloudProviderId = dataSource.connection_config?.cloud_provider_id;
        if (!cloudProviderId) {
            throw new Error('AWS data source missing cloud_provider_id');
        }

        const { data: cloudProvider, error: cpError } = await supabase
            .from('tools')
            .select('*')
            .eq('id', cloudProviderId)
            .eq('type', 'cloud_provider')
            .single();

        if (cpError || !cloudProvider) {
            throw new Error('AWS cloud provider configuration not found');
        }

        const config = cloudProvider.config;
        if (!config.access_key_id || !config.secret_access_key) {
            throw new Error('AWS provider credentials missing access key or secret key');
        }

        // Default region can be stored in config, or passed in filters for some calls
        const defaultRegion = config.aws_region || 'us-east-1';

        const credentials = {
            accessKeyId: config.access_key_id,
            secretAccessKey: config.secret_access_key,
        };

        const resourceType = dataSource.query_config?.resource_type;
        if (!resourceType) {
            throw new Error('AWS data source must have a resource_type in query_config');
        }

        // The EC2 client for listing regions does not require a region to be set.
        // For other commands, we'll initialize a new client if a specific region is needed.
        const globalEc2Client = new EC2Client({ credentials });

        switch (resourceType) {
            /**
             * To use:
             * query_config: { "resource_type": "aws_regions" }
             */
            case 'aws_regions':
                return await getAwsRegions(globalEc2Client);

            /**
             * To use:
             * query_config: { "resource_type": "aws_vpcs_by_region" }
             * This resource type depends on a filter for the region.
             * Example filter: { "region": "us-east-1" }
             */
            case 'aws_vpcs_by_region':
                const region = filters?.region;
                if (!region) {
                    throw new Error('Filter { "region": "..." } is required for resource type aws_vpcs_by_region');
                }
                const regionalEc2Client = new EC2Client({ credentials, region });
                return await getVpcsByRegion(regionalEc2Client);

            /**
            * To use:
            * query_config: { "resource_type": "aws_vpc_details" }
            * This resource type depends on filters for region and vpcId.
            * Example filter: { "region": "us-east-1", "vpcId": "vpc-..." }
            */
            case 'aws_vpc_details':
                const detailRegion = filters?.region;
                const vpcId = filters?.vpcId;
                if (!detailRegion || !vpcId) {
                    throw new Error('Filters { "region": "...", "vpcId": "..." } are required for aws_vpc_details');
                }
                const detailEc2Client = new EC2Client({ credentials, region: detailRegion });
                // This function logs details but may not be suitable for a dropdown.
                // Returning an empty array for dropdown purposes.
                await getVpcDetails(detailEc2Client, vpcId);
                return [];


            default:
                console.warn(`Unsupported AWS resource type: ${resourceType}`);
                return [];
        }

    } catch (error) {
        console.error('Error in fetchAwsApiOptions:', error);
        return [];
    }
}


/**
 * Converts getRegions.js
 * Fetches all available AWS regions.
 */
async function getAwsRegions(ec2Client) {
    console.log("Fetching all available AWS regions...");
    try {
        const command = new DescribeRegionsCommand({});
        const response = await ec2Client.send(command);
        const regions = response.Regions || [];

        return regions.map(region => ({
            value: region.RegionName,
            label: region.RegionName
        }));

    } catch (err) {
        console.error("Failed to fetch AWS regions:", err);
        throw err;
    }
}


/**
 * Converts getVpcsByRegion.js
 * Fetches all VPCs in a specific AWS region.
 */
async function getVpcsByRegion(ec2Client) {
    const clientRegion = await ec2Client.config.region();
    console.log(`Searching for VPCs in region: ${clientRegion}...`);
    try {
        const command = new DescribeVpcsCommand({});
        const response = await ec2Client.send(command);
        const vpcs = response.Vpcs || [];

        return vpcs.map(vpc => ({
            value: vpc.VpcId,
            label: `${vpc.VpcId} (${vpc.CidrBlock}) ${vpc.IsDefault ? ' - Default' : ''}`
        }));

    } catch (err) {
        console.error(`Failed to fetch VPCs for region ${clientRegion}:`, err);
        throw err;
    }
}

/**
 * Converts getVpcDetails.js
 * Fetches and logs details for a specific VPC.
 */
async function getVpcDetails(ec2Client, vpcId) {
    const region = await ec2Client.config.region();
    console.log(`Fetching details for VPC "${vpcId}" in region "${region}"...`);
    const vpcFilter = [{ Name: "vpc-id", Values: [vpcId] }];

    try {
        // --- Fetch Subnets ---
        const subnetsResponse = await ec2Client.send(new DescribeSubnetsCommand({ Filters: vpcFilter }));
        console.log("Subnets:", subnetsResponse.Subnets || []);

        // --- Fetch Route Tables ---
        const routeTablesResponse = await ec2Client.send(new DescribeRouteTablesCommand({ Filters: vpcFilter }));
        console.log("Route Tables:", routeTablesResponse.RouteTables || []);

        // --- Fetch Security Groups ---
        const sgResponse = await ec2Client.send(new DescribeSecurityGroupsCommand({ Filters: vpcFilter }));
        console.log("Security Groups:", sgResponse.SecurityGroups || []);

        // --- Fetch Internet Gateways ---
        const igwFilter = [{ Name: "attachment.vpc-id", Values: [vpcId] }];
        const igwResponse = await ec2Client.send(new DescribeInternetGatewaysCommand({ Filters: igwFilter }));
        console.log("Internet Gateways:", igwResponse.InternetGateways || []);

    } catch (err) {
        console.error("An error occurred while fetching VPC details:", err);
        throw err;
    }
}


// =============================================================== //
// =================== NEW AWS INTEGRATION END =================== //
// =============================================================== //


async function fetchGcpApiOptions(dataSource, filters, supabase) {
    try {
        console.log('GCP API integration not yet implemented, returning mock data');
        return [{
            value: 'us-central1',
            label: 'us-central1 (Iowa)'
        }, {
            value: 'us-east1',
            label: 'us-east1 (South Carolina)'
        }, {
            value: 'europe-west1',
            label: 'europe-west1 (Belgium)'
        },];
    } catch (error) {
        console.error('Error in fetchGcpApiOptions:', error);
        return [];
    }
}
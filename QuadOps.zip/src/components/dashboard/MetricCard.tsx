import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface MetricCardProps {
    title: string;
    value: number;
    icon: typeof LucideIcon;
    color: 'blue' | 'green' | 'red' | 'yellow' | 'purple';
    onClick?: () => void;
    trend?: {
        value: number;
        label: string;
    };
}

const colorClasses = {
    blue: 'bg-blue-500 text-blue-100',
    green: 'bg-green-500 text-green-100',
    red: 'bg-red-500 text-red-100',
    yellow: 'bg-yellow-500 text-yellow-100',
    purple: 'bg-purple-500 text-purple-100',
};

export const MetricCard: React.FC<MetricCardProps> = ({
    title,
    value,
    icon: Icon,
    color,
    onClick,
    trend,
}) => {
    return (
        <div
            className={`bg-white dark:bg-gray-800 overflow-hidden shadow-sm rounded-lg border border-gray-200 dark:border-gray-700 transition-all duration-200 ${onClick ? 'cursor-pointer hover:shadow-md hover:scale-105' : ''
                }`}
            onClick={onClick}
        >
            <div className="p-6">
                <div className="flex items-center">
                    <div className="flex-shrink-0">
                        <div className={`p-3 rounded-md ${colorClasses[color]}`}>
                            <Icon className="h-6 w-6" />
                        </div>
                    </div>
                    <div className="ml-5 w-0 flex-1">
                        <dl>
                            <dt className="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">{title}</dt>
                            <dd className="flex items-baseline">
                                <div className="text-2xl font-semibold text-gray-900 dark:text-white">{value.toLocaleString()}</div>
                                {trend && (
                                    <div className={`ml-2 flex items-baseline text-sm font-semibold ${trend.value >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                                        }`}>
                                        {trend.value >= 0 ? '+' : ''}{trend.value}%
                                        <span className="ml-1 text-gray-500 dark:text-gray-400 font-normal">{trend.label}</span>
                                    </div>
                                )}
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>
    );
};
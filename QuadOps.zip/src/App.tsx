import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { AuthWrapper } from './components/auth/AuthWrapper';
import { Layout } from './components/layout/Layout';
import { Dashboard } from './pages/Dashboard';
import { AIAgents } from './pages/AIAgents';
import { TowerAutomations } from './pages/TowerAutomations';
import { AutomationForm } from './pages/AutomationForm';
import { Tools } from './pages/Tools';
import { WorkflowRuns } from './pages/WorkflowRuns';
import { Tickets } from './pages/Tickets';
import { Admin } from './pages/Admin';
import { useAuth } from './hooks/useAuth';
import { supabase } from './config/supabase';
import { InfraArchitectAgent } from './pages/InfraArchitectAgent';

const AppContent: React.FC = () => {
    const { user, loading } = useAuth();

    useEffect(() => {
        // Fetch and set initial company settings for document title
        const fetchInitialSettings = async () => {
            try {
                const { data, error } = await supabase
                    .from('company_settings')
                    .select('company_name')
                    .limit(1)
                    .single();

                if (data && !error) {
                    document.title = `${data.company_name} - Automation Workflow Platform`;
                }
            } catch (error) {
                console.error('Error fetching initial company settings:', error);
            }
        };

        fetchInitialSettings();
    }, []);

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
                <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    if (!user) {
        return <AuthWrapper />;
    }

    return (
        <Router>
            <Routes>
                <Route path="/" element={<Layout />}>
                    <Route index element={<Dashboard />} />
                    <Route path="agents" element={<AIAgents />} />
                    <Route path="agents/:towerId" element={<TowerAutomations />} />
                    <Route path="agents/:towerId/:automationId" element={<AutomationForm />} />
                    <Route path="tools" element={<Tools />} />
                    <Route path="workflows" element={<WorkflowRuns />} />
                    <Route path="tickets" element={<Tickets />} />
                    <Route path="admin" element={<Admin />} />
                    <Route path="infra-architect" element={<InfraArchitectAgent />} />
                </Route>
            </Routes>
        </Router>
    );
};

function App() {
    return (
        <ThemeProvider>
            <AuthProvider>
                <AppContent />
            </AuthProvider>
        </ThemeProvider>
    );
}

export default App;
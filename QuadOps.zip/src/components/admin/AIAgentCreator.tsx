import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { Plus, Trash2, Save, X, Edit, Database, Settings, GripVertical, Search } from 'lucide-react';
import { supabase } from '../../config/supabase';

interface FormField {
    name: string;
    label: string;
    type: 'text' | 'email' | 'number' | 'select' | 'textarea' | 'password';
    required: boolean;
    options?: string[];
    data_source_id?: string;
    hidden_on_load?: boolean;
    conditional_display?: {
        depends_on_field: string;
        condition_type: 'equals' | 'not_equals' | 'contains' | 'regex';
        condition_value: string;
        regex_pattern?: string;
    };
}

interface AIAgentData {
    tower: string;
    automation_type: string;
    name: string;
    description: string;
    icon_name: string;
    form_schema: {
        fields: FormField[];
    };
}

interface DataSource {
    id: string;
    name: string;
    type: string;
    is_active: boolean;
}

interface AIAgentCreatorProps {
    onAgentCreated: () => void;
}

const availableIcons = [
    'UserPlus', 'UserMinus', 'UserCheck', 'Users', 'MailPlus', 'MailMinus',
    'Settings', 'Server', 'Trash2', 'Database', 'Shield', 'HardDrive',
    'Globe', 'Cloud', 'Terminal', 'Monitor', 'Network', 'Activity'
];

const towers = [
    'active-directory', 'exchange', 'windows', 'linux', 'database',
    'network', 'azure', 'o365', 'aws', 'gcp'
];

const conditionTypes = [
    { value: 'equals', label: 'Equals' },
    { value: 'not_equals', label: 'Not Equals' },
    { value: 'contains', label: 'Contains' },
    { value: 'regex', label: 'Regex Pattern' },
];

export const AIAgentCreator: React.FC<AIAgentCreatorProps> = ({ onAgentCreated }) => {
    const [agents, setAgents] = useState<any[]>([]);
    const [dataSources, setDataSources] = useState<DataSource[]>([]);
    const [showForm, setShowForm] = useState(false);
    const [editingAgent, setEditingAgent] = useState<any>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [expandedFields, setExpandedFields] = useState<Set<number>>(new Set());
    const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
    const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);

    // Filter and Search States
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedTower, setSelectedTower] = useState('');
    const [selectedStatus, setSelectedStatus] = useState('');

    const formRef = useRef<HTMLDivElement>(null);

    const { register, control, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<AIAgentData>({
        defaultValues: {
            form_schema: {
                fields: [{ name: '', label: '', type: 'text', required: true, hidden_on_load: false }]
            }
        }
    });

    const { fields, append, remove, move } = useFieldArray({
        control,
        name: 'form_schema.fields'
    });

    // Filter and search logic
    const filteredAgents = useMemo(() => {
        return agents.filter(agent => {
            const matchesSearch = searchTerm === '' ||
                agent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                agent.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                agent.automation_type.toLowerCase().includes(searchTerm.toLowerCase());

            const matchesTower = selectedTower === '' || agent.tower === selectedTower;

            const matchesStatus = selectedStatus === '' ||
                (selectedStatus === 'active' && agent.is_active) ||
                (selectedStatus === 'inactive' && !agent.is_active);

            return matchesSearch && matchesTower && matchesStatus;
        });
    }, [agents, searchTerm, selectedTower, selectedStatus]);

    // Get unique towers for filter dropdown
    const availableTowers = useMemo(() => {
        const towers = [...new Set(agents.map(agent => agent.tower))].filter(Boolean);
        return towers.sort();
    }, [agents]);

    const clearFilters = () => {
        setSearchTerm('');
        setSelectedTower('');
        setSelectedStatus('');
    };

    const watchedFields = watch('form_schema.fields');

    useEffect(() => {
        fetchAgents();
        fetchDataSources();
    }, []);

    // Auto-scroll to form when it opens
    useEffect(() => {
        if (showForm && formRef.current) {
            formRef.current.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }, [showForm]);

    const fetchAgents = async () => {
        try {
            const { data, error } = await supabase
                .from('automation_templates')
                .select('*')
                .order('tower', { ascending: true });

            if (error) throw error;
            setAgents(data || []);
        } catch (error) {
            console.error('Error fetching BOTs:', error);
        }
    };

    const fetchDataSources = async () => {
        try {
            const { data, error } = await supabase
                .from('data_sources')
                .select('id, name, type, is_active')
                .eq('is_active', true)
                .order('name', { ascending: true });

            if (error) throw error;
            setDataSources(data || []);
        } catch (error) {
            console.error('Error fetching data sources:', error);
        }
    };

    const onSubmit = async (data: AIAgentData) => {
        setIsLoading(true);
        try {
            let agentId: string;

            if (editingAgent) {
                const { error } = await supabase
                    .from('automation_templates')
                    .update({
                        ...data,
                        updated_at: new Date().toISOString(),
                    })
                    .eq('id', editingAgent.id);

                if (error) throw error;
                agentId = editingAgent.id;
            } else {
                const { data: newAgent, error } = await supabase
                    .from('automation_templates')
                    .insert([{
                        ...data,
                        is_active: true,
                    }])
                    .select()
                    .single();

                if (error) throw error;
                agentId = newAgent.id;
            }

            // Save data source field mappings
            await saveDataSourceMappings(agentId, data.form_schema.fields);

            await fetchAgents();
            onAgentCreated();
            handleCancel();
        } catch (error) {
            console.error('Error saving BOT:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const saveDataSourceMappings = async (agentId: string, fields: FormField[]) => {
        try {
            // Delete existing mappings
            await supabase
                .from('data_source_fields')
                .delete()
                .eq('automation_template_id', agentId);

            // Insert new mappings for fields with data sources
            const mappings = fields
                .filter(field => field.data_source_id)
                .map(field => ({
                    automation_template_id: agentId,
                    field_name: field.name,
                    data_source_id: field.data_source_id,
                    value_column: 'value',
                    label_column: 'label'
                }));

            if (mappings.length > 0) {
                const { error } = await supabase
                    .from('data_source_fields')
                    .insert(mappings);

                if (error) throw error;
            }
        } catch (error) {
            console.error('Error saving data source mappings:', error);
        }
    };

    const handleEdit = async (agent: any) => {
        setEditingAgent(agent);
        setValue('tower', agent.tower);
        setValue('automation_type', agent.automation_type);
        setValue('name', agent.name);
        setValue('description', agent.description);
        setValue('icon_name', agent.icon_name);
        setValue('form_schema', agent.form_schema);

        // Load data source mappings
        try {
            const { data: mappings, error } = await supabase
                .from('data_source_fields')
                .select('field_name, data_source_id')
                .eq('automation_template_id', agent.id);

            if (!error && mappings) {
                const updatedFields = agent.form_schema.fields.map((field: FormField) => {
                    const mapping = mappings.find(m => m.field_name === field.name);
                    return mapping ? { ...field, data_source_id: mapping.data_source_id } : field;
                });

                setValue('form_schema.fields', updatedFields);
            }
        } catch (error) {
            console.error('Error loading data source mappings:', error);
        }

        setShowForm(true);
    };

    const handleDelete = async (id: string) => {
        if (!window.confirm('Are you sure you want to delete this BOT?')) return;

        try {
            const { error } = await supabase
                .from('automation_templates')
                .delete()
                .eq('id', id);

            if (error) throw error;
            await fetchAgents();
            onAgentCreated();
        } catch (error) {
            console.error('Error deleting BOT:', error);
        }
    };

    const handleCancel = () => {
        setEditingAgent(null);
        setShowForm(false);
        setExpandedFields(new Set());
        setDraggedIndex(null);
        setDragOverIndex(null);
        reset({
            form_schema: {
                fields: [{ name: '', label: '', type: 'text', required: true, hidden_on_load: false }]
            }
        });
    };

    const addField = () => {
        append({ name: '', label: '', type: 'text', required: true, hidden_on_load: false });
    };

    const toggleFieldExpansion = (index: number) => {
        const newExpanded = new Set(expandedFields);
        if (newExpanded.has(index)) {
            newExpanded.delete(index);
        } else {
            newExpanded.add(index);
        }
        setExpandedFields(newExpanded);
    };

    const getAvailableFieldsForCondition = (currentIndex: number) => {
        return watchedFields
            .slice(0, currentIndex)
            .filter(field => field.name)
            .map(field => ({ value: field.name, label: field.label || field.name }));
    };

    // Drag and Drop handlers
    const handleDragStart = (e: React.DragEvent, index: number) => {
        setDraggedIndex(index);
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/html', '');
    };

    const handleDragOver = (e: React.DragEvent, index: number) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        setDragOverIndex(index);
    };

    const handleDragLeave = () => {
        setDragOverIndex(null);
    };

    const handleDrop = (e: React.DragEvent, dropIndex: number) => {
        e.preventDefault();

        if (draggedIndex !== null && draggedIndex !== dropIndex) {
            move(draggedIndex, dropIndex);
        }

        setDraggedIndex(null);
        setDragOverIndex(null);
    };

    const handleDragEnd = () => {
        setDraggedIndex(null);
        setDragOverIndex(null);
    };

    const getFeatureSummary = (agent: any) => {
        const fieldsWithDataSources = agent.form_schema?.fields?.filter((field: any) => field.data_source_id) || [];
        const fieldsWithConditions = agent.form_schema?.fields?.filter((field: any) => field.conditional_display?.depends_on_field) || [];
        const hiddenFields = agent.form_schema?.fields?.filter((field: any) => field.hidden_on_load) || [];

        const features = [];
        if (fieldsWithDataSources.length > 0) features.push(`${fieldsWithDataSources.length} DS`);
        if (fieldsWithConditions.length > 0) features.push(`${fieldsWithConditions.length} Cond`);
        if (hiddenFields.length > 0) features.push(`${hiddenFields.length} Hidden`);

        return features.length > 0 ? features.join(', ') : 'Basic';
    };

    return (
        <div className="bg-white dark:bg-gray-800 shadow-sm rounded-lg border border-gray-200 dark:border-gray-700">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                <div className="flex justify-between items-center mb-4">
                    <div>
                        <h3 className="text-lg font-medium text-gray-900 dark:text-white">BOT Management</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                            Create and manage AI automation agents with dynamic data sources and conditional fields
                        </p>
                    </div>
                    <button
                        onClick={() => setShowForm(true)}
                        className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                    >
                        <Plus className="h-4 w-4 mr-2" />
                        Create BOT
                    </button>
                </div>

                {/* Search and Filter Bar */}
                <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                    {/* Search Input */}
                    <div className="relative flex-1 max-w-md">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Search className="h-4 w-4 text-gray-400" />
                        </div>
                        <input
                            type="text"
                            placeholder="Search agents by name, description, or type..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md leading-5 bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        />
                    </div>

                    {/* Filter Controls */}
                    <div className="flex flex-wrap gap-2">
                        <select
                            value={selectedTower}
                            onChange={(e) => setSelectedTower(e.target.value)}
                            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                        >
                            <option value="">All Towers</option>
                            {availableTowers.map(tower => (
                                <option key={tower} value={tower}>{tower}</option>
                            ))}
                        </select>

                        <select
                            value={selectedStatus}
                            onChange={(e) => setSelectedStatus(e.target.value)}
                            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                        >
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>

                        {(searchTerm || selectedTower || selectedStatus) && (
                            <button
                                onClick={clearFilters}
                                className="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"
                            >
                                <X className="h-3 w-3 mr-1" />
                                Clear
                            </button>
                        )}
                    </div>

                    {/* Results Count */}
                    <div className="text-sm text-gray-500 dark:text-gray-400 whitespace-nowrap">
                        {filteredAgents.length} of {agents.length} agent{agents.length !== 1 ? 's' : ''}
                    </div>
                </div>
            </div>

            {showForm && (
                <div ref={formRef} className="p-6 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700">
                    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                    Tower
                                </label>
                                <select
                                    {...register('tower', { required: 'Tower is required' })}
                                    className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                >
                                    <option value="">Select Tower</option>
                                    {towers.map(tower => (
                                        <option key={tower} value={tower}>{tower}</option>
                                    ))}
                                </select>
                                {errors.tower && (
                                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.tower.message}</p>
                                )}
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                    Automation Type
                                </label>
                                <input
                                    {...register('automation_type', { required: 'Automation type is required' })}
                                    type="text"
                                    className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                    placeholder="e.g., create-vm, deploy-app"
                                />
                                {errors.automation_type && (
                                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.automation_type.message}</p>
                                )}
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                    Name
                                </label>
                                <input
                                    {...register('name', { required: 'Name is required' })}
                                    type="text"
                                    className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                    placeholder="Enter agent name"
                                />
                                {errors.name && (
                                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.name.message}</p>
                                )}
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                    Icon
                                </label>
                                <select
                                    {...register('icon_name', { required: 'Icon is required' })}
                                    className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                >
                                    <option value="">Select Icon</option>
                                    {availableIcons.map(icon => (
                                        <option key={icon} value={icon}>{icon}</option>
                                    ))}
                                </select>
                                {errors.icon_name && (
                                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.icon_name.message}</p>
                                )}
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                Description
                            </label>
                            <textarea
                                {...register('description')}
                                rows={3}
                                className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                placeholder="Enter agent description"
                            />
                        </div>

                        <div>
                            <div className="flex justify-between items-center mb-4">
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                    Form Fields
                                </label>

                            </div>

                            <div className="space-y-4">
                                {fields.map((field, index) => (
                                    <div
                                        key={field.id}
                                        className={`border border-gray-200 dark:border-gray-600 rounded-md transition-all duration-200 ${dragOverIndex === index ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : ''
                                            } ${draggedIndex === index ? 'opacity-50 scale-95' : ''
                                            }`}
                                        draggable
                                        onDragStart={(e) => handleDragStart(e, index)}
                                        onDragOver={(e) => handleDragOver(e, index)}
                                        onDragLeave={handleDragLeave}
                                        onDrop={(e) => handleDrop(e, index)}
                                        onDragEnd={handleDragEnd}
                                    >
                                        {/* Field Header */}
                                        <div className="p-4 bg-gray-50 dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600">
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center space-x-4 flex-1">
                                                    {/* Drag Handle */}
                                                    <div className="cursor-move text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                                                        <GripVertical className="h-5 w-5" />
                                                    </div>

                                                    <div className="flex-1">
                                                        <input
                                                            {...register(`form_schema.fields.${index}.name`, { required: true })}
                                                            type="text"
                                                            className="block w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                                            placeholder="Field Name"
                                                        />
                                                    </div>
                                                    <div className="flex-1">
                                                        <input
                                                            {...register(`form_schema.fields.${index}.label`, { required: true })}
                                                            type="text"
                                                            className="block w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                                            placeholder="Field Label"
                                                        />
                                                    </div>
                                                    <div>
                                                        <select
                                                            {...register(`form_schema.fields.${index}.type`)}
                                                            className="block w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                                        >
                                                            <option value="text">Text</option>
                                                            <option value="email">Email</option>
                                                            <option value="number">Number</option>
                                                            <option value="select">Select</option>
                                                            <option value="textarea">Textarea</option>
                                                            <option value="password">Password</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div className="flex items-center space-x-2">
                                                    <span className="text-xs text-gray-500 dark:text-gray-400 bg-gray-200 dark:bg-gray-600 px-2 py-1 rounded">
                                                        #{index + 1}
                                                    </span>
                                                    <button
                                                        type="button"
                                                        onClick={() => toggleFieldExpansion(index)}
                                                        className="text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300"
                                                        title="Advanced Settings"
                                                    >
                                                        <Settings className="h-4 w-4" />
                                                    </button>
                                                    <button
                                                        type="button"
                                                        onClick={() => remove(index)}
                                                        className="text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300"
                                                    >
                                                        <Trash2 className="h-4 w-4" />
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Expanded Field Configuration */}
                                        {expandedFields.has(index) && (
                                            <div className="p-4 space-y-4">
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                    {/* Basic Settings */}
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                                                            Data Source
                                                        </label>
                                                        <select
                                                            {...register(`form_schema.fields.${index}.data_source_id`)}
                                                            className="block w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                                        >
                                                            <option value="">None (Static)</option>
                                                            {dataSources.map(source => (
                                                                <option key={source.id} value={source.id}>
                                                                    {source.name} ({source.type})
                                                                </option>
                                                            ))}
                                                        </select>
                                                    </div>

                                                    <div className="flex items-center space-x-4">
                                                        <label className="flex items-center">
                                                            <input
                                                                {...register(`form_schema.fields.${index}.required`)}
                                                                type="checkbox"
                                                                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                                            />
                                                            <span className="ml-2 text-xs text-gray-700 dark:text-gray-300">Required</span>
                                                        </label>
                                                        <label className="flex items-center">
                                                            <input
                                                                {...register(`form_schema.fields.${index}.hidden_on_load`)}
                                                                type="checkbox"
                                                                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                                            />
                                                            <span className="ml-2 text-xs text-gray-700 dark:text-gray-300">Hidden on Load</span>
                                                        </label>
                                                    </div>
                                                </div>

                                                {/* Static Options for Select Fields */}
                                                {watch(`form_schema.fields.${index}.type`) === 'select' && !watch(`form_schema.fields.${index}.data_source_id`) && (
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                                                            Static Options (comma-separated)
                                                        </label>
                                                        <input
                                                            type="text"
                                                            className="block w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                                            placeholder="Option 1, Option 2, Option 3"
                                                            defaultValue={(() => {
                                                                const options = watch(`form_schema.fields.${index}.options`);
                                                                return Array.isArray(options) ? options.join(', ') : options || '';
                                                            })()}
                                                            onChange={(e) => {
                                                                const options = e.target.value.split(',').map(opt => opt.trim()).filter(opt => opt);
                                                                setValue(`form_schema.fields.${index}.options`, options, { shouldValidate: true });
                                                            }}
                                                        />
                                                        {/* Preview of parsed options */}
                                                        {(() => {
                                                            const options = watch(`form_schema.fields.${index}.options`);
                                                            return options && Array.isArray(options) && options.length > 0 && (
                                                                <div className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                                                                    Preview: {options.map((opt: string, idx: number) => (
                                                                        <span key={idx} className="inline-block bg-gray-100 dark:bg-gray-600 px-2 py-1 rounded mr-1 mb-1">
                                                                            {opt}
                                                                        </span>
                                                                    ))}
                                                                </div>
                                                            );
                                                        })()}
                                                    </div>
                                                )}

                                                {/* Conditional Display Settings */}
                                                <div className="border-t border-gray-200 dark:border-gray-600 pt-4">
                                                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                                                        Conditional Display
                                                    </h4>
                                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                        <div>
                                                            <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                                                                Depends on Field
                                                            </label>
                                                            <select
                                                                {...register(`form_schema.fields.${index}.conditional_display.depends_on_field`)}
                                                                className="block w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                                            >
                                                                <option value="">No dependency</option>
                                                                {getAvailableFieldsForCondition(index).map(availableField => (
                                                                    <option key={availableField.value} value={availableField.value}>
                                                                        {availableField.label}
                                                                    </option>
                                                                ))}
                                                            </select>
                                                        </div>

                                                        <div>
                                                            <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                                                                Condition Type
                                                            </label>
                                                            <select
                                                                {...register(`form_schema.fields.${index}.conditional_display.condition_type`)}
                                                                className="block w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                                            >
                                                                {conditionTypes.map(type => (
                                                                    <option key={type.value} value={type.value}>
                                                                        {type.label}
                                                                    </option>
                                                                ))}
                                                            </select>
                                                        </div>

                                                        <div>
                                                            <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                                                                Condition Value
                                                            </label>
                                                            <input
                                                                {...register(`form_schema.fields.${index}.conditional_display.condition_value`)}
                                                                type="text"
                                                                className="block w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                                                placeholder="Value to match"
                                                            />
                                                        </div>

                                                        {watch(`form_schema.fields.${index}.conditional_display.condition_type`) === 'regex' && (
                                                            <div>
                                                                <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                                                                    Regex Pattern
                                                                </label>
                                                                <input
                                                                    {...register(`form_schema.fields.${index}.conditional_display.regex_pattern`)}
                                                                    type="text"
                                                                    className="block w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                                                    placeholder="^[a-zA-Z]+$"
                                                                />
                                                            </div>
                                                        )}
                                                    </div>
                                                </div>

                                                {/* Data Source Indicator */}
                                                {watch(`form_schema.fields.${index}.data_source_id`) && (
                                                    <div className="flex items-center text-xs text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20 p-2 rounded">
                                                        <Database className="h-3 w-3 mr-1" />
                                                        <span>This field will be populated from the selected data source</span>
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="flex justify-end space-x-2">
                            <button
                                type="button"
                                onClick={addField}
                                className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded text-blue-600 dark:text-blue-400 hover:text-blue-500 dark:hover:text-blue-300"
                            >
                                <Plus className="h-4 w-4 mr-1" />
                                Add Field
                            </button>
                            <button
                                type="button"
                                onClick={handleCancel}
                                className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 shadow-sm text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"
                            >
                                <X className="h-4 w-4 mr-2" />
                                Cancel
                            </button>
                            <button
                                type="submit"
                                disabled={isLoading}
                                className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
                            >
                                {isLoading ? (
                                    <div className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full"></div>
                                ) : (
                                    <Save className="h-4 w-4 mr-2" />
                                )}
                                {editingAgent ? 'Update' : 'Create'} Agent
                            </button>
                        </div>
                    </form>
                </div>
            )}

            {/* Responsive Table */}
            <div className="overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead className="bg-gray-50 dark:bg-gray-700">
                            <tr>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Agent Details
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider min-w-0">
                                    Configuration
                                </th>
                                <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Status
                                </th>
                                <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider w-20">
                                    Actions
                                </th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            {filteredAgents.map((agent) => (
                                <tr key={agent.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                                    <td className="px-4 py-4">
                                        <div className="max-w-xs">
                                            <div className="text-sm font-medium text-gray-900 dark:text-white truncate">
                                                {agent.name}
                                            </div>
                                            <div className="text-sm text-gray-500 dark:text-gray-400 break-words">
                                                <div className="mb-1">{agent.tower} � {agent.automation_type}</div>
                                                {agent.description && (
                                                    <div className="text-xs opacity-75 line-clamp-2">
                                                        {agent.description}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-4 py-4">
                                        <div className="text-sm text-gray-900 dark:text-white">
                                            <div className="mb-1">
                                                <span className="font-medium">{agent.form_schema?.fields?.length || 0}</span> fields
                                            </div>
                                            <div className="text-xs text-gray-500 dark:text-gray-400">
                                                {getFeatureSummary(agent)}
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-4 py-4 text-center">
                                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full whitespace-nowrap ${agent.is_active
                                            ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-400'
                                            : 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-400'
                                            }`}>
                                            {agent.is_active ? 'Active' : 'Inactive'}
                                        </span>
                                    </td>
                                    <td className="px-4 py-4">
                                        <div className="flex justify-center space-x-2">
                                            <button
                                                onClick={() => handleEdit(agent)}
                                                className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 p-1"
                                                title="Edit Agent"
                                            >
                                                <Edit className="h-4 w-4" />
                                            </button>
                                            <button
                                                onClick={() => handleDelete(agent.id)}
                                                className="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300 p-1"
                                                title="Delete Agent"
                                            >
                                                <Trash2 className="h-4 w-4" />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                {filteredAgents.length === 0 && (
                    <div className="text-center py-8">
                        <div className="text-gray-500 dark:text-gray-400">
                            {agents.length === 0
                                ? "No BOTs created yet. Click \"Create BOT\" to get started."
                                : searchTerm || selectedTower || selectedStatus
                                    ? "No agents match your current filters. Try adjusting your search or filters."
                                    : "No agents found."
                            }
                        </div>
                        {(searchTerm || selectedTower || selectedStatus) && agents.length > 0 && (
                            <button
                                onClick={clearFilters}
                                className="mt-2 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 text-sm font-medium"
                            >
                                Clear all filters
                            </button>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};
import { encryptSensitiveFields, decryptSensitiveFields } from './encryption';

// Define which fields should be encrypted for each tool type
const SENSITIVE_FIELDS_MAP: Record<string, string[]> = {
  // Notification tools
  slack: ['webhook_url'],
  email: ['password'],
  
  // ITSM tools
  servicenow: ['password', 'client_secret'],
  jira: ['api_token'],
  
  // Version control tools
  github: ['access_token'],
  azure_devops: ['personal_access_token'],
  
  // Cloud provider tools
  azure: ['client_secret'],
  aws: ['secret_access_key'],
  gcp: ['service_account_key'],
};

/**
 * Gets the list of sensitive fields for a specific tool provider
 * @param provider - The tool provider (e.g., 'slack', 'servicenow')
 * @returns Array of field names that should be encrypted
 */
export const getSensitiveFields = (provider: string): string[] => {
  return SENSITIVE_FIELDS_MAP[provider.toLowerCase()] || [];
};

/**
 * Encrypts sensitive fields in tool configuration before saving to database
 * @param provider - The tool provider
 * @param config - The tool configuration object
 * @returns Configuration with encrypted sensitive fields
 */
export const encryptToolConfig = (provider: string, config: any): any => {
  const sensitiveFields = getSensitiveFields(provider);
  return encryptSensitiveFields(config, sensitiveFields);
};

/**
 * Decrypts sensitive fields in tool configuration after loading from database
 * @param provider - The tool provider
 * @param config - The tool configuration object with encrypted fields
 * @returns Configuration with decrypted sensitive fields
 */
export const decryptToolConfig = (provider: string, config: any): any => {
  const sensitiveFields = getSensitiveFields(provider);
  return decryptSensitiveFields(config, sensitiveFields);
};

/**
 * Masks sensitive fields for display purposes (shows only first/last few characters)
 * @param provider - The tool provider
 * @param config - The tool configuration object
 * @returns Configuration with masked sensitive fields
 */
export const maskToolConfig = (provider: string, config: any): any => {
  if (!config || typeof config !== 'object') return config;
  
  const sensitiveFields = getSensitiveFields(provider);
  const maskedConfig = { ...config };
  
  for (const field of sensitiveFields) {
    if (maskedConfig[field] && typeof maskedConfig[field] === 'string') {
      const value = maskedConfig[field];
      if (value.length > 8) {
        maskedConfig[field] = `${value.substring(0, 4)}****${value.substring(value.length - 4)}`;
      } else if (value.length > 4) {
        maskedConfig[field] = `${value.substring(0, 2)}****`;
      } else {
        maskedConfig[field] = '****';
      }
    }
  }
  
  return maskedConfig;
};

/**
 * Checks if any sensitive fields in the configuration are encrypted
 * @param provider - The tool provider
 * @param config - The tool configuration object
 * @returns True if sensitive fields appear to be encrypted
 */
export const hasEncryptedFields = (provider: string, config: any): boolean => {
  if (!config || typeof config !== 'object') return false;
  
  const sensitiveFields = getSensitiveFields(provider);
  
  for (const field of sensitiveFields) {
    if (config[field] && typeof config[field] === 'string') {
      // Check if it looks like our encrypted format
      const parts = config[field].split(':');
      if (parts.length === 4) {
        return true;
      }
    }
  }
  
  return false;
};
/*
  # Fix infinite recursion in user_roles RLS policy

  1. Changes
    - Drop the problematic "Only admins can manage user roles" policy
    - Create separate policies for INSERT, UPDATE, DELETE operations
    - Keep the existing SELECT policy that allows users to read their own role

  2. Security
    - Users can still read their own role
    - Only admins can modify user roles (INSERT, UPDATE, DELETE)
    - No more infinite recursion when checking user roles
*/

-- Drop the problematic policy that causes infinite recursion
DROP POLICY IF EXISTS "Only admins can manage user roles" ON user_roles;

-- Create separate policies for data modification operations only
CREATE POLICY "Only admins can insert user roles"
  ON user_roles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Only admins can update user roles"
  ON user_roles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Only admins can delete user roles"
  ON user_roles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );
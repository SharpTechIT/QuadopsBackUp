#######################################
# Provider
#######################################
provider "aws" {
  region = var.aws_region
}

#######################################
# Naming locals
#######################################
locals {
  prefix = "${var.project}-${var.environment}"
  secret_tf_name = var.secret_name != "" ? var.secret_name : "${local.prefix}-secret"
  common_tags = merge(var.tags, { Project = var.project, Env = var.environment })
}

#######################################
# VPC: conditional creation or data lookup
#######################################
resource "aws_vpc" "new" {
  count                = var.vpc_selection_type == "new" ? 1 : 0
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true
  tags = merge(local.common_tags, { Name = "${local.prefix}-vpc" })
}

data "aws_vpc" "existing" {
  count = var.vpc_selection_type == "existing" ? 1 : 0
  id    = var.existing_vpc_id
}

#######################################
# Subnet: conditional creation or data lookup
#######################################
resource "aws_subnet" "new" {
  count                   = var.subnet_selection_type == "new" ? 1 : 0
  vpc_id                  = coalesce(try(aws_vpc.new[0].id, null), try(data.aws_vpc.existing[0].id, null))
  cidr_block              = var.subnet_cidr
  map_public_ip_on_launch = false
  tags = merge(local.common_tags, { Name = "${local.prefix}-subnet" })
}

data "aws_subnet" "existing" {
  count = var.subnet_selection_type == "existing" ? 1 : 0
  id    = var.existing_subnet_id
}

#######################################
# Security Group: conditional creation or data lookup
# Default: restrictive
#######################################
resource "aws_security_group" "new" {
  count = var.sg_selection_type == "new" ? 1 : 0
  name  = "${local.prefix}-sg"
  description = "Restricted SG for systems accessing secrets"
  vpc_id = coalesce(try(aws_vpc.new[0].id, null), try(data.aws_vpc.existing[0].id, null))

  # allow SSH only from admin CIDRs if provided (recommended narrow range)
  dynamic "ingress" {
    for_each = var.allowed_admin_cidrs
    content {
      description = "admin-ssh"
      from_port   = 22
      to_port     = 22
      protocol    = "tcp"
      cidr_blocks = [ingress.value]
    }
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(local.common_tags, { Name = "${local.prefix}-sg" })
}

data "aws_security_group" "existing" {
  count = var.sg_selection_type == "existing" ? 1 : 0
  id    = var.existing_sg_id
}

#######################################
# Key Pair: conditional create or data lookup
#######################################
resource "aws_key_pair" "new" {
  count = var.keypair_selection_type == "new" ? 1 : 0
  key_name   = "${local.prefix}-kp"
  public_key = var.new_keypair_public_key
}

data "aws_key_pair" "existing" {
  count = var.keypair_selection_type == "existing" ? 1 : 0
  key_name = var.existing_keypair_name
}

#######################################
# IAM Role for rotation/automation: conditional create or data lookup
# The role below is minimalized for rotation usage; tighten policies as needed.
#######################################
data "aws_iam_role" "existing" {
  count = var.iam_role_selection_type == "existing" ? 1 : 0
  name  = var.existing_iam_role_name
}

data "aws_iam_policy_document" "rotation_assume" {
  statement {
    effect = "Allow"
    principals { type = "Service", identifiers = ["lambda.amazonaws.com"] }
    actions = ["sts:AssumeRole"]
  }
}

resource "aws_iam_role" "rotation" {
  count              = var.iam_role_selection_type == "new" ? 1 : 0
  name               = "${local.prefix}-rotation-role"
  assume_role_policy = data.aws_iam_policy_document.rotation_assume.json
  tags               = local.common_tags
}

# Minimal inline policy for the rotation role: restrict to Secrets Manager actions for target secret
data "aws_iam_policy_document" "rotation_policy" {
  count = var.iam_role_selection_type == "new" ? 1 : 0

  statement {
    sid = "SecretsManagerAccess"
    effect = "Allow"
    actions = [
      "secretsmanager:GetSecretValue",
      "secretsmanager:PutSecretValue",
      "secretsmanager:DescribeSecret"
    ]
    resources = ["*"] # tighten to specific secret ARN after creation via aws_secretsmanager_secret.this[*].arn if desired
  }

  # Allow Lambda to write logs
  statement {
    sid = "CloudWatchLogs"
    effect = "Allow"
    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ]
    resources = ["arn:aws:logs:*:*:*"]
  }
}

resource "aws_iam_role_policy" "rotation_inline" {
  count = var.iam_role_selection_type == "new" ? 1 : 0
  name  = "${local.prefix}-rotation-inline"
  role  = aws_iam_role.rotation[0].id
  policy = data.aws_iam_policy_document.rotation_policy[0].json
}

#######################################
# Locals: coalesce new vs existing resource values
#######################################
locals {
  vpc_id = coalesce(try(aws_vpc.new[0].id, null), try(data.aws_vpc.existing[0].id, null))

  subnet_id = coalesce(try(aws_subnet.new[0].id, null), try(data.aws_subnet.existing[0].id, null))

  security_group_id = coalesce(try(aws_security_group.new[0].id, null), try(data.aws_security_group.existing[0].id, null))

  keypair_name = coalesce(try(aws_key_pair.new[0].key_name, null), try(data.aws_key_pair.existing[0].key_name, null), var.existing_keypair_name, null)

  rotation_role_arn = coalesce(try(aws_iam_role.rotation[0].arn, null), try(data.aws_iam_role.existing[0].arn, null), null)
}

#######################################
# Secrets Manager: create new secret (or reference existing)
#######################################
resource "aws_secretsmanager_secret" "this" {
  count = var.resource_selection_type == "new" ? 1 : 0

  name        = local.secret_tf_name
  description = var.secret_description

  # recommended: enable automatic replication or KMS key if required (not included here)
  tags = merge(local.common_tags, { TerraformManaged = "true" })

  # optional lifecycle policy to prevent accidental deletion in prod
  lifecycle {
    prevent_destroy = false
  }
}

# If user supplied a plaintext secret_value, create a version.
resource "aws_secretsmanager_secret_version" "initial" {
  count      = var.resource_selection_type == "new" && var.secret_value != "" ? 1 : 0
  secret_id  = aws_secretsmanager_secret.this[0].id
  secret_string = var.secret_value
}

# Data source for existing secret (by ARN)
data "aws_secretsmanager_secret" "existing" {
  count = var.resource_selection_type == "existing" ? 1 : 0
  arn   = var.existing_secret_arn
}

#######################################
# Optional: enable rotation using existing or new Lambda (only if enable_rotation == true)
# This demonstrates conditional wiring; you will need to provide/implement rotation lambda code.
#######################################
# Use existing Lambda ARN if provided
data "aws_lambda_function" "existing_rotation" {
  count = var.enable_rotation && var.rotation_lambda_selection_type == "existing" ? 1 : 0
  function_name = var.existing_rotation_lambda_arn != "" ? split(":", var.existing_rotation_lambda_arn)[6] : "" # minimal attempt; better to pass function name separately
}

# If rotation uses a new Lambda, user must provide deployment of Lambda separately or you can extend module to create it.
# For this template, we assume rotation lambda exists or user will create it external to this module.

resource "aws_secretsmanager_secret_rotation" "this" {
  count = var.enable_rotation ? 1 : 0

  secret_id = var.resource_selection_type == "new" ? aws_secretsmanager_secret.this[0].id : data.aws_secretsmanager_secret.existing[0].id

  rotation_lambda_arn = var.rotation_lambda_selection_type == "existing" ? var.existing_rotation_lambda_arn : (var.iam_role_selection_type == "new" ? null : null)

  # If you want schedule, use rotation_rules
  rotation_rules {
    automatically_after_days = length(var.rotation_schedule_expression) > 0 ? tonumber(regex("\\d+", var.rotation_schedule_expression)) : 30
  }

  depends_on = [aws_iam_role_policy.rotation_inline]
}

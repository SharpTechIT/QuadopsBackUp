import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Plus, Trash2, Save, X, Edit, Database, TestTube, CheckCircle, XCircle, Cloud } from 'lucide-react';
import { supabase } from '../../config/supabase';

interface DataSource {
    id: string;
    name: string;
    description: string;
    type: 'postgresql' | 'mysql' | 'sqlserver' | 'oracle' | 'sqlite' | 'api' | 'static' | 'azure_api' | 'aws_api' | 'gcp_api';
    connection_config: any;
    query_config: any;
    is_active: boolean;
}

interface DataSourceFormData {
    name: string;
    description: string;
    type: string;
    connection_config: any;
    query_config: any;
    is_active: boolean;
}

interface DataSourceManagerProps {
    onDataSourceCreated: () => void;
}

const dataSourceTypes = [
    { value: 'postgresql', label: 'PostgreSQL' },
    { value: 'mysql', label: 'MySQL' },
    { value: 'sqlserver', label: 'SQL Server' },
    { value: 'oracle', label: 'Oracle' },
    { value: 'sqlite', label: 'SQLite' },
    { value: 'api', label: 'REST API' },
    { value: 'static', label: 'Static Data' },
    { value: 'azure_api', label: 'Azure API' },
    { value: 'aws_api', label: 'AWS API' },
    { value: 'gcp_api', label: 'Google Cloud API' },
];

const azureResourceTypes = [
    { value: 'subscriptions', label: 'Subscriptions' },
    { value: 'resourceGroups', label: 'Resource Groups' },
    { value: 'locations', label: 'Locations/Regions' },
    { value: 'vmSizes', label: 'VM Sizes (Available for VM)' },
    { value: 'virtualMachines', label: 'Virtual Machines' },
    { value: 'storageAccounts', label: 'Storage Accounts' },
    { value: 'networkSecurityGroups', label: 'Network Security Groups' },
];

export const DataSourceManager: React.FC<DataSourceManagerProps> = ({ onDataSourceCreated }) => {
    const [dataSources, setDataSources] = useState<DataSource[]>([]);
    const [cloudProviders, setCloudProviders] = useState<any[]>([]);
    const [showForm, setShowForm] = useState(false);
    const [editingSource, setEditingSource] = useState<DataSource | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [testResults, setTestResults] = useState<{ [key: string]: { success: boolean; message: string; data?: any[] } }>({});

    const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<DataSourceFormData>({
        defaultValues: {
            connection_config: '{}',
            query_config: '{}',
            is_active: true
        }
    });

    const watchedType = watch('type');

    useEffect(() => {
        fetchDataSources();
        fetchCloudProviders();
    }, []);

    const fetchDataSources = async () => {
        try {
            const { data, error } = await supabase
                .from('data_sources')
                .select('*')
                .order('name', { ascending: true });

            if (error) throw error;
            setDataSources(data || []);
        } catch (error) {
            console.error('Error fetching data sources:', error);
        }
    };

    const fetchCloudProviders = async () => {
        try {
            const { data, error } = await supabase
                .from('tools')
                .select('*')
                .eq('type', 'cloud_provider')
                .eq('status', 'active')
                .order('name', { ascending: true });

            if (error) throw error;
            setCloudProviders(data || []);
        } catch (error) {
            console.error('Error fetching cloud providers:', error);
        }
    };

    const onSubmit = async (data: DataSourceFormData) => {
        setIsLoading(true);
        try {
            console.log('Submitting data source:', data);

            // Parse JSON strings for connection_config and query_config
            let connectionConfig = {};
            let queryConfig = {};

            // Handle connection_config
            if (typeof data.connection_config === 'string') {
                try {
                    connectionConfig = data.connection_config.trim() ? JSON.parse(data.connection_config) : {};
                } catch (e) {
                    console.error('Invalid connection_config JSON:', e);
                    alert('Invalid JSON in Connection Configuration. Please check the format.');
                    return;
                }
            } else {
                connectionConfig = data.connection_config || {};
            }

            // Handle query_config
            if (typeof data.query_config === 'string') {
                try {
                    queryConfig = data.query_config.trim() ? JSON.parse(data.query_config) : {};
                } catch (e) {
                    console.error('Invalid query_config JSON:', e);
                    alert('Invalid JSON in Query Configuration. Please check the format.');
                    return;
                }
            } else {
                queryConfig = data.query_config || {};
            }

            const payload = {
                name: data.name,
                description: data.description || '',
                type: data.type,
                connection_config: connectionConfig,
                query_config: queryConfig,
                is_active: data.is_active
            };

            console.log('Final payload:', payload);

            if (editingSource) {
                const { error } = await supabase
                    .from('data_sources')
                    .update({
                        ...payload,
                        updated_at: new Date().toISOString(),
                    })
                    .eq('id', editingSource.id);

                if (error) {
                    console.error('Update error:', error);
                    throw error;
                }
            } else {
                const { error } = await supabase
                    .from('data_sources')
                    .insert([payload]);

                if (error) {
                    console.error('Insert error:', error);
                    throw error;
                }
            }

            await fetchDataSources();
            onDataSourceCreated();
            handleCancel();
        } catch (error) {
            console.error('Error saving data source:', error);
            alert(`Error saving data source: ${error instanceof Error ? error.message : 'Unknown error'}`);
        } finally {
            setIsLoading(false);
        }
    };

    const handleEdit = (source: DataSource) => {
        setEditingSource(source);
        setValue('name', source.name);
        setValue('description', source.description);
        setValue('type', source.type);
        setValue('connection_config', JSON.stringify(source.connection_config, null, 2));
        setValue('query_config', JSON.stringify(source.query_config, null, 2));
        setValue('is_active', source.is_active);
        setShowForm(true);
    };

    const handleDelete = async (id: string) => {
        if (!window.confirm('Are you sure you want to delete this data source?')) return;

        try {
            const { error } = await supabase
                .from('data_sources')
                .delete()
                .eq('id', id);

            if (error) throw error;
            await fetchDataSources();
            onDataSourceCreated();
        } catch (error) {
            console.error('Error deleting data source:', error);
        }
    };

    const handleCancel = () => {
        setEditingSource(null);
        setShowForm(false);
        reset({
            connection_config: '{}',
            query_config: '{}',
            is_active: true
        });
    };

    const testDataSource = async (source: DataSource) => {
        try {
            setTestResults(prev => ({ ...prev, [source.id]: { success: false, message: 'Testing...' } }));

            // Test the data source via API
            const response = await fetch(`/api/data-sources/${source.id}/options`);
            const result = await response.json();

            if (result.success) {
                setTestResults(prev => ({
                    ...prev,
                    [source.id]: {
                        success: true,
                        message: `Found ${result.data.length} records`,
                        data: result.data.slice(0, 5) // Show first 5 records
                    }
                }));
            } else {
                setTestResults(prev => ({
                    ...prev,
                    [source.id]: {
                        success: false,
                        message: result.error || 'Test failed'
                    }
                }));
            }
        } catch (error) {
            setTestResults(prev => ({
                ...prev,
                [source.id]: {
                    success: false,
                    message: `Test failed: ${error instanceof Error ? error.message : 'Unknown error'}`
                }
            }));
        }
    };

    const getConfigurationHelp = (type: string) => {
        switch (type) {
            case 'azure_api':
                return {
                    connection: 'Select the Azure cloud provider configuration from your tools.',
                    query: `Specify the resource type and any additional parameters:
{
  "resource_type": "subscriptions|resourceGroups|locations|vmSizes|virtualMachines",
  "additional_filters": {}
}`
                };
            case 'aws_api':
                return {
                    connection: 'Select the AWS cloud provider configuration from your tools.',
                    query: `Specify the service and resource type:
{
  "service": "ec2",
  "resource_type": "instances",
  "region": "us-east-1"
}`
                };
            case 'gcp_api':
                return {
                    connection: 'Select the GCP cloud provider configuration from your tools.',
                    query: `Specify the service and resource type:
{
  "service": "compute",
  "resource_type": "instances",
  "zone": "us-central1-a"
}`
                };
            default:
                return null;
        }
    };

    const handleCloudProviderSelect = (providerId: string) => {
        const selectedProvider = cloudProviders.find(cp => cp.id === providerId);
        if (selectedProvider) {
            const config = {
                cloud_provider_id: selectedProvider.id,
                provider_type: selectedProvider.provider.toLowerCase().replace(/\s+/g, '_')
            };
            setValue('connection_config', JSON.stringify(config, null, 2));
        }
    };

    const handleAzureResourceTypeSelect = (resourceType: string) => {
        const config = {
            resource_type: resourceType,
            additional_filters: {}
        };
        setValue('query_config', JSON.stringify(config, null, 2));
    };

    const configHelp = getConfigurationHelp(watchedType);

    return (
        <div className="bg-white dark:bg-gray-800 shadow-sm rounded-lg border border-gray-200 dark:border-gray-700">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                <div className="flex justify-between items-center">
                    <div>
                        <h3 className="text-lg font-medium text-gray-900 dark:text-white">Data Sources</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                            Configure data sources for dynamic form fields including cloud provider APIs
                        </p>
                    </div>
                    <button
                        onClick={() => setShowForm(true)}
                        className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                    >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Data Source
                    </button>
                </div>
            </div>

            {showForm && (
                <div className="p-6 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700">
                    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                    Name
                                </label>
                                <input
                                    {...register('name', { required: 'Name is required' })}
                                    type="text"
                                    className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                    placeholder="Azure VM Sizes"
                                />
                                {errors.name && (
                                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.name.message}</p>
                                )}
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                    Type
                                </label>
                                <select
                                    {...register('type', { required: 'Type is required' })}
                                    className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                >
                                    <option value="">Select Type</option>
                                    {dataSourceTypes.map(type => (
                                        <option key={type.value} value={type.value}>{type.label}</option>
                                    ))}
                                </select>
                                {errors.type && (
                                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.type.message}</p>
                                )}
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                Description
                            </label>
                            <textarea
                                {...register('description')}
                                rows={2}
                                className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="Description of this data source"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                Connection Configuration (JSON)
                            </label>
                            {['azure_api', 'aws_api', 'gcp_api'].includes(watchedType) && (
                                <div className="mb-2">
                                    <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">
                                        Select Cloud Provider
                                    </label>
                                    <select
                                        className="block w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                        onChange={(e) => handleCloudProviderSelect(e.target.value)}
                                    >
                                        <option value="">Select Cloud Provider</option>
                                        {cloudProviders
                                            .filter(cp => {
                                                if (watchedType === 'azure_api') return cp.provider === 'Microsoft Azure';
                                                if (watchedType === 'aws_api') return cp.provider === 'Amazon Web Services';
                                                if (watchedType === 'gcp_api') return cp.provider === 'Google Cloud Platform';
                                                return false;
                                            })
                                            .map(provider => (
                                                <option key={provider.id} value={provider.id}>
                                                    {provider.name} ({provider.provider})
                                                </option>
                                            ))}
                                    </select>
                                </div>
                            )}
                            <textarea
                                {...register('connection_config')}
                                rows={4}
                                className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white font-mono text-sm"
                                placeholder={['azure_api', 'aws_api', 'gcp_api'].includes(watchedType)
                                    ? '{"cloud_provider_id": "uuid", "provider_type": "azure"}'
                                    : '{"host": "localhost", "port": 5432, "database": "mydb"}'
                                }
                            />
                            {configHelp && (
                                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                                    {configHelp.connection}
                                </p>
                            )}
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                Query Configuration (JSON)
                            </label>
                            {watchedType === 'azure_api' && (
                                <div className="mb-2">
                                    <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">
                                        Azure Resource Type
                                    </label>
                                    <select
                                        className="block w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                        onChange={(e) => handleAzureResourceTypeSelect(e.target.value)}
                                    >
                                        <option value="">Select Resource Type</option>
                                        {azureResourceTypes.map(type => (
                                            <option key={type.value} value={type.value}>{type.label}</option>
                                        ))}
                                    </select>
                                </div>
                            )}
                            <textarea
                                {...register('query_config')}
                                rows={6}
                                className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white font-mono text-sm"
                                placeholder={configHelp?.query || '{"query": "SELECT id as value, name as label FROM table", "data": [{"value": "1", "label": "Option 1"}]}'}
                            />
                            {watchedType === 'azure_api' ? (
                                <div className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                                    <p><strong>Available resource types:</strong></p>
                                    <ul className="list-disc list-inside mt-1 space-y-1">
                                        <li><strong>subscriptions:</strong> List all Azure subscriptions</li>
                                        <li><strong>resourceGroups:</strong> List resource groups in subscription</li>
                                        <li><strong>locations:</strong> List available Azure regions</li>
                                        <li><strong>vmSizes:</strong> List available VM sizes for a specific VM (uses your subscription/resource group)</li>
                                        <li><strong>virtualMachines:</strong> List virtual machines in resource group</li>
                                    </ul>
                                </div>
                            ) : configHelp ? (
                                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                                    Specify the resource type and any additional parameters for the API query.
                                </p>
                            ) : (
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                    SQL query for databases or static data array. Must return 'value' and 'label' columns.
                                </p>
                            )}
                        </div>

                        <div className="flex items-center">
                            <input
                                {...register('is_active')}
                                type="checkbox"
                                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                defaultChecked={true}
                            />
                            <label className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                                Active
                            </label>
                        </div>

                        <div className="flex justify-end space-x-2">
                            <button
                                type="button"
                                onClick={handleCancel}
                                className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 shadow-sm text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"
                            >
                                <X className="h-4 w-4 mr-2" />
                                Cancel
                            </button>
                            <button
                                type="submit"
                                disabled={isLoading}
                                className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
                            >
                                {isLoading ? (
                                    <div className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full"></div>
                                ) : (
                                    <Save className="h-4 w-4 mr-2" />
                                )}
                                {editingSource ? 'Update' : 'Create'} Data Source
                            </button>
                        </div>
                    </form>
                </div>
            )}

            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                        <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Data Source
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Type
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Status
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Test
                            </th>
                            <th className="relative px-6 py-3">
                                <span className="sr-only">Actions</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                        {dataSources.map((source) => {
                            const isCloudApi = ['azure_api', 'aws_api', 'gcp_api'].includes(source.type);
                            const IconComponent = isCloudApi ? Cloud : Database;

                            return (
                                <tr key={source.id}>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="flex items-center">
                                            <IconComponent className={`h-5 w-5 mr-3 ${isCloudApi ? 'text-orange-500' : 'text-gray-400'}`} />
                                            <div>
                                                <div className="text-sm font-medium text-gray-900 dark:text-white">
                                                    {source.name}
                                                </div>
                                                <div className="text-sm text-gray-500 dark:text-gray-400">
                                                    {source.description}
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                                        {dataSourceTypes.find(t => t.value === source.type)?.label || source.type}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${source.is_active
                                                ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-400'
                                                : 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-400'
                                            }`}>
                                            {source.is_active ? 'Active' : 'Inactive'}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="flex items-center space-x-2">
                                            <button
                                                onClick={() => testDataSource(source)}
                                                className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300"
                                                title="Test Connection"
                                            >
                                                <TestTube className="h-4 w-4" />
                                            </button>
                                            {testResults[source.id] && (
                                                <div className="flex items-center" title={testResults[source.id].message}>
                                                    {testResults[source.id].success ? (
                                                        <CheckCircle className="h-4 w-4 text-green-500" />
                                                    ) : (
                                                        <XCircle className="h-4 w-4 text-red-500" />
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <div className="flex space-x-2">
                                            <button
                                                onClick={() => handleEdit(source)}
                                                className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300"
                                            >
                                                <Edit className="h-4 w-4" />
                                            </button>
                                            <button
                                                onClick={() => handleDelete(source.id)}
                                                className="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300"
                                            >
                                                <Trash2 className="h-4 w-4" />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
output "vpc_id" {
  description = "The ID of the VPC"
  value       = local.vpc_id
}

output "public_subnet_ids" {
  description = "List of public subnet IDs"
  value       = local.public_subnet_ids
}

output "igw_id" {
  description = "Internet Gateway ID"
  value       = local.igw_id
}

output "public_route_table_id" {
  description = "Route Table ID for public subnets"
  value       = try(aws_route_table.public[0].id, null)
}

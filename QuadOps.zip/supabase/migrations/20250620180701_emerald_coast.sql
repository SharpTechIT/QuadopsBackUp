/*
  # Admin Console Database Schema

  1. New Tables
    - `company_settings` - Store company branding and configuration
    - `workflow_configurations` - Map workflows to ITSM and version control tools
    - `automation_templates` - Store dynamic AI agent configurations
    - `user_roles` - Manage user permissions and admin access

  2. Security
    - Enable RLS on all new tables
    - Add policies for admin-only access to sensitive data
    - Add policies for regular users to read company settings

  3. Updates
    - Add role field to auth.users metadata
    - Create indexes for better performance
*/

-- Company settings table
CREATE TABLE IF NOT EXISTS company_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name TEXT NOT NULL DEFAULT 'AutoFlow',
  logo_url TEXT,
  primary_color TEXT DEFAULT '#2563eb',
  secondary_color TEXT DEFAULT '#1e40af',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default company settings
INSERT INTO company_settings (company_name, logo_url, primary_color, secondary_color)
VALUES ('AutoFlow', NULL, '#2563eb', '#1e40af')
ON CONFLICT DO NOTHING;

-- Workflow configurations table
CREATE TABLE IF NOT EXISTS workflow_configurations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tower TEXT NOT NULL,
  automation_type TEXT NOT NULL,
  workflow_name TEXT NOT NULL,
  workflow_endpoint TEXT NOT NULL,
  itsm_tool_id UUID REFERENCES tools(id),
  version_control_tool_id UUID REFERENCES tools(id),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(tower, automation_type)
);

-- Enhanced automation templates table
DROP TABLE IF EXISTS automation_templates;
CREATE TABLE IF NOT EXISTS automation_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tower TEXT NOT NULL,
  automation_type TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  form_schema JSONB NOT NULL DEFAULT '{}',
  icon_name TEXT DEFAULT 'Settings',
  is_active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(tower, automation_type)
);

-- User roles table
CREATE TABLE IF NOT EXISTS user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) UNIQUE,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE company_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE workflow_configurations ENABLE ROW LEVEL SECURITY;
ALTER TABLE automation_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Company settings policies (readable by all, writable by admin)
CREATE POLICY "Anyone can read company settings"
  ON company_settings
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can update company settings"
  ON company_settings
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

-- Workflow configurations policies (admin only)
CREATE POLICY "Only admins can manage workflow configurations"
  ON workflow_configurations
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

-- Automation templates policies
CREATE POLICY "Anyone can read active automation templates"
  ON automation_templates
  FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Only admins can manage automation templates"
  ON automation_templates
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

-- User roles policies
CREATE POLICY "Users can read their own role"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Only admins can manage user roles"
  ON user_roles
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

-- Insert default admin user (replace with actual admin email)
INSERT INTO user_roles (user_id, role)
SELECT id, 'admin'
FROM auth.users
WHERE email = 'admin@autoflow.com'
ON CONFLICT (user_id) DO UPDATE SET role = 'admin';

-- Insert some default automation templates
INSERT INTO automation_templates (tower, automation_type, name, description, form_schema, icon_name) VALUES
('active-directory', 'create-user', 'Create User', 'Create a new AD user account', 
 '{"fields": [
   {"name": "username", "label": "Username", "type": "text", "required": true},
   {"name": "firstName", "label": "First Name", "type": "text", "required": true},
   {"name": "lastName", "label": "Last Name", "type": "text", "required": true},
   {"name": "email", "label": "Email", "type": "email", "required": true},
   {"name": "department", "label": "Department", "type": "text", "required": true},
   {"name": "manager", "label": "Manager", "type": "text", "required": false}
 ]}', 'UserPlus'),
('azure', 'azure-vm', 'Azure VM', 'Deploy Azure Virtual Machine', 
 '{"fields": [
   {"name": "vmName", "label": "VM Name", "type": "text", "required": true},
   {"name": "resourceGroup", "label": "Resource Group", "type": "text", "required": true},
   {"name": "location", "label": "Location", "type": "select", "required": true, "options": ["East US", "West US 2", "North Europe"]},
   {"name": "vmSize", "label": "VM Size", "type": "select", "required": true, "options": ["Standard_B2s", "Standard_D2s_v3", "Standard_D4s_v3"]}
 ]}', 'Server')
ON CONFLICT (tower, automation_type) DO NOTHING;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_workflow_configurations_tower ON workflow_configurations(tower);
CREATE INDEX IF NOT EXISTS idx_automation_templates_tower ON automation_templates(tower);
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
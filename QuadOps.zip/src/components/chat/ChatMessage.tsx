// src/components/chat/ChatMessage.tsx

import React, { useState } from "react";
import { Clipboard, Download, FolderDown, ChevronDown, ChevronRight } from "lucide-react";
import type { ChatMessage as ChatMessageType } from "../../types";

interface Props {
  message: ChatMessageType | null | undefined;
}

/* ---------- helpers ---------- */

function tryParseJSON(text: string) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function stripHeredocAndFences(s: string) {
  if (!s) return "";
  let out = s;

  // Remove surrounding triple backticks or language fences
  out = out.replace(/^\s*```(?:\w+)?\s*/, "");
  out = out.replace(/\s*```\s*$/, "");

  // Try common heredoc patterns <<-EOT ... EOT or <<EOT ... EOT
  const heredoc = out.match(/<<-?EOT\s*\n([\s\S]*?)\nEOT/);
  if (heredoc && heredoc[1]) {
    out = heredoc[1];
  } else {
    // fallback: if starts with <<-EOT but no final EOT on same block, try looser capture
    const heredoc2 = out.match(/<<-?EOT\s*([\s\S]*?)\s*EOT/);
    if (heredoc2 && heredoc2[1]) out = heredoc2[1];
  }

  // trim quotes and whitespace
  out = out.trim();
  if ((out.startsWith('"') && out.endsWith('"')) || (out.startsWith("'") && out.endsWith("'"))) {
    out = out.slice(1, -1);
  }
  return out.trim();
}

function extractHeredoc(text: string, key: string) {
  // e.g. "main_tf": <<-EOT\n .... \nEOT
  const re = new RegExp(`"${key}"\\s*:\\s*<<-?EOT\\s*\\n([\\s\\S]*?)\\nEOT`, "i");
  const m = text.match(re);
  return m ? m[1].trim() : null;
}

function extractFenceForKey(text: string, key: string) {
  // e.g. "main_tf": ```terraform\n...\n```
  const re = new RegExp(`"${key}"\\s*:\\s*\\\`\\\`\\\`(?:\\w+)?\\s*\\n([\\s\\S]*?)\\n\\\`\\\`\\\``, "i");
  const m = text.match(re);
  return m ? m[1].trim() : null;
}

function extractLooseValueByKey(text: string, key: string) {
  // capture value after "key": up to next ,"someKey": OR end of object
  // non-greedy
  const re = new RegExp(`"${key}"\\s*:\\s*([\\s\\S]*?)(?=,\\s*"\\w+"\\s*:|\\n\\s*}\\s*\\,|\\n\\s*}\\s*$|\\n\\s*"[a-zA-Z0-9_]+\"\\s*:)`, "i");
  const m = text.match(re);
  return m ? m[1].trim() : null;
}

function findTerraformStartIndex(text: string) {
  // find a likely terraform code start
  const patterns = [/^\s*terraform\s*\{/im, /resource\s+"/im, /provider\s+"azurerm"/im, /module\s+"/im];
  for (const p of patterns) {
    const m = text.search(p);
    if (m >= 0) return m;
  }
  return -1;
}

/* returns object with keys main_tf, variables_tf, outputs_tf if found */
function extractTerraformConfigFromRawText(raw: string) {
  const keys = ["main_tf", "variables_tf", "outputs_tf"];
  const result: Record<string, string> = {};

  // 1) try direct JSON parse and TerraformConfiguration property
  const parsed = tryParseJSON(raw);
  if (parsed && typeof parsed === "object" && parsed.TerraformConfiguration) {
    const tc = parsed.TerraformConfiguration;
    keys.forEach((k) => {
      if (tc[k] !== undefined && tc[k] !== null) {
        let v = String(tc[k]);
        v = stripHeredocAndFences(v);
        if (!v && String(tc[k]).trim()) v = String(tc[k]).trim();
        result[k] = v;
      }
    });
    console.debug("extractTerraformConfigFromRawText: from parsed TerraformConfiguration", { foundKeys: Object.keys(result) });
    return result;
  }

  // 2) For each key try multiple extraction strategies on raw text
  keys.forEach((k) => {
    if (result[k]) return;
    // heredoc
    const h = extractHeredoc(raw, k);
    if (h) {
      result[k] = stripHeredocAndFences(h);
      return;
    }
    // fenced block value for that key
    const f = extractFenceForKey(raw, k);
    if (f) {
      result[k] = stripHeredocAndFences(f);
      return;
    }
    // loose value (may be quoted string or object-like)
    const loose = extractLooseValueByKey(raw, k);
    if (loose) {
      const cleaned = stripHeredocAndFences(loose);
      result[k] = cleaned || loose.trim();
      return;
    }
  });

  // 3) If none found but the text contains terraform-like code, try to split by markers
  const anyFound = Object.keys(result).length > 0;
  if (!anyFound) {
    const startIdx = findTerraformStartIndex(raw);
    if (startIdx !== -1) {
      // try to split into main / vars / outputs using markers or section headers
      const tail = raw.slice(startIdx).trim();
      // try to detect variables block by "variable " pattern
      const varIdx = tail.search(/\n\s*variable\s+"/i);
      const outputsIdx = tail.search(/\n\s*output\s+"/i);
      let mainPart = "";
      let varsPart = "";
      let outsPart = "";

      if (varIdx !== -1) {
        mainPart = tail.slice(0, varIdx).trim();
        if (outputsIdx !== -1 && outputsIdx > varIdx) {
          varsPart = tail.slice(varIdx, outputsIdx).trim();
          outsPart = tail.slice(outputsIdx).trim();
        } else {
          varsPart = tail.slice(varIdx).trim();
        }
      } else if (outputsIdx !== -1) {
        mainPart = tail.slice(0, outputsIdx).trim();
        outsPart = tail.slice(outputsIdx).trim();
      } else {
        // whole tail as main
        mainPart = tail;
      }

      if (mainPart) result["main_tf"] = stripHeredocAndFences(mainPart);
      if (varsPart) result["variables_tf"] = stripHeredocAndFences(varsPart);
      if (outsPart) result["outputs_tf"] = stripHeredocAndFences(outsPart);

      console.debug("extractTerraformConfigFromRawText: derived terraform by splitting", { main: !!mainPart, vars: !!varsPart, outs: !!outsPart });
    }
  }

  // 4) final: normalize empty strings to undefined (so caller can decide)
  Object.keys(result).forEach((k) => {
    if (result[k] === undefined || result[k] === null) delete result[k];
  });

  console.debug("extractTerraformConfigFromRawText: final result keys", Object.keys(result));
  return result;
}

/* ---------- Markdown Parsing Helpers ---------- */

interface MarkdownSection {
  type: 'heading' | 'list' | 'text' | 'code' | 'divider';
  content: string;
  level?: number;
  items?: string[];
  language?: string;
}

function parseMarkdown(text: string): MarkdownSection[] {
  const lines = text.split('\n');
  const sections: MarkdownSection[] = [];
  let currentSection: MarkdownSection | null = null;
  let inCodeBlock = false;
  let codeContent: string[] = [];
  let codeLanguage = '';

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmedLine = line.trim();

    // Handle code blocks (both ``` and backtick sections)
    if (trimmedLine.startsWith('```') || (trimmedLine.startsWith('`') && trimmedLine.endsWith('`') && trimmedLine.length > 6)) {
      if (!inCodeBlock) {
        // Starting code block
        inCodeBlock = true;
        if (trimmedLine.startsWith('```')) {
          codeLanguage = trimmedLine.substring(3).trim();
        } else {
          // Handle `main.tf` style sections
          codeLanguage = trimmedLine.replace(/`/g, '').trim();
        }
        codeContent = [];
        if (currentSection) {
          sections.push(currentSection);
          currentSection = null;
        }
      } else {
        // Ending code block
        inCodeBlock = false;
        sections.push({
          type: 'code',
          content: codeContent.join('\n'),
          language: codeLanguage
        });
        codeContent = [];
        codeLanguage = '';
      }
      continue;
    }

    if (inCodeBlock) {
      codeContent.push(line);
      continue;
    }

    // Handle horizontal rules
    if (trimmedLine === '---' || trimmedLine === '***') {
      if (currentSection) {
        sections.push(currentSection);
        currentSection = null;
      }
      sections.push({ type: 'divider', content: '' });
      continue;
    }

    // Handle headings
    const headingMatch = trimmedLine.match(/^(#{1,6})\s+(.+)$/);
    if (headingMatch) {
      if (currentSection) {
        sections.push(currentSection);
      }
      currentSection = {
        type: 'heading',
        content: headingMatch[2],
        level: headingMatch[1].length
      };
      continue;
    }

    // Handle list items
    const listMatch = trimmedLine.match(/^[-*•]\s+(.+)$/);
    if (listMatch) {
      if (currentSection?.type !== 'list') {
        if (currentSection) {
          sections.push(currentSection);
        }
        currentSection = {
          type: 'list',
          content: '',
          items: []
        };
      }
      currentSection.items!.push(listMatch[1]);
      continue;
    }

    // Handle regular text
    if (trimmedLine) {
      if (currentSection?.type !== 'text') {
        if (currentSection) {
          sections.push(currentSection);
        }
        currentSection = {
          type: 'text',
          content: trimmedLine
        };
      } else {
        currentSection.content += '\n' + trimmedLine;
      }
    } else if (currentSection) {
      // Empty line - finalize current section
      sections.push(currentSection);
      currentSection = null;
    }
  }

  // Add any remaining section
  if (currentSection) {
    sections.push(currentSection);
  }

  // Post-process to merge duplicate code sections and remove empty ones
  const processedSections: MarkdownSection[] = [];
  const codeBlockTracker: Record<string, number> = {};

  for (const section of sections) {
    if (section.type === 'code') {
      const language = section.language || 'code';
      
      // If we already have a code block with this language and it's empty, skip this empty one
      if (section.content.trim() === '' && codeBlockTracker[language] !== undefined) {
        continue;
      }
      
      // If we have an empty code block and later find a non-empty one, replace it
      if (codeBlockTracker[language] !== undefined && processedSections[codeBlockTracker[language]].content.trim() === '' && section.content.trim() !== '') {
        processedSections[codeBlockTracker[language]] = section;
        continue;
      }
      
      // Track this code block
      if (codeBlockTracker[language] === undefined) {
        codeBlockTracker[language] = processedSections.length;
      }
    }
    
    processedSections.push(section);
  }

  return processedSections;
}

/* ---------- Markdown Rendering Component ---------- */

interface MarkdownRendererProps {
  content: string;
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});
  const sections = parseMarkdown(content);

  const toggleSection = (index: number) => {
    setExpandedSections(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  // Helper function to render text with markdown formatting
  const renderTextWithMarkdown = (text: string) => {
    // Handle bold text (**text**)
    const parts = text.split(/(\*\*[^*]+\*\*)/g);
    return parts.map((part, index) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={index} className="font-semibold">
            {part.slice(2, -2)}
          </strong>
        );
      }
      return part;
    });
  };

  const renderSection = (section: MarkdownSection, index: number) => {
    switch (section.type) {
      case 'heading':
        const HeadingTag = `h${Math.min(section.level || 1, 6)}` as keyof JSX.IntrinsicElements;
        const headingClasses = {
          1: 'text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4 pb-2 border-b border-gray-300 dark:border-gray-600',
          2: 'text-xl font-bold text-gray-800 dark:text-gray-200 mb-3 mt-6',
          3: 'text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2 mt-4',
          4: 'text-base font-semibold text-gray-700 dark:text-gray-300 mb-2 mt-3',
          5: 'text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1 mt-2',
          6: 'text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1 mt-2'
        };
        
        return (
          <HeadingTag
            key={index}
            className={headingClasses[section.level as keyof typeof headingClasses] || headingClasses[3]}
          >
            {renderTextWithMarkdown(section.content)}
          </HeadingTag>
        );

      case 'list':
        return (
          <div key={index} className="mb-4">
            <ul className="space-y-2">
              {section.items?.map((item, itemIndex) => {
                const isNested = item.includes('\n') || item.length > 100;
                const isExpanded = expandedSections[`${index}-${itemIndex}`];
                
                return (
                  <li key={itemIndex} className="flex items-start">
                    <span className="text-blue-500 dark:text-blue-400 mr-2 mt-1">•</span>
                    <div className="flex-1">
                      {isNested ? (
                        <div>
                          <button
                            onClick={() => toggleSection(`${index}-${itemIndex}` as any)}
                            className="flex items-center text-sm text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                          >
                            {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                            <span className="ml-1">
                              {item.split('\n')[0].substring(0, 80)}
                              {item.length > 80 && '...'}
                            </span>
                          </button>
                          {isExpanded && (
                            <div className="mt-2 pl-4 border-l-2 border-gray-200 dark:border-gray-600">
                              <div className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                                {item}
                              </div>
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-sm text-gray-700 dark:text-gray-300">
                          {renderTextWithMarkdown(item)}
                        </span>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        );

      case 'code':
        return (
          <div key={index} className="mb-4">
            <div className="relative bg-gray-900 dark:bg-gray-800 text-green-300 rounded-lg p-4 text-sm">
              {section.language && (
                <div className="text-gray-400 text-xs mb-2 uppercase tracking-wide">
                  {section.language}
                </div>
              )}
              <pre
                className="whitespace-pre-wrap break-words overflow-x-auto"
                style={{ 
                  fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, "Roboto Mono", monospace',
                  margin: 0,
                  paddingRight: '40px'
                }}
              >
                {section.content}
              </pre>
              <button
                onClick={() => navigator.clipboard.writeText(section.content)}
                className="absolute top-2 right-2 bg-gray-800 hover:bg-gray-700 text-white p-2 rounded border border-gray-600 transition-colors duration-200"
                title="Copy code"
              >
                <Clipboard size={16} />
              </button>
            </div>
          </div>
        );

      case 'divider':
        return (
          <div key={index} className="my-6">
            <hr className="border-gray-300 dark:border-gray-600" />
          </div>
        );

      case 'text':
        return (
          <div key={index} className="mb-4">
            <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed whitespace-pre-wrap">
              {renderTextWithMarkdown(section.content)}
            </p>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="prose prose-sm max-w-none">
      {sections.map(renderSection)}
    </div>
  );
};

/* ---------- File Download Component ---------- */

interface FileDownloadSectionProps {
  sessionId: string;
  files?: Record<string, any>;
}

const FileDownloadSection: React.FC<FileDownloadSectionProps> = ({ sessionId, files }) => {
  const [isDownloading, setIsDownloading] = useState<Record<string, boolean>>({});

  const handleFileDownload = async (filename: string) => {
    setIsDownloading(prev => ({ ...prev, [filename]: true }));
    try {
      const response = await fetch(`http://localhost:3001/api/download/${sessionId}/${filename}`);
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Download error:', error);
      alert('Failed to download file');
    } finally {
      setIsDownloading(prev => ({ ...prev, [filename]: false }));
    }
  };

  const handleDownloadAll = async () => {
    setIsDownloading(prev => ({ ...prev, 'all': true }));
    try {
      const response = await fetch(`http://localhost:3001/api/download-all/${sessionId}`);
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `terraform-${sessionId}.zip`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Download error:', error);
      alert('Failed to download files');
    } finally {
      setIsDownloading(prev => ({ ...prev, 'all': false }));
    }
  };

  if (!files || Object.keys(files).length === 0) return null;

  return (
    <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-sm font-medium text-blue-900 dark:text-blue-100 flex items-center">
          <FolderDown size={16} className="mr-2" />
          Generated Files
        </h4>
        <button
          onClick={handleDownloadAll}
          disabled={isDownloading['all']}
          className="flex items-center gap-2 px-3 py-1 text-xs bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 transition-colors"
        >
          <Download size={14} />
          {isDownloading['all'] ? 'Downloading...' : 'Download All'}
        </button>
      </div>
      
      <div className="grid gap-2">
        {Object.entries(files).map(([key, fileInfo]) => (
          <div key={key} className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-md border border-gray-200 dark:border-gray-700">
            <span className="text-sm text-gray-700 dark:text-gray-300 font-medium">
              {fileInfo.filename || `${key}.tf`}
            </span>
            <button
              onClick={() => handleFileDownload(fileInfo.filename || `${key}.tf`)}
              disabled={isDownloading[fileInfo.filename]}
              className="flex items-center gap-1 px-2 py-1 text-xs bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50 transition-colors"
            >
              <Download size={12} />
              {isDownloading[fileInfo.filename] ? 'Downloading...' : 'Download'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

/* ---------- UI ---------- */

export const ChatMessage: React.FC<Props> = ({ message }) => {
  if (!message) return null;

  const sender = message.sender ?? "agent";
  const isUser = sender === "user";

  // Normalize message text to raw string
  let rawText = "[No content]";
  if (message.text !== undefined && message.text !== null) {
    rawText = typeof message.text === "string" ? message.text : JSON.stringify(message.text, null, 2);
  }

  // Extract file information from metadata
  const metadata = message.metadata ? (typeof message.metadata === 'string' ? tryParseJSON(message.metadata) : message.metadata) : null;
  const files = metadata?.files;

  // For agent: check if it's markdown content or structured data
  if (!isUser) {
    // First try to extract Terraform configuration (existing logic)
    const parsed = tryParseJSON(rawText);
    let terraformObj: Record<string, string> | null = null;
    
    if (parsed && typeof parsed === "object" && parsed.TerraformConfiguration) {
      const tc = parsed.TerraformConfiguration;
      terraformObj = {};
      ["main_tf", "variables_tf", "outputs_tf"].forEach((k) => {
        if (tc[k] !== undefined && tc[k] !== null) {
          let v = String(tc[k]);
          v = stripHeredocAndFences(v);
          if (!v && String(tc[k]).trim()) v = String(tc[k]).trim();
          terraformObj![k] = v;
        }
      });
    } else {
      const extracted = extractTerraformConfigFromRawText(rawText);
      if (Object.keys(extracted).length > 0) terraformObj = extracted;
    }

    // If terraform configuration found, render it (existing logic)
    if (terraformObj && Object.keys(terraformObj).length > 0) {
      const orderedKeys: Array<{ key: string; title: string }> = [
        { key: "main_tf", title: "main.tf" },
        { key: "variables_tf", title: "variables.tf" },
        { key: "outputs_tf", title: "outputs.tf" },
      ];

      let normalText = rawText;
      normalText = normalText.replace(/```(?:\w+)?\n[\s\S]*?\n```/g, "").trim();
      normalText = normalText.replace(/<<-?EOT\s*\n[\s\S]*?\nEOT/g, "").trim();
      
      normalText = normalText.replace(/^(`main.tf`|`variables\.tf`|`outputs\.tf`)\s*$/gm, "").trim();
      normalText = normalText.replace(/📁 \*\*Generated Files Available for Download:\*\*[\s\S]*$/, "").trim();
      
      if (parsed && typeof parsed === "object") {
        const maybeMsg = parsed.message || parsed.explanation || parsed.text;
        if (maybeMsg && typeof maybeMsg === "string") {
          normalText = maybeMsg.trim();
        }
      }


        // If we've extracted terraform files into terraformObj, strip code blocks
        // and any orphan file-name lines so we don't show duplicate/blank names.
        if (terraformObj && Object.keys(terraformObj).length > 0) {
          // remove fenced code blocks (```...```) – simpler and more robust
          normalText = normalText.replace(/```[\s\S]*?```/g, "");

          // remove heredoc blocks like <<EOT ... EOT (handles <<EOT and <<-EOT)
          normalText = normalText.replace(/<<-?EOT[\s\S]*?EOT/g, "");

          // Remove lines that are JUST a filename (optionally wrapped in 1-3 backticks).
          // This catches:
          //   main.tf
          //   `main.tf`
          //   ```main.tf```
          normalText = normalText.replace(/^\s*`{0,3}\s*(?:main\.tf|variables\.tf|outputs\.tf)\s*`{0,3}\s*$/gmi, "");

          // Remove inline `main.tf` occurrences (so inline code like `main.tf` is removed)
          normalText = normalText.replace(/`(?:main\.tf|variables\.tf|outputs\.tf|backend\.tf)`/gi, "");

          // remove the "Generated Files Available for Download" footer if present
          normalText = normalText.replace(/📁 \*\*Generated Files Available for Download:\*\*[\s\S]*$/g, "");

          normalText = normalText.trim();
        } else {
          // no terraform extracted — keep fences so code appears inline in the message
          normalText = normalText.replace(/📁 \*\*Generated Files Available for Download:\*\*[\s\S]*$/g, "").trim();
        }
      
        // Remove empty ### (Markdown headings with no text)
      normalText = normalText.replace(/^#{1,6}\s*$/gm, "");

        // Remove lines that are just "Final", "Final <filename>", or Markdown heading versions
      normalText = normalText.replace(/^#{0,6}\s*Final(?:\s+`?.+?`?)?\s*$/gmi, "");

      const [expandedBlocksState, setExpandedBlocksState] = useState<Record<string, boolean>>({});
      const toggle = (k: string) =>
        setExpandedBlocksState((s) => ({ ...s, [k]: !s[k] }));

      return (
        <div className="flex justify-start my-4">
          <div className="rounded-xl px-6 py-4 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 border border-gray-200 dark:border-gray-600 shadow-sm max-w-4xl w-full">
            <div className="mb-3">
              <div className="flex items-center mb-2">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                  AI
                </div>
                <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">Agent</span>
              </div>
            </div>

            {normalText && <MarkdownRenderer content={normalText} />}

            {orderedKeys.map(({ key, title }) => {
              const code = terraformObj![key] ?? "";
              if (code === "") {
                return (
                  <div key={key} className="mb-4">
                    <div className="font-medium text-sm mb-2 text-gray-700 dark:text-gray-300">{title}</div>
                    <div className="text-sm text-gray-500 italic bg-gray-100 dark:bg-gray-800 p-3 rounded-md">
                      [empty]
                    </div>
                  </div>
                );
              }
              const isExpanded = !!expandedBlocksState[key];
              const needShowMore = code.length > 400;
              return (
                <div key={key} className="mb-4">
                  <div className="font-medium text-sm mb-2 text-gray-700 dark:text-gray-300">{title}</div>
                  <div className="relative bg-gray-900 dark:bg-gray-800 text-green-300 rounded-lg p-4 text-sm">
                    <pre
                      className={`whitespace-pre-wrap break-words ${isExpanded ? "max-h-none" : "max-h-48 overflow-y-auto"}`}
                      style={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, "Roboto Mono", monospace', margin: 0, paddingRight: '40px' }}
                    >
                      {code}
                    </pre>

                    <button
                      onClick={() => { navigator.clipboard.writeText(code); }}
                      className="absolute top-3 right-3 bg-gray-800 hover:bg-gray-700 text-white p-2 rounded border border-gray-600 transition-colors duration-200"
                      title={`Copy ${title}`}
                    >
                      <Clipboard size={16} />
                    </button>

                    {needShowMore && (
                      <button
                        onClick={() => toggle(key)}
                        className="mt-3 text-xs text-blue-400 hover:underline block"
                      >
                        {isExpanded ? "Show less" : "Show more"}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}

            {message.id && <FileDownloadSection sessionId={message.id.split('-')[0] || ''} files={files} />}
          </div>
        </div>
      );
    }

    // Check if it's markdown content (contains markdown patterns)
    const hasMarkdownPatterns = rawText.match(/^#{1,6}\s+/m) || 
                               rawText.match(/^[-*]\s+/m) || 
                               rawText.match(/```/) ||
                               rawText.match(/^\s*---\s*$/m);

    if (hasMarkdownPatterns) {
      return (
        <div className="flex justify-start my-4">
          <div className="rounded-xl px-6 py-4 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 border border-gray-200 dark:border-gray-600 shadow-sm max-w-4xl w-full">
            <div className="mb-4">
              <div className="flex items-center mb-3">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                  AI
                </div>
                <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">Agent</span>
              </div>
            </div>

            <MarkdownRenderer content={rawText} />
            
            {message.id && <FileDownloadSection sessionId={message.id.split('-')[0] || ''} files={files} />}
          </div>
        </div>
      );
    }

    // Fallback to existing logic for code blocks and JSON
    const fencedMatch = rawText.match(/```(?:json|terraform|hcl|[a-zA-Z0-9_-]+)?\n([\s\S]*?)\n```/i);
    if (fencedMatch) {
      const code = stripHeredocAndFences(fencedMatch[0]);
      return (
        <div className="flex justify-start my-4">
          <div className="rounded-xl px-6 py-4 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 border border-gray-200 dark:border-gray-600 shadow-sm max-w-4xl w-full">
            <div className="mb-3">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                  AI
                </div>
                <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">Agent</span>
              </div>
            </div>
            <div className="relative bg-gray-900 dark:bg-gray-800 text-green-300 rounded-lg p-4 text-sm">
              <pre className="whitespace-pre-wrap break-words max-h-48 overflow-y-auto" style={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, "Roboto Mono", monospace', margin: 0, paddingRight: '40px' }}>{code}</pre>
              <button onClick={() => navigator.clipboard.writeText(code)} className="absolute top-3 right-3 bg-gray-800 hover:bg-gray-700 text-white p-2 rounded border border-gray-600 transition-colors duration-200"><Clipboard size={16} /></button>
            </div>
            {message.id && <FileDownloadSection sessionId={message.id.split('-')[0] || ''} files={files} />}
          </div>
        </div>
      );
    }

    // detect raw JSON and pretty-print
    const trimmed = rawText.trim();
    if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
      const pretty = (() => {
        try { return JSON.stringify(JSON.parse(trimmed), null, 2); } catch { return trimmed; }
      })();
      return (
        <div className="flex justify-start my-4">
          <div className="rounded-xl px-6 py-4 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 border border-gray-200 dark:border-gray-600 shadow-sm max-w-4xl w-full">
            <div className="mb-3">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                  AI
                </div>
                <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">Agent</span>
              </div>
            </div>
            <div className="relative bg-gray-900 dark:bg-gray-800 text-green-300 rounded-lg p-4 text-sm">
              <pre className="whitespace-pre-wrap break-words max-h-48 overflow-y-auto" style={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, "Roboto Mono", monospace', margin: 0, paddingRight: '40px' }}>{pretty}</pre>
              <button onClick={() => navigator.clipboard.writeText(pretty)} className="absolute top-3 right-3 bg-gray-800 hover:bg-gray-700 text-white p-2 rounded border border-gray-600 transition-colors duration-200"><Clipboard size={16} /></button>
            </div>
            {message.id && <FileDownloadSection sessionId={message.id.split('-')[0] || ''} files={files} />}
          </div>
        </div>
      );
    }

    // final fallback: plain agent text
    return (
      <div className="flex justify-start my-4">
        <div className="rounded-xl px-6 py-4 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 border border-gray-200 dark:border-gray-600 shadow-sm max-w-4xl w-full">
          <div className="mb-3">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                AI
              </div>
              <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">Agent</span>
            </div>
          </div>
          <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">{rawText}</p>
          {message.id && <FileDownloadSection sessionId={message.id.split('-')[0] || ''} files={files} />}
        </div>
      </div>
    );
  }

  // USER: enhanced bubble design
  return (
    <div className="flex justify-end my-4">
      <div className="rounded-xl px-6 py-4 bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-sm max-w-3xl w-full">
        <div className="mb-2">
          <div className="flex items-center justify-end">
            <span className="mr-2 text-sm font-medium">You</span>
            <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center text-blue-100 text-sm font-medium">
              U
            </div>
          </div>
        </div>
        <div className="text-sm leading-relaxed whitespace-pre-wrap">{rawText}</div>
      </div>
    </div>
  );
};
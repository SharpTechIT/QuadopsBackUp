import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  UserPlus, 
  UserMinus, 
  UserCheck, 
  Users, 
  MailPlus,
  MailMinus,
  Settings,
  Server,
  Trash2,
  Database,
  Shield,
  HardDrive,
  Globe,
  Cloud,
  Terminal,
  Monitor,
  Network,
  Activity
} from 'lucide-react';
import { supabase } from '../../config/supabase';

const iconMap = {
  UserPlus, UserMinus, UserCheck, Users, MailPlus, MailMinus,
  Settings, Server, Trash2, Database, Shield, HardDrive,
  Globe, Cloud, Terminal, Monitor, Network, Activity
};

interface AutomationGridProps {
  towerId: string;
}

export const AutomationGrid: React.FC<AutomationGridProps> = ({ towerId }) => {
  const navigate = useNavigate();
  const [automations, setAutomations] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchAutomations();
  }, [towerId]);

  const fetchAutomations = async () => {
    try {
      const { data, error } = await supabase
        .from('automation_templates')
        .select('*')
        .eq('tower', towerId)
        .eq('is_active', true)
        .order('name', { ascending: true });

      if (error) throw error;
      setAutomations(data || []);
    } catch (error) {
      console.error('Error fetching automations:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 animate-pulse">
            <div className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-gray-200 w-12 h-12"></div>
                <div className="ml-4 flex-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (automations.length === 0) {
    return (
      <div className="text-center py-12">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white">No automations available</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
          No automation templates have been configured for this tower yet.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {automations.map((automation) => {
        const IconComponent = iconMap[automation.icon_name as keyof typeof iconMap] || Settings;
        
        return (
          <div
            key={automation.id}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200 cursor-pointer hover:scale-105"
            onClick={() => navigate(`/agents/${towerId}/${automation.automation_type}`)}
          >
            <div className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400">
                  <IconComponent className="h-6 w-6" />
                </div>
                <div className="ml-4 flex-1">
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white">{automation.name}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{automation.description}</p>
                </div>
              </div>
              <div className="mt-4">
                <span className="text-sm font-medium text-blue-600 dark:text-blue-400">Configure →</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
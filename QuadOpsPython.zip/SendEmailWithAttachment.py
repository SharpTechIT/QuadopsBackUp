import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import sys
import json
import logging
from jinja2 import Template

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Email & SMTP Configuration
smtp_server = "smtp.gmail.com"  # or "smtp.office365.com" for Outlook
smtp_port = 587
sender_password = "wlmczskuvhaznxua"
sender_email = "sharptechgenai@gmail.com"

# Load and customize HTML template
def generate_html_template(data):
    # HTML Template using Jinja2
    html_template = """
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body {
          background-color: #f1f4f8;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          margin: 0;
          padding: 20px;
        }
        .container {
          max-width: 600px;
          margin: auto;
          background-color: #ffffff;
          border-radius: 8px;
          box-shadow: 0 0 10px rgba(0,0,0,0.08);
          padding: 30px;
        }
        .header {
          border-bottom: 2px solid #0078d4;
          padding-bottom: 10px;
          margin-bottom: 20px;
        }
        .header h1 {
          color: #0078d4;
          font-size: 24px;
          margin: 0;
        }
        .body {
          font-size: 16px;
          color: #333333;
        }
        .body p {
          margin-bottom: 15px;
        }
        .details {
          background-color: #f9f9f9;
          border-radius: 6px;
          padding: 15px;
          margin-top: 10px;
          font-size: 15px;
        }
        .details p {
          margin: 6px 0;
        }
        .details span {
          font-weight: bold;
          color: #444;
        }
        .footer {
          margin-top: 25px;
          font-size: 13px;
          color: #777;
          border-top: 1px solid #ddd;
          padding-top: 10px;
          text-align: center;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>✅ {{ automation_name }} Completed Successfully</h1>
        </div>

        <div class="body">
          <p>Hi <strong>User</strong>,</p>
          <p>
            The automation for <strong>{{ automation_name }}</strong> in <strong>{{ tower }}</strong> has been completed successfully by SharTech bot.
            Below are the submitted details:
          </p>

          <div class="details">
            {% for key, value in form_data.items() %}
              <p><span>{{ key | replace("_", " ") | title }}:</span> {{ value }}</p>
            {% endfor %}
          </div>

          <p>
            ServiceNow Request Number: <a href="https://dev206438.service-now.com/nav_to.do?uri=sc_request.do?sys_id={{ servicenow_request.sys_id }}"><strong>{{ servicenow_request.request_number }}</strong></a>
          </p>
        </div>

        <div class="footer">
          © 2025 IT Automation | Generic Automation System
        </div>
      </div>
    </body>
    </html>
    """

    # Render HTML
    template = Template(html_template)
    html_output = template.render(
        tower=data["tower"],
        form_data=data["form_data"],
        automation_name=data["automation_name"],
        servicenow_request=data["servicenow_request"]
    )

    # Save or send email using this HTML
    return html_output


def SendGmailNotification(recipient_email, mail_details):

    print("Coming to send mail")
    mail_details_json=json.loads(mail_details)
    # Replace placeholders with actual values
    html_content = generate_html_template(mail_details_json)

    # Create MIME email
    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"✅ SharpTech Automation : {mail_details_json['automation_name']}"
    msg["From"] = sender_email
    msg["To"] = recipient_email
    msg.attach(MIMEText(html_content, "html"))

    # Send email via SMTP
    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, recipient_email, msg.as_string())
        print("✅ Email sent successfully.")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")


if __name__ == "__main__":
    recipient_email = sys.argv[2] #"cloudautomationninja@gmail.com"
    # VM Details (replace with dynamic values or parameters)
    vm_details = json.dump(sys.argv[1])

    SendGmailNotification(recipient_email, vm_details)
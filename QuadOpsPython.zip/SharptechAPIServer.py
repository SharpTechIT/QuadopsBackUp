import os
import requests
import json
import base64
from fastapi import FastAPI, HTTPException, Request, Depends, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
from supabase import create_client, Client
import logging
from SendEmailWithAttachment import SendGmailNotification

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables from .env file
load_dotenv()

# --- Supabase Configuration ---
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

if not SUPABASE_URL:
    logger.error("Error: SUPABASE_URL environment variable is not set.")
    raise ValueError("SUPABASE_URL environment variable is not set.")
if not SUPABASE_KEY:
    logger.error("Error: SUPABASE_KEY environment variable is not set.")
    raise ValueError("SUPABASE_KEY environment variable is not set.")

try:
    supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
    logger.info("Supabase client initialized successfully.")
except Exception as e:
    logger.exception(f"Error creating Supabase client: {e}")
    raise RuntimeError(f"Failed to initialize Supabase client: {e}")


# --- FastAPI App Initialization ---
app = FastAPI(
    title="ServiceNow Request & Git Action Trigger",
    description="API to interact with ServiceNow and trigger GitHub Actions.",
    version="1.0.0"
)

# --- CORS Middleware Configuration ---
origins = [
    "http://localhost:5173",
    "http://quadops.eastus.cloudapp.azure.com/",
    "http://52.147.203.234:8000"# Your React app's development server origin
    # Add other frontend origins if necessary, e.g., "[https://your-deployed-frontend.com](https://your-deployed-frontend.com)"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Basic Authentication Configuration for FastAPI itself ---
security = HTTPBasic()

FASTAPI_USERNAME = os.getenv("FASTAPI_USERNAME")
FASTAPI_PASSWORD = os.getenv("FASTAPI_PASSWORD")

if not FASTAPI_USERNAME or not FASTAPI_PASSWORD:
    logger.error("FASTAPI_USERNAME and FASTAPI_PASSWORD must be set in the .env file for API authentication.")
    raise ValueError("FASTAPI_USERNAME and FASTAPI_PASSWORD must be set in the .env file for API authentication.")

def authenticate_fastapi_user(credentials: HTTPBasicCredentials = Depends(security)):
    """
    Dependency to authenticate users accessing this FastAPI application.
    """
    if not (credentials.username == FASTAPI_USERNAME and credentials.password == FASTAPI_PASSWORD):
        logger.warning(f"Failed authentication attempt for user: {credentials.username}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password for FastAPI",
            headers={"WWW-Authenticate": "Basic"},
        )
    logger.info(f"User '{credentials.username}' authenticated successfully.")
    return credentials.username

# --- Pydantic Models for Request Payloads ---
class ServiceRequestPayload(BaseModel):
    short_description: str
    description: str | None = None
    approval: str = "requested" # Default value
    request_state: str = "requested" # Default value

class ServiceRequestUpdate(BaseModel):
    sys_id: str # Required for updating a specific record
    snow_data: dict # Use dict for generic JSON payload

class GitPayload(BaseModel):
    workflowID: str
    automationData: dict # Use dict for generic JSON payload
    servicenowData: dict
# --- Helper Function to Fetch ServiceNow Credentials from Supabase ---
async def get_servicenow_credentials():
    """
    Fetches ServiceNow configuration from the 'tools' table in Supabase.
    Assumes a 'tools' table with columns 'type', 'provider', 'config'.
    The 'config' column is expected to be a JSONB containing:
    {
      "instance_url": "[https://yourinstance.service-now.com](https://yourinstance.service-now.com)",
      "username": "your_servicenow_username",
      "password": "your_servicenow_password"
    }
    """
    try:
        response = supabase.from_('tools').select('*').eq('type', 'itsm').eq('status', 'active').execute()
        tools_data = response.data

        if not tools_data:
            logger.warning("No active ITSM tools found in Supabase.")
            return None

        servicenow_tool = next((
            tool for tool in tools_data
            if tool.get('provider', '').lower() == 'servicenow'
        ), None)

        if not servicenow_tool:
            logger.warning("ServiceNow tool (provider 'servicenow') not found in active ITSM tools.")
            return None

        config = servicenow_tool.get('config')
        if not config:
            logger.warning("ServiceNow tool found but 'config' is missing.")
            return None

        instance_url = config.get('instance_url')
        username = config.get('username')
        password = config.get('password')

        if not instance_url or not username or not password:
            logger.warning("ServiceNow config incomplete: missing instance_url, username, or password in config.")
            return None

        # Encode username and password to Base64 for Basic Auth
        auth_string = f"{username}:{password}"
        encoded_auth = base64.b64encode(auth_string.encode('utf-8')).decode('utf-8')
        authorization_header = f"Basic {encoded_auth}"

        return {
            "base_url": f"{instance_url}/api/now/table/sc_request", # Base URL for sc_request table
            "authorization_header": authorization_header
        }

    except Exception as e:
        logger.exception(f"Error fetching ServiceNow credentials from Supabase: {e}")
        return None

class EmailNotificationPayload(BaseModel):
    mail_id: str
    mail_body: object
# --- FastAPI Endpoints ---

@app.get("/")
async def root():
    """
    Root endpoint to check if the FastAPI application is running.
    """
    logger.info("Root endpoint hit.")
    return {"message": "ServiceNow and Git Action API is running!"}

@app.post("/create-servicenow-request")
async def create_servicenow_request(
    request_payload: ServiceRequestPayload,
    http_request: Request,
    username: str = Depends(authenticate_fastapi_user)
):
    """
    Receives a request to create a ServiceNow Service Request.
    Fetches ServiceNow credentials from Supabase and sends the request.
    This endpoint requires Basic Authentication.
    """
    logger.info(f"User '{username}' received request to create ServiceNow ticket: {request_payload.short_description}")

    servicenow_creds = await get_servicenow_credentials()

    if not servicenow_creds:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="ServiceNow configuration not found or incomplete in Supabase."
        )

    servicenow_create_url = servicenow_creds["base_url"] # Use base_url for creating a new record
    authorization_header = servicenow_creds["authorization_header"]

    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': authorization_header,
    }

    servicenow_payload = json.dumps({
        "approval": request_payload.approval,
        "request_state": request_payload.request_state,
        "short_description": request_payload.short_description,
        "description": request_payload.description,
    })

    try:
        logger.info(f"Sending POST request to ServiceNow URL: {servicenow_create_url}")
        logger.debug(f"ServiceNow Payload: {servicenow_payload}")

        response = requests.request("POST", servicenow_create_url, headers=headers, data=servicenow_payload)
        response.raise_for_status() # Raises HTTPError for bad responses (4xx or 5xx)

        servicenow_response_data = response.json()
        logger.info(f"ServiceNow response: {json.dumps(servicenow_response_data, indent=2)}")

        if "error" in servicenow_response_data:
            error_message = servicenow_response_data['error'].get('message', 'Unknown error from ServiceNow')
            error_detail = servicenow_response_data['error'].get('detail', '')
            logger.error(f"ServiceNow reported an application error: {error_message} - {error_detail}")
            raise HTTPException(
                status_code=response.status_code if response.status_code >= 400 else status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"ServiceNow API reported an error: {error_message} {error_detail}".strip()
            )

        return {
            "message": "ServiceNow request created successfully",
            "servicenow_response": servicenow_response_data
        }

    except requests.exceptions.HTTPError as http_err:
        logger.error(f"HTTP error occurred while creating ServiceNow request: {http_err}")
        logger.error(f"ServiceNow error response text: {response.text}")
        try:
            error_json = response.json()
            error_detail_msg = error_json.get('error', {}).get('message', 'No specific message from ServiceNow.')
            error_detail_more = error_json.get('error', {}).get('detail', '')
            detail_message = f"ServiceNow API HTTP Error: {error_detail_msg} {error_detail_more}".strip()
        except json.JSONDecodeError:
            detail_message = f"ServiceNow API HTTP Error: {response.text}"
        raise HTTPException(
            status_code=response.status_code,
            detail=detail_message
        )
    except requests.exceptions.ConnectionError as conn_err:
        logger.error(f"Connection error occurred with ServiceNow: {conn_err}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Could not connect to ServiceNow. Check URL or network connectivity."
        )
    except requests.exceptions.Timeout as timeout_err:
        logger.error(f"Timeout error occurred with ServiceNow: {timeout_err}")
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail="ServiceNow request timed out. The ServiceNow instance might be slow or unreachable."
        )
    except requests.exceptions.RequestException as req_err:
        logger.exception(f"An unexpected request error occurred with ServiceNow: {req_err}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An unexpected error occurred while making the request to ServiceNow: {req_err}"
        )
    except json.JSONDecodeError as json_err:
        logger.exception(f"JSON decode error from ServiceNow: {json_err}. Response text: {response.text}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Invalid JSON response from ServiceNow. Received: '{response.text[:100]}...'"
        )
    except Exception as e:
        logger.exception(f"An unexpected internal server error occurred in create-servicenow-request: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Internal server error: {e}")

async def get_workflow_details(workflow_id: str):
    """
    Fetches Workflow details from the 'workflow_configurations' table in Supabase.
    """
    try:
        response = supabase.from_('workflow_configurations').select('*').eq('automation_template_id', workflow_id).execute()
        wf_data = response.data

        if not wf_data:
            logger.warning("No workflow_configurations found in Supabase.")
            return None

        wf_tool = wf_data[0]

        wf_id = wf_tool.get('workflow_id')
        if not wf_id:
            logger.warning("workflow config found but 'workflow_id' is missing.")
            return None

        return wf_id
    except Exception as e:
        logger.exception(f"Error fetching ServiceNow credentials from Supabase: {e}")
        return None


@app.post("/update-servicenow-request") # Changed to POST to follow the existing pattern in your code, but for true RESTful UPDATE, it should be PUT /update-servicenow-request/{sys_id}
async def update_servicenow_request(
    request_payload: ServiceRequestUpdate,
    http_request: Request,
    username: str = Depends(authenticate_fastapi_user)
):
    """
    Receives a request to update a ServiceNow Service Request.
    Fetches ServiceNow credentials from Supabase and sends the request.
    This endpoint requires Basic Authentication.
    """
    logger.info(f"User '{username}' received request to update ServiceNow ticket with sys_id: {request_payload.sys_id}")
    logger.info(f"Update payload: {request_payload.snow_data}")

    servicenow_creds = await get_servicenow_credentials()

    if not servicenow_creds:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="ServiceNow configuration not found or incomplete in Supabase."
        )

    # IMPORTANT: For updating a ServiceNow record, the sys_id must be in the URL path.
    # The base_url is for the collection, so append the sys_id for the specific record.
    servicenow_update_url = f"{servicenow_creds['base_url']}/{request_payload.sys_id}"
    authorization_header = servicenow_creds["authorization_header"]

    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': authorization_header,
    }

    # The snow_data field should contain the fields you want to update
    servicenow_payload = json.dumps(request_payload.snow_data)


    try:
        logger.info(f"Sending PUT request to ServiceNow URL: {servicenow_update_url}")
        logger.debug(f"ServiceNow Update Payload: {servicenow_payload}")

        response = requests.request("PUT", servicenow_update_url, headers=headers, data=servicenow_payload)

        servicenow_response_data = response.json()
        logger.info(f"ServiceNow update response: {json.dumps(servicenow_response_data, indent=2)}")

        if "error" in servicenow_response_data:
            error_message = servicenow_response_data['error'].get('message', 'Unknown error from ServiceNow')
            error_detail = servicenow_response_data['error'].get('detail', '')
            logger.error(f"ServiceNow reported an application error during update: {error_message} - {error_detail}")
            raise HTTPException(
                status_code=response.status_code if response.status_code >= 400 else status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"ServiceNow API reported an error during update: {error_message} {error_detail}".strip()
            )

        return {
            "message": "ServiceNow request updated successfully",
            "servicenow_response": servicenow_response_data
        }

    except requests.exceptions.HTTPError as http_err:
        logger.error(f"HTTP error occurred while updating ServiceNow request: {http_err}")
        logger.error(f"ServiceNow error response text: {response.text}")
        try:
            error_json = response.json()
            error_detail_msg = error_json.get('error', {}).get('message', 'No specific message from ServiceNow.')
            error_detail_more = error_json.get('error', {}).get('detail', '')
            detail_message = f"ServiceNow API HTTP Error during update: {error_detail_msg} {error_detail_more}".strip()
        except json.JSONDecodeError:
            detail_message = f"ServiceNow API HTTP Error during update: {response.text}"
        raise HTTPException(
            status_code=response.status_code,
            detail=detail_message
        )
    except requests.exceptions.ConnectionError as conn_err:
        logger.error(f"Connection error occurred with ServiceNow during update: {conn_err}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Could not connect to ServiceNow for update. Check URL or network connectivity."
        )
    except requests.exceptions.Timeout as timeout_err:
        logger.error(f"Timeout error occurred with ServiceNow during update: {timeout_err}")
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail="ServiceNow update request timed out. The ServiceNow instance might be slow or unreachable."
        )
    except requests.exceptions.RequestException as req_err:
        logger.exception(f"An unexpected request error occurred with ServiceNow during update: {req_err}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An unexpected error occurred while making the update request to ServiceNow: {req_err}"
        )
    except json.JSONDecodeError as json_err:
        logger.exception(f"JSON decode error from ServiceNow during update: {json_err}. Response text: {response.text}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Invalid JSON response from ServiceNow during update. Received: '{response.text[:100]}...'"
        )
    except Exception as e:
        logger.exception(f"An unexpected internal server error occurred in update-servicenow-request: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Internal server error: {e}")



@app.post("/trigger-git-action")
async def trigger_git_action(
    request_payload: GitPayload,
    http_request: Request,
    username: str = Depends(authenticate_fastapi_user) # Add this dependency for authentication
):
    """
    Receives a request to create a ServiceNow Service Request.
    Fetches ServiceNow credentials from Supabase and sends the request.
    This endpoint requires Basic Authentication.
    """
    print(f"Authenticated user '{username}' received request to run git workflow: {request_payload.automationData}")


    try:
        workflow_ID = await get_workflow_details(request_payload.workflowID)

        print(f"\n Workflow ID: {workflow_ID}")
        url = f"https://api.github.com/repos/SharpTechIT/SOTAF/actions/workflows/{workflow_ID}/dispatches"
        #
        # url = "https://api.github.com/repos/SharpTechIT/SOTAF/actions/workflows/169878977/dispatches"

        payload = json.dumps({
            "ref": "main",
            "inputs": {
                "automationData": str(json.dumps(request_payload.automationData)),
                "servicenowData": str(json.dumps(request_payload.servicenowData))
            }
        })
        headers = {
            'Accept': 'application/vnd.github+json',
            'Authorization': 'Bearer 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',
            'Content-Type': 'application/json'
        }

        print(f"Git payload: {payload} \n headers: {headers}")
        logging.info(f"Git payload: {payload} \n headers: {headers}")
        response = requests.request("POST", url, headers=headers, data=payload)

        print(response.text)
    except Exception as e:
        print(f"An unexpected internal server error occurred: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Internal server error: {e}")


@app.post("/send-email-notification")
async def create_servicenow_request(
    request_payload: EmailNotificationPayload,
    http_request: Request,
    username: str = Depends(authenticate_fastapi_user)
):
    """
    Receives a request to create a ServiceNow Service Request.
    Fetches ServiceNow credentials from Supabase and sends the request.
    This endpoint requires Basic Authentication.
    """
    logger.info(f"User '{username}' received request to send email to : {request_payload.mail_id}")
    try:

        logger.info(f"Mail body: {request_payload.mail_body}")
        email_id = request_payload.mail_id
        email_body = json.dumps(request_payload.mail_body)
        SendGmailNotification(email_id, email_body)
        return {"message": "✅ Email sent successfully."}

    except Exception as e:
        print(f"An unexpected internal server error occurred: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Internal server error: {e}")
# This block allows you to run the app directly using 'python your_app_name.py'



from TerraformAgent.main import run_workflow, UserRequestPayload

@app.post("/invoke-agent")
async def trigger_agent(
        request_payload: UserRequestPayload,
        http_request: Request
):
    """
    This is the main endpoint that the Streamlit UI calls to start the agent workflow.
    """
    try:
        print(f"Received request to trigger agent for: {request_payload.user_query}")
        # The workflow runs in the background. The UI will interact via the webhook.
        run_workflow(request_payload.user_query, request_payload.sessionId)
        return {
            "message": "Successfully triggered AI agent workflow. The agent will ask questions in the chat if more information is needed."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("SharptechAPIServer:app", host="0.0.0.0", port=8000, reload=True) # Assuming your file is named 'main.py'

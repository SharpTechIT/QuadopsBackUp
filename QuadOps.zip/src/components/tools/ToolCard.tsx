import React from 'react';
import { Edit, Trash2, CheckCircle, XCircle, Clock, Shield } from 'lucide-react';
import { Tool } from '../../types';
import { hasEncryptedFields } from '../../utils/toolEncryption';

interface ToolCardProps {
  tool: Tool;
  onEdit: (tool: Tool) => void;
  onDelete: (tool: Tool) => void;
  onStatusChange: (tool: Tool, newStatus: 'active' | 'inactive' | 'error') => void;
}

const statusIcons = {
  active: CheckCircle,
  inactive: XCircle,
  error: Clock,
};

const statusColors = {
  active: 'text-green-600 bg-green-100 dark:text-green-400 dark:bg-green-900/50',
  inactive: 'text-gray-600 bg-gray-100 dark:text-gray-400 dark:bg-gray-700',
  error: 'text-red-600 bg-red-100 dark:text-red-400 dark:bg-red-900/50',
};

export const ToolCard: React.FC<ToolCardProps> = ({ tool, onEdit, onDelete, onStatusChange }) => {
  const StatusIcon = statusIcons[tool.status];
  const providerKey = tool.provider.toLowerCase().replace(' ', '_');
  const isEncrypted = hasEncryptedFields(providerKey, tool.config);

  const handleStatusChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const newStatus = event.target.value as 'active' | 'inactive' | 'error';
    onStatusChange(tool, newStatus);
  };
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
      <div className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-2">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">{tool.name}</h3>
              {isEncrypted && (
                <Shield className="h-4 w-4 text-green-600 dark:text-green-400"/>
              )}
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 capitalize">
              {tool.type.replace('_', ' ')} • {tool.provider}
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <StatusIcon className={`h-4 w-4 ${
              tool.status === 'active' ? 'text-green-600 dark:text-green-400' :
              tool.status === 'inactive' ? 'text-gray-600 dark:text-gray-400' :
              'text-red-600 dark:text-red-400'
            }`} />
            <select
              value={tool.status}
              onChange={handleStatusChange}
              className={`text-xs font-medium rounded px-2 py-1 border-0 focus:ring-2 focus:ring-blue-500 ${statusColors[tool.status]}`}
            >
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="error">Error</option>
            </select>
          </div>
        </div>
        
        <div className="mt-4 flex justify-end space-x-2">
          <button
            onClick={() => onEdit(tool)}
            className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-600 shadow-sm text-sm font-medium rounded text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Edit className="h-3 w-3 mr-1" />
            Edit
          </button>
          <button
            onClick={() => onDelete(tool)}
            className="inline-flex items-center px-3 py-1.5 border border-red-300 dark:border-red-600 shadow-sm text-sm font-medium rounded text-red-700 dark:text-red-400 bg-white dark:bg-gray-700 hover:bg-red-50 dark:hover:bg-red-900/20 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
          >
            <Trash2 className="h-3 w-3 mr-1" />
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};
provider "aws" {
  region = var.aws_region
}

# ------------------------------
# Conditional VPC Creation
# ------------------------------
resource "aws_vpc" "this" {
  count             = var.resource_selection_type == "new" ? 1 : 0
  cidr_block        = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true
  tags = {
    Name = "fargate-vpc"
  }
}

# Fetch existing VPC if needed
data "aws_vpc" "existing" {
  count = var.resource_selection_type == "existing" ? 1 : 0
  id    = var.existing_vpc_id
}

# ------------------------------
# Conditional Subnet Creation
# ------------------------------
resource "aws_subnet" "this" {
  count             = var.resource_selection_type == "new" ? 2 : 0
  vpc_id            = aws_vpc.this[0].id
  cidr_block        = cidrsubnet("10.0.0.0/16", 8, count.index)
  availability_zone = element(data.aws_availability_zones.available.names, count.index)
  map_public_ip_on_launch = true
  tags = {
    Name = "fargate-subnet-${count.index}"
  }
}

# Fetch existing Subnets
data "aws_subnet" "existing" {
  count = var.resource_selection_type == "existing" ? length(var.existing_subnet_ids) : 0
  id    = var.existing_subnet_ids[count.index]
}

# ------------------------------
# Security Group
# ------------------------------
resource "aws_security_group" "this" {
  count  = var.resource_selection_type == "new" ? 1 : 0
  name   = "fargate-sg"
  vpc_id = aws_vpc.this[0].id

  ingress {
    from_port   = var.container_port
    to_port     = var.container_port
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"] # Can restrict further for security
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

data "aws_security_group" "existing" {
  count = var.resource_selection_type == "existing" ? 1 : 0
  id    = var.existing_sg_id
}

# ------------------------------
# IAM Role
# ------------------------------
resource "aws_iam_role" "task_role" {
  count = var.resource_selection_type == "new" ? 1 : 0
  name  = "fargate-task-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17",
    Statement = [{
      Effect    = "Allow",
      Principal = { Service = "ecs-tasks.amazonaws.com" },
      Action    = "sts:AssumeRole"
    }]
  })
}

data "aws_iam_role" "existing" {
  count = var.resource_selection_type == "existing" ? 1 : 0
  arn   = var.existing_task_role_arn
}

# ------------------------------
# Locals for Unified Resource References
# ------------------------------
locals {
  vpc_id    = var.resource_selection_type == "new" ? aws_vpc.this[0].id : data.aws_vpc.existing[0].id
  subnet_ids = var.resource_selection_type == "new" ? aws_subnet.this[*].id : var.existing_subnet_ids
  sg_id      = var.resource_selection_type == "new" ? aws_security_group.this[0].id : data.aws_security_group.existing[0].id
  task_role_arn = var.resource_selection_type == "new" ? aws_iam_role.task_role[0].arn : data.aws_iam_role.existing[0].arn
}

# ------------------------------
# ECS Cluster
# ------------------------------
resource "aws_ecs_cluster" "this" {
  name = var.ecs_cluster_name
}

# Task Definition
resource "aws_ecs_task_definition" "this" {
  family                   = var.fargate_service_name
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = "256"
  memory                   = "512"
  execution_role_arn       = local.task_role_arn
  container_definitions = jsonencode([{
    name      = var.fargate_service_name
    image     = var.container_image
    essential = true
    portMappings = [{
      containerPort = var.container_port
      hostPort      = var.container_port
    }]
  }])
}

# ECS Service
resource "aws_ecs_service" "this" {
  name            = var.fargate_service_name
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.this.arn
  desired_count   = 1
  launch_type     = "FARGATE"

  network_configuration {
    subnets         = local.subnet_ids
    security_groups = [local.sg_id]
    assign_public_ip = true
  }
}

import React from 'react';

interface ProviderSelectorProps {
    type: 'notification' | 'itsm' | 'version_control' | 'cloud_provider';
    onSelectProvider: (provider: string) => void;
    onBack: () => void;
}

export const ProviderSelector: React.FC<ProviderSelectorProps> = ({ type, onSelectProvider, onBack }) => {
    const providers = {
        notification: [
            { id: 'slack', name: 'Slack', logo: '/Slack-logo.png' },
            { id: 'email', name: 'Email', logo: null },
        ],
        itsm: [
            { id: 'servicenow', name: 'ServiceNow', logo: '/servicenow-logo.jpg' },
            { id: 'jira', name: 'Jira', logo: null },
        ],
        version_control: [
            { id: 'github', name: 'GitHub', logo: '/github.png' },
            { id: 'azure_devops', name: 'Azure DevOps', logo: '/AzureDevops.png' },
        ],
        cloud_provider: [
            { id: 'azure', name: 'Microsoft Azure', logo: null },
            { id: 'aws', name: 'Amazon Web Services', logo: null },
            { id: 'gcp', name: 'Google Cloud Platform', logo: '/gcp.png' },
        ],
    };

    const typeNames = {
        notification: 'Notification',
        itsm: 'ITSM',
        version_control: 'Version Control',
        cloud_provider: 'Cloud Provider',
    };

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-20 mx-auto p-5 border w-2/3 max-w-2xl shadow-lg rounded-md bg-white dark:bg-gray-800">
                <div className="mt-3">
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-6 text-center">
                        Select {typeNames[type]} Provider
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {providers[type].map((provider) => (
                            <div
                                key={provider.id}
                                onClick={() => onSelectProvider(provider.id)}
                                className="bg-white dark:bg-gray-700 rounded-lg shadow-sm border border-gray-200 dark:border-gray-600 hover:shadow-md transition-all duration-200 cursor-pointer hover:scale-105 p-6"
                            >
                                <div className="flex flex-col items-center text-center">
                                    {provider.logo ? (
                                        <div className="mb-4">
                                            <img
                                                src={provider.logo}
                                                alt={provider.name}
                                                className="h-16 w-auto object-contain"
                                            />
                                        </div>
                                    ) : (
                                        <div className="p-4 rounded-lg bg-gray-100 dark:bg-gray-600 text-gray-600 dark:text-gray-300 mb-4">
                                            <div className="h-8 w-8 flex items-center justify-center text-lg font-bold">
                                                {provider.name.charAt(0)}
                                            </div>
                                        </div>
                                    )}
                                    <h4 className="text-lg font-medium text-gray-900 dark:text-white">
                                        {provider.name}
                                    </h4>
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="mt-6 flex justify-center space-x-2">
                        <button
                            onClick={onBack}
                            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                        >
                            Back
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};
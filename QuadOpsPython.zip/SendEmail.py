# import smtplib
# from email.mime.text import MIMEText
# from email.mime.multipart import MIMEMultipart
#
# # Sender and recipient
# sender_email = "sharptechgenai@gmail.com"
# receiver_email = "cloudautomationninja@gmail.com"
# app_password = "wlmczskuvhaznxua"  # App password from Step 1
#
# # Email content
# subject = "Test Email from Python"
# body = "This is a test email sent using Gmail and Python."
#
# # Construct message
# message = MIMEMultipart()
# message["From"] = sender_email
# message["To"] = receiver_email
# message["Subject"] = subject
#
# message.attach(MIMEText(body, "plain"))
#
# # Send via Gmail SMTP
# try:
#     with smtplib.SMTP("smtp.gmail.com", 587) as server:
#         server.starttls()  # Secure the connection
#         server.login(sender_email, app_password)
#         server.sendmail(sender_email, receiver_email, message.as_string())
#     print("✅ Email sent successfully.")
# except Exception as e:
#     print(f"❌ Error sending email: {e}")

from SendEmailWithAttachment import SendGmailNotification
import json

emailid = "Arjun.Mehta@878tdk.onmicrosoft.com"
jsonmail = {
        "tower": "azure",
        "form_data": {"name": "test", "location": "yrdy"},
        "automation_name": "Storage creation",
        "automation_type": "Storgae",
        "servicenow_error": None,
        "servicenow_request": {
            "state": "1",
            "sys_id": "c19ebe13831e6a50193315a6feaad305",
            "request_id": "c19ebe13831e6a50193315a6feaad305",
            "request_number": "REQ0010045"
        }
    }
SendGmailNotification(emailid, json.dumps(jsonmail))
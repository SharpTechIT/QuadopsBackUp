import React, { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import { ToolCard } from '../components/tools/ToolCard';
import { ToolTypeSelector } from '../components/tools/ToolTypeSelector';
import { ProviderSelector } from '../components/tools/ProviderSelector';
import { ToolConfigForm } from '../components/tools/ToolConfigForm';
import { Tool } from '../types';
import { supabase } from '../config/supabase';

type ModalStep = 'type' | 'provider' | 'config';

export const Tools: React.FC = () => {
    const [tools, setTools] = useState<Tool[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [modalStep, setModalStep] = useState<ModalStep>('type');
    const [selectedType, setSelectedType] = useState<'notification' | 'itsm' | 'version_control' | 'cloud_provider' | null>(null);
    const [selectedProvider, setSelectedProvider] = useState<string>('');
    const [editingTool, setEditingTool] = useState<Tool | null>(null);

    useEffect(() => {
        fetchTools();
    }, []);

    const fetchTools = async () => {
        try {
            const { data, error } = await supabase
                .from('tools')
                .select('*')
                .order('created_at', { ascending: false });

            if (error) throw error;
            setTools(data || []);
        } catch (error) {
            console.error('Error fetching tools:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleAddTool = () => {
        setEditingTool(null);
        setSelectedType(null);
        setSelectedProvider('');
        setModalStep('type');
        setShowModal(true);
    };

    const handleEditTool = (tool: Tool) => {
        console.log('Editing tool:', tool); // Debug log
        setEditingTool(tool);
        setSelectedType(tool.type as any);
        // Map provider names correctly
        const providerMap: Record<string, string> = {
            'ServiceNow': 'servicenow',
            'Jira': 'jira',
            'GitHub': 'github',
            'Azure DevOps': 'azure_devops',
            'Slack': 'slack',
            'Email': 'email'
        };
        setSelectedProvider(providerMap[tool.provider] || tool.provider.toLowerCase().replace(' ', '_'));
        setModalStep('config');
        setShowModal(true);
    };

    const handleDeleteTool = async (tool: Tool) => {
        if (window.confirm(`Are you sure you want to delete ${tool.name}?`)) {
            try {
                const { error } = await supabase
                    .from('tools')
                    .delete()
                    .eq('id', tool.id);

                if (error) throw error;

                // Refresh tools list
                await fetchTools();
            } catch (error) {
                console.error('Error deleting tool:', error);
                alert('Error deleting tool. Please try again.');
            }
        }
    };

    const handleStatusChange = async (tool: Tool, newStatus: 'active' | 'inactive' | 'error') => {
        try {
            const { error } = await supabase
                .from('tools')
                .update({ status: newStatus })
                .eq('id', tool.id);

            if (error) throw error;
            await fetchTools();
        } catch (err) {
            console.error('Error updating tool status:', err);
        }
    };

    const handleSelectType = (type: 'notification' | 'itsm' | 'version_control' | 'cloud_provider') => {
        setSelectedType(type);
        setModalStep('provider');
    };

    const handleSelectProvider = (provider: string) => {
        setSelectedProvider(provider);
        setModalStep('config');
    };

    const handleConfigSubmit = async (data: any) => {
        try {
            if (editingTool) {
                // Update existing tool
                const { error } = await supabase
                    .from('tools')
                    .update({
                        name: data.name,
                        config: data.config,
                        updated_at: new Date().toISOString()
                    })
                    .eq('id', editingTool.id);

                if (error) throw error;
            } else {
                // Add new tool
                const { error } = await supabase
                    .from('tools')
                    .insert([{
                        type: data.type,
                        name: data.name,
                        provider: data.provider,
                        config: data.config,
                        status: 'active'
                    }]);

                if (error) throw error;
            }

            // Refresh tools list
            await fetchTools();
            setShowModal(false);
        } catch (error) {
            console.error('Error saving tool:', error);
            alert('Error saving tool. Please try again.');
        }
    };

    const handleCloseModal = () => {
        setShowModal(false);
        setSelectedType(null);
        setSelectedProvider('');
        setModalStep('type');
        setEditingTool(null);
    };

    const handleBackStep = () => {
        if (modalStep === 'provider') {
            setModalStep('type');
            setSelectedType(null);
        } else if (modalStep === 'config') {
            if (editingTool) {
                handleCloseModal();
            } else {
                setModalStep('provider');
                setSelectedProvider('');
            }
        }
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Tools Configuration</h1>
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                        Configure integration tools for workflows and notifications
                    </p>
                </div>
                <button
                    onClick={handleAddTool}
                    className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Tool
                </button>
            </div>

            {/* Tools Grid */}
            {tools.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {tools.map((tool) => (
                        <ToolCard
                            key={tool.id}
                            tool={tool}
                            onEdit={handleEditTool}
                            onDelete={handleDeleteTool}
                            onStatusChange={handleStatusChange}
                        />
                    ))}
                </div>
            ) : (
                <div className="text-center py-12">
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">No tools configured</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                        Add your first tool to start integrating with external systems
                    </p>
                </div>
            )}

            {/* Modals */}
            {showModal && modalStep === 'type' && (
                <ToolTypeSelector
                    onSelectType={handleSelectType}
                    onClose={handleCloseModal}
                />
            )}

            {showModal && modalStep === 'provider' && selectedType && (
                <ProviderSelector
                    type={selectedType}
                    onSelectProvider={handleSelectProvider}
                    onBack={handleBackStep}
                />
            )}

            {showModal && modalStep === 'config' && selectedType && selectedProvider && (
                <ToolConfigForm
                    type={selectedType}
                    provider={selectedProvider}
                    editingTool={editingTool}
                    onSubmit={handleConfigSubmit}
                    onBack={handleBackStep}
                    onClose={handleCloseModal}
                />
            )}
        </div>
    );
};

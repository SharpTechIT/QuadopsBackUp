# This is a conceptual example for sending email via Microsoft Graph API using OAuth 2.0
# It requires proper setup in Azure AD for application registration and permissions.
# For a full implementation, you'd use a library like 'msal' or handle OAuth flow.
import os
import requests
import json
from dotenv import load_dotenv

from jinja2 import Template

# Load environment variables from .env file
load_dotenv()
CLIENT_ID = os.getenv('CLIENT_ID')
CLIENT_SECRET = os.getenv('CLIENT_SECRET')
TENANT_ID = os.getenv('TENANT_ID')
AUTHORITY = f"https://login.microsoftonline.com/{TENANT_ID}"
SCOPE = ["https://graph.microsoft.com/.default"]
MAIL_USERNAME = os.getenv('MAIL_USERNAME')

# Function to get an access token (simplified for demonstration)
def get_access_token():
    url = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    data = {
        "client_id": CLIENT_ID,
        "scope": "https://graph.microsoft.com/.default", # Or "https://graph.microsoft.com/Mail.Send"
        "client_secret": CLIENT_SECRET,
        "grant_type": "client_credentials" # For daemon apps (no user interaction)
        # For delegated permissions (user interaction), you'd use authorization_code flow
    }
    response = requests.post(url, headers=headers, data=data)
    response.raise_for_status()
    return response.json()["access_token"]

# Load and customize HTML template
def generate_html_template(data):
    # HTML Template using Jinja2
    html_template = """
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body {
          background-color: #f1f4f8;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          margin: 0;
          padding: 20px;
        }
        .container {
          max-width: 600px;
          margin: auto;
          background-color: #ffffff;
          border-radius: 8px;
          box-shadow: 0 0 10px rgba(0,0,0,0.08);
          padding: 30px;
        }
        .header {
          border-bottom: 2px solid #0078d4;
          padding-bottom: 10px;
          margin-bottom: 20px;
        }
        .header h1 {
          color: #0078d4;
          font-size: 24px;
          margin: 0;
        }
        .body {
          font-size: 16px;
          color: #333333;
        }
        .body p {
          margin-bottom: 15px;
        }
        .details {
          background-color: #f9f9f9;
          border-radius: 6px;
          padding: 15px;
          margin-top: 10px;
          font-size: 15px;
        }
        .details p {
          margin: 6px 0;
        }
        .details span {
          font-weight: bold;
          color: #444;
        }
        .footer {
          margin-top: 25px;
          font-size: 13px;
          color: #777;
          border-top: 1px solid #ddd;
          padding-top: 10px;
          text-align: center;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>✅ {{ automation_name }} Completed Successfully</h1>
        </div>

        <div class="body">
          <p>Hi <strong>User</strong>,</p>
          <p>
            The automation for <strong>{{ automation_name }}</strong> in <strong>{{ tower }}</strong> has been completed successfully by SharTech bot.
            Below are the submitted details:
          </p>

          <div class="details">
            {% for key, value in form_data.items() %}
              <p><span>{{ key | replace("_", " ") | title }}:</span> {{ value }}</p>
            {% endfor %}
          </div>

          <p>
            ServiceNow Request Number: <a href="https://dev206438.service-now.com/nav_to.do?uri=sc_request.do?sys_id={{ servicenow_request.sys_id }}"><strong>{{ servicenow_request.request_number }}</strong></a>
          </p>
        </div>

        <div class="footer">
          © 2025 IT Automation | Generic Automation System
        </div>
      </div>
    </body>
    </html>
    """

    # Render HTML
    template = Template(html_template)
    html_output = template.render(
        tower=data["tower"],
        form_data=data["form_data"],
        automation_name=data["automation_name"],
        servicenow_request=data["servicenow_request"]
    )

    # Save or send email using this HTML
    return html_output


def send_email_graph_api(recipient_email, mail_details):

    mail_details_json=json.loads(mail_details)
    access_token = get_access_token()
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    html_content = generate_html_template(mail_details_json) # Reuse your existing template function

    email_message = {
        "message": {
            "subject": f"✅ SharpTech Automation : {mail_details_json['automation_name']}",
            "body": {
                "contentType": "Html",
                "content": html_content
            },
            "toRecipients": [
                {
                    "emailAddress": {
                        "address": recipient_email
                    }
                }
            ]
        },
        "saveToSentItems": "true"
    }
    O365_SENDER_EMAIL="sharptech@878tdk.onmicrosoft.com"
    # The 'from' address is typically the user associated with the access token.
    # If sending "on behalf of" another user, additional Graph API permissions are needed.
    send_mail_url = f"https://graph.microsoft.com/v1.0/users/{O365_SENDER_EMAIL}/sendMail" # O365_SENDER_EMAIL is the user sending the mail

    try:
        response = requests.post(send_mail_url, headers=headers, json=email_message)
        response.raise_for_status() # Raise an exception for HTTP errors (4xx or 5xx)
        print("✅ Email sent successfully via Microsoft Graph API.")
    except requests.exceptions.HTTPError as err:
        print(f"❌ Failed to send email via Graph API: {err}")
        print(f"Response: {response.json()}")
    except Exception as e:
        print(f"❌ An unexpected error occurred: {e}")

# You would call send_email_graph_api instead of SendO365Notification
# Example: send_email_graph_api(recipient_email, mail_details_json)


emailid = "sharptech@878tdk.onmicrosoft.com"
jsonmail = {
        "tower": "azure",
        "form_data": {"name": "test", "location": "yrdy"},
        "automation_name": "Storage creation",
        "automation_type": "Storgae",
        "servicenow_error": None,
        "servicenow_request": {
            "state": "1",
            "sys_id": "c19ebe13831e6a50193315a6feaad305",
            "request_id": "c19ebe13831e6a50193315a6feaad305",
            "request_number": "REQ0010045"
        }
    }
send_email_graph_api(emailid, json.dumps(jsonmail))
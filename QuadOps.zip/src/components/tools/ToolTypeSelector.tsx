import React from 'react';
import { MessageSquare, Ticket, GitBranch, Cloud } from 'lucide-react';

interface ToolTypeSelectorProps {
    onSelectType: (type: 'notification' | 'itsm' | 'version_control' | 'cloud_provider') => void;
    onClose: () => void;
}

export const ToolTypeSelector: React.FC<ToolTypeSelectorProps> = ({ onSelectType, onClose }) => {
    const toolTypes = [
        {
            id: 'notification' as const,
            name: 'Notification',
            description: 'Communication channels like Slack or Email',
            icon: MessageSquare,
            color: 'bg-green-500',
        },
        {
            id: 'itsm' as const,
            name: 'ITSM',
            description: 'Service management tools like ServiceNow or Jira',
            icon: Ticket,
            color: 'bg-blue-500',
        },
        {
            id: 'version_control' as const,
            name: 'Version Control',
            description: 'Git repositories or Azure DevOps',
            icon: GitBranch,
            color: 'bg-purple-500',
        },
        {
            id: 'cloud_provider' as const,
            name: 'Cloud Provider',
            description: 'Azure, AWS, GCP for dynamic data sources',
            icon: Cloud,
            color: 'bg-orange-500',
        },
    ];

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-20 mx-auto p-5 border w-2/3 max-w-2xl shadow-lg rounded-md bg-white dark:bg-gray-800">
                <div className="mt-3">
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-6 text-center">
                        Select Tool Type
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {toolTypes.map((type) => (
                            <div
                                key={type.id}
                                onClick={() => onSelectType(type.id)}
                                className="bg-white dark:bg-gray-700 rounded-lg shadow-sm border border-gray-200 dark:border-gray-600 hover:shadow-md transition-all duration-200 cursor-pointer hover:scale-105 p-6"
                            >
                                <div className="flex flex-col items-center text-center">
                                    <div className={`p-4 rounded-lg ${type.color} text-white mb-4`}>
                                        <type.icon className="h-8 w-8" />
                                    </div>
                                    <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                                        {type.name}
                                    </h4>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">
                                        {type.description}
                                    </p>
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="mt-6 flex justify-center">
                        <button
                            onClick={onClose}
                            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                        >
                            Cancel
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
    Repeat,
    Ticket,
    CheckCircle,
    XCircle,
    TrendingUp
} from 'lucide-react';
import { MetricCard } from '../components/dashboard/MetricCard';
import { WorkflowRunsList } from '../components/dashboard/WorkflowRunsList';
import { TicketsList } from '../components/dashboard/TicketsList';
import { DashboardMetrics, WorkflowRun, Ticket as TicketType } from '../types';
import { supabase } from '../config/supabase';

export const Dashboard: React.FC = () => {
    const navigate = useNavigate();
    const [metrics, setMetrics] = useState<DashboardMetrics>({
        total_workflows: 0,
        successful_workflows: 0,
        failed_workflows: 0,
        pending_workflows: 0,
        total_tickets: 0,
        open_tickets: 0,
        resolved_tickets: 0,
    });

    const [previousMetrics, setPreviousMetrics] = useState<DashboardMetrics>({
        total_workflows: 0,
        successful_workflows: 0,
        failed_workflows: 0,
        pending_workflows: 0,
        total_tickets: 0,
        open_tickets: 0,
        resolved_tickets: 0,
    });

    const [recentRuns, setRecentRuns] = useState<WorkflowRun[]>([]);
    const [recentTickets, setRecentTickets] = useState<TicketType[]>([]);
    const [showWorkflowModal, setShowWorkflowModal] = useState(false);
    const [selectedRun, setSelectedRun] = useState<WorkflowRun | null>(null);

    useEffect(() => {
        fetchDashboardData();
    }, []);

    const fetchDashboardData = async () => {
        try {
            // Get current date and last month date
            const currentDate = new Date();
            const lastMonthDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1);
            const currentMonthStart = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);

            // Fetch current month workflow runs
            const { data: currentWorkflowRuns, error: currentWorkflowError } = await supabase
                .from('workflow_runs')
                .select('*')
                .gte('created_at', currentMonthStart.toISOString())
                .order('created_at', { ascending: false });

            if (currentWorkflowError) throw currentWorkflowError;

            // Fetch last month workflow runs
            const { data: lastMonthWorkflowRuns, error: lastMonthWorkflowError } = await supabase
                .from('workflow_runs')
                .select('*')
                .gte('created_at', lastMonthDate.toISOString())
                .lt('created_at', currentMonthStart.toISOString());

            if (lastMonthWorkflowError) throw lastMonthWorkflowError;

            // Fetch current month tickets
            const { data: currentTickets, error: currentTicketError } = await supabase
                .from('tickets')
                .select('*')
                .gte('created_at', currentMonthStart.toISOString())
                .order('created_at', { ascending: false });

            if (currentTicketError) throw currentTicketError;

            // Fetch last month tickets
            const { data: lastMonthTickets, error: lastMonthTicketError } = await supabase
                .from('tickets')
                .select('*')
                .gte('created_at', lastMonthDate.toISOString())
                .lt('created_at', currentMonthStart.toISOString());

            if (lastMonthTicketError) throw lastMonthTicketError;

            // Fetch all workflow runs for recent list
            const { data: allWorkflowRuns, error: allWorkflowError } = await supabase
                .from('workflow_runs')
                .select('*')
                .order('created_at', { ascending: false })
                .limit(10);

            if (allWorkflowError) throw allWorkflowError;
            setRecentRuns(allWorkflowRuns || []);

            // Fetch all tickets for recent list
            const { data: allTickets, error: allTicketError } = await supabase
                .from('tickets')
                .select('*')
                .order('created_at', { ascending: false })
                .limit(10);

            if (allTicketError) throw allTicketError;
            setRecentTickets(allTickets || []);

            // Calculate current metrics
            const currentWorkflows = currentWorkflowRuns || [];
            const currentTicketsData = currentTickets || [];

            const currentSuccessfulWorkflows = currentWorkflows.filter(w => w.status === 'success').length;
            const currentFailedWorkflows = currentWorkflows.filter(w => w.status === 'failed').length;
            const currentPendingWorkflows = currentWorkflows.filter(w => w.status === 'pending').length;
            const currentOpenTickets = currentTicketsData.filter(t => ['open', 'pending_approval'].includes(t.status)).length;
            const currentResolvedTickets = currentTicketsData.filter(t => ['resolved', 'approved'].includes(t.status)).length;

            const currentMetrics = {
                total_workflows: currentWorkflows.length,
                successful_workflows: currentSuccessfulWorkflows,
                failed_workflows: currentFailedWorkflows,
                pending_workflows: currentPendingWorkflows,
                total_tickets: currentTicketsData.length,
                open_tickets: currentOpenTickets,
                resolved_tickets: currentResolvedTickets,
            };

            // Calculate previous metrics
            const lastMonthWorkflows = lastMonthWorkflowRuns || [];
            const lastMonthTicketsData = lastMonthTickets || [];

            const lastMonthSuccessfulWorkflows = lastMonthWorkflows.filter(w => w.status === 'success').length;
            const lastMonthFailedWorkflows = lastMonthWorkflows.filter(w => w.status === 'failed').length;
            const lastMonthPendingWorkflows = lastMonthWorkflows.filter(w => w.status === 'pending').length;
            const lastMonthOpenTickets = lastMonthTicketsData.filter(t => ['open', 'pending_approval'].includes(t.status)).length;
            const lastMonthResolvedTickets = lastMonthTicketsData.filter(t => ['resolved', 'approved'].includes(t.status)).length;

            const previousMetricsData = {
                total_workflows: lastMonthWorkflows.length,
                successful_workflows: lastMonthSuccessfulWorkflows,
                failed_workflows: lastMonthFailedWorkflows,
                pending_workflows: lastMonthPendingWorkflows,
                total_tickets: lastMonthTicketsData.length,
                open_tickets: lastMonthOpenTickets,
                resolved_tickets: lastMonthResolvedTickets,
            };

            setMetrics(currentMetrics);
            setPreviousMetrics(previousMetricsData);

        } catch (error) {
            console.error('Error fetching dashboard data:', error);
            // Keep default values if fetch fails
        }
    };

    // Calculate trend percentages
    const calculateTrend = (current: number, previous: number): { value: number; label: string } => {
        if (previous === 0) {
            return current > 0 ? { value: 100, label: 'vs last month' } : { value: 0, label: 'vs last month' };
        }
        const percentage = Math.round(((current - previous) / previous) * 100);
        return { value: percentage, label: 'vs last month' };
    };

    const handleViewWorkflowDetails = (run: WorkflowRun) => {
        setSelectedRun(run);
        setShowWorkflowModal(true);
    };

    const handleViewAllWorkflows = () => {
        navigate('/workflows');
    };

    const handleViewAllTickets = () => {
        navigate('/tickets');
    };

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    Monitor your automation workflows and system performance
                </p>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <MetricCard
                    title="Total Workflows"
                    value={metrics.total_workflows}
                    icon={Repeat}
                    color="blue"
                    trend={calculateTrend(metrics.total_workflows, previousMetrics.total_workflows)}
                    onClick={() => setShowWorkflowModal(true)}
                />
                <MetricCard
                    title="Successful"
                    value={metrics.successful_workflows}
                    icon={CheckCircle}
                    color="green"
                    trend={calculateTrend(metrics.successful_workflows, previousMetrics.successful_workflows)}
                />
                <MetricCard
                    title="Failed"
                    value={metrics.failed_workflows}
                    icon={XCircle}
                    color="red"
                    trend={calculateTrend(metrics.failed_workflows, previousMetrics.failed_workflows)}
                />
                <MetricCard
                    title="Total Tickets"
                    value={metrics.total_tickets}
                    icon={Ticket}
                    color="purple"
                    trend={calculateTrend(metrics.total_tickets, previousMetrics.total_tickets)}
                />
            </div>

            {/* Charts and Lists */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <WorkflowRunsList
                    runs={recentRuns}
                    onViewDetails={handleViewWorkflowDetails}
                    onViewAll={handleViewAllWorkflows}
                />
                <TicketsList
                    tickets={recentTickets}
                    onViewAll={handleViewAllTickets}
                />
            </div>

            {/* Success Rate Chart */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">Workflow Success Rate</h3>
                    <TrendingUp className="h-5 w-5 text-green-500" />
                </div>
                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Success Rate</span>
                        <span className="text-sm font-medium text-green-600 dark:text-green-400">
                            {metrics.total_workflows > 0
                                ? ((metrics.successful_workflows / metrics.total_workflows) * 100).toFixed(1)
                                : 0}%
                        </span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div
                            className="bg-green-500 h-2 rounded-full"
                            style={{
                                width: `${metrics.total_workflows > 0
                                    ? (metrics.successful_workflows / metrics.total_workflows) * 100
                                    : 0}%`,
                            }}
                        />
                    </div>
                </div>
            </div>

            {/* Workflow Details Modal */}
            {showWorkflowModal && selectedRun && (
                <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
                    <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white dark:bg-gray-800">
                        <div className="mt-3">
                            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                                Workflow Details
                            </h3>
                            <div className="space-y-3">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
                                    <p className="text-sm text-gray-900 dark:text-white">{selectedRun.workflow_name}</p>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
                                    <p className={`text-sm font-medium ${selectedRun.status === 'success' ? 'text-green-600 dark:text-green-400' :
                                            selectedRun.status === 'failed' ? 'text-red-600 dark:text-red-400' : 'text-yellow-600 dark:text-yellow-400'
                                        }`}>
                                        {selectedRun.status.toUpperCase()}
                                    </p>
                                </div>
                                {selectedRun.ticket_number && (
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Ticket</label>
                                        <p className="text-sm text-gray-900 dark:text-white">{selectedRun.ticket_number}</p>
                                    </div>
                                )}
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Form Data</label>
                                    <pre className="text-xs bg-gray-100 dark:bg-gray-700 p-2 rounded mt-1 text-gray-900 dark:text-white">
                                        {JSON.stringify(selectedRun.form_data, null, 2)}
                                    </pre>
                                </div>
                            </div>
                            <div className="mt-6 flex justify-end">
                                <button
                                    onClick={() => setShowWorkflowModal(false)}
                                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                                >
                                    Close
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
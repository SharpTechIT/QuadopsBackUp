// Windows Service wrapper for Node.js backend
const Service = require('node-windows').Service;
const path = require('path');

// Create a new service object
const svc = new Service({
  name: 'QuadOps API Service',
  description: 'QuadOps Backend API Server',
  script: path.join(__dirname, 'server.js'),
  nodeOptions: [
    '--harmony',
    '--max_old_space_size=4096'
  ],
  env: [
    {
      name: "NODE_ENV",
      value: "production"
    },
    {
      name: "PORT",
      value: "3001"
    }
  ]
});

// Listen for the "install" event, which indicates the process is available as a service.
svc.on('install', function() {
  console.log('QuadOps API Service installed successfully!');
  svc.start();
});

svc.on('start', function() {
    console.log('QuadOps API Service started successfully!');
});

svc.on('stop', function() {
    console.log('QuadOps API Service stopped.');
});

svc.on('uninstall', function() {
    console.log('QuadOps API Service uninstalled.');
});

// Check if we're installing or uninstalling
const action = process.argv[2];

if (action === 'install') {
  svc.install();
} else if (action === 'uninstall') {
  svc.uninstall();
} else if (action === 'start') {
  svc.start();
} else if (action === 'stop') {
  svc.stop();
} else {
  console.log('Usage: node backend-service.cjs [install|uninstall|start|stop]');
}
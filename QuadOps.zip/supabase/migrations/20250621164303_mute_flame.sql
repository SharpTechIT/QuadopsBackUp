/*
  # Add ITSM reference field to tickets table

  1. Changes
    - Add `itsm_reference` field to tickets table to store external ITSM ticket numbers
    - Add `itsm_type` field to identify the type of ITSM system (servicenow, jira, etc.)
    - Add index for better performance when searching by ITSM reference

  2. Security
    - No changes to RLS policies needed
    - Field is optional and can be null for tickets without ITSM integration
*/

-- Add ITSM reference fields to tickets table
ALTER TABLE tickets 
ADD COLUMN IF NOT EXISTS itsm_reference TEXT,
ADD COLUMN IF NOT EXISTS itsm_type TEXT CHECK (itsm_type IN ('servicenow', 'jira', 'other'));

-- Add index for better performance when searching by ITSM reference
CREATE INDEX IF NOT EXISTS idx_tickets_itsm_reference ON tickets(itsm_reference);
CREATE INDEX IF NOT EXISTS idx_tickets_itsm_type ON tickets(itsm_type);

-- Add comment to document the fields
COMMENT ON COLUMN tickets.itsm_reference IS 'External ITSM ticket number (e.g., ServiceNow REQ number, Jira ticket key)';
COMMENT ON COLUMN tickets.itsm_type IS 'Type of ITSM system that created the external ticket';
/*
  # Fix duplicate RLS policies

  1. Changes
    - Drop all existing policies that might conflict
    - Recreate policies with correct permissions for custom authentication
    - Ensure policies work with anonymous key access

  2. Security
    - Allow access via anonymous key for custom authentication system
    - Maintain data integrity while enabling proper access
*/

-- Drop all existing policies to avoid conflicts
DROP POLICY IF EXISTS "Allow read access to user_roles" ON user_roles;
DROP POLICY IF EXISTS "Allow insert to user_roles" ON user_roles;
DROP POLICY IF EXISTS "Allow update to user_roles" ON user_roles;
DROP POLICY IF EXISTS "Allow delete from user_roles" ON user_roles;
DROP POLICY IF EXISTS "Users can read their own role" ON user_roles;
DROP POLICY IF EXISTS "Users can insert their own role" ON user_roles;
DROP POLICY IF EXISTS "Only admins can update user roles" ON user_roles;
DROP POLICY IF EXISTS "Only admins can delete user roles" ON user_roles;
DROP POLICY IF EXISTS "Only admins can insert user roles" ON user_roles;

-- Drop company_settings policies
DROP POLICY IF EXISTS "Anyone can read company settings" ON company_settings;
DROP POLICY IF EXISTS "Only admins can update company settings" ON company_settings;
DROP POLICY IF EXISTS "Allow company settings management" ON company_settings;

-- Drop workflow_configurations policies
DROP POLICY IF EXISTS "Only admins can manage workflow configurations" ON workflow_configurations;
DROP POLICY IF EXISTS "Allow workflow configurations management" ON workflow_configurations;

-- Drop automation_templates policies
DROP POLICY IF EXISTS "Anyone can read active automation templates" ON automation_templates;
DROP POLICY IF EXISTS "Only admins can manage automation templates" ON automation_templates;
DROP POLICY IF EXISTS "Allow automation templates management" ON automation_templates;

-- Create new policies that work with custom authentication and anonymous key
CREATE POLICY "user_roles_select_policy"
  ON user_roles
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "user_roles_insert_policy"
  ON user_roles
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "user_roles_update_policy"
  ON user_roles
  FOR UPDATE
  TO public
  USING (true);

CREATE POLICY "user_roles_delete_policy"
  ON user_roles
  FOR DELETE
  TO public
  USING (true);

-- Company settings policies
CREATE POLICY "company_settings_select_policy"
  ON company_settings
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "company_settings_all_policy"
  ON company_settings
  FOR ALL
  TO public
  USING (true);

-- Workflow configurations policies
CREATE POLICY "workflow_configurations_all_policy"
  ON workflow_configurations
  FOR ALL
  TO public
  USING (true);

-- Automation templates policies
CREATE POLICY "automation_templates_all_policy"
  ON automation_templates
  FOR ALL
  TO public
  USING (true);
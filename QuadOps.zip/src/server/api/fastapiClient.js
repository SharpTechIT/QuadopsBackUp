export const fastApiClient = {
    /**
     * Makes an authenticated POST request to your FastAPI endpoint to create a ServiceNow request.
     * @param {string} url - The full URL of your FastAPI endpoint.
     * @param {object} payload - The data to send to FastAPI for ServiceNow request creation.
     * @returns {Promise<object>} A promise that resolves with the FastAPI's response.
     */
    createServiceRequest: async (url, payload) => {
        try {
            console.log(`Calling FastAPI endpoint: ${url}`);
            console.log('Payload for FastAPI:', JSON.stringify(payload, null, 2));
            //const authString = btoa(`CloudAutomationNinja:P@$sW0rd#312`);
            //const authorizationHeader = `Basic ${authString}`;
            
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Authorization': 'Basic Q2xvdWRBdXRvbWF0aW9uTmluamE6UEAkc1cwcmQjMzEy'
                },
                body: JSON.stringify(payload),
            });

            if (!response.ok) {
                let errorData;
                try {
                    errorData = await response.json();
                } catch (jsonError) {
                    errorData = { detail: await response.text() };
                }

                const errorMessage = errorData.detail || `HTTP error! Status: ${response.status}`;
                throw new Error(`FastAPI request failed: ${errorMessage}`);
            }

            const responseData = await response.json();
            return responseData;
        } catch (error) {
            console.error('Error in fastapiClient.createServiceNowRequest:', error);
            throw error;
        }
    },

    triggerGitAction: async (url, payload) => {
        try {
            console.log(`Calling FastAPI endpoint: ${url}`);
            console.log('Payload for FastAPI:', JSON.stringify(payload));
            //const authString = btoa(`CloudAutomationNinja:P@$sW0rd#312`);
            //const authorizationHeader = `Basic ${authString}`;

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Authorization': 'Basic Q2xvdWRBdXRvbWF0aW9uTmluamE6UEAkc1cwcmQjMzEy'
                },
                body: JSON.stringify(payload),
            });

            if (!response.ok) {
                let errorData;
                try {
                    errorData = await response.json();
                } catch (jsonError) {
                    errorData = { detail: await response.text() };
                }

                const errorMessage = errorData.detail || `HTTP error! Status: ${response.status}`;
                throw new Error(`FastAPI request failed: ${errorMessage}`);
            }

            const responseData = await response.json();
            return responseData;
        } catch (error) {
            console.error('Error in fastapiClient.triggerGitAction:', error);
            throw error;
        }
    },

    /**
     * Updates a ServiceNow ticket with approval status
     * @param {string} url - The FastAPI endpoint URL
     * @param {object} payload - The data to update in ServiceNow (sys_id, snow_data, etc.)
     * @returns {Promise<object>} A promise that resolves with the FastAPI's response.
     */
    updateServiceNowRequest: async (url, payload) => {
        try {
            console.log('Calling FastAPI to update ServiceNow ticket...');
            console.log('Update payload:', JSON.stringify(payload, null, 2));
            //const authString = btoa(`CloudAutomationNinja:P@$sW0rd#312`);
            //const authorizationHeader = `Basic ${authString}`;

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Authorization': 'Basic Q2xvdWRBdXRvbWF0aW9uTmluamE6UEAkc1cwcmQjMzEy'
                },
                body: JSON.stringify(payload),
            });

            if (!response.ok) {
                let errorData;
                try {
                    errorData = await response.json();
                } catch (jsonError) {
                    errorData = { detail: await response.text() };
                }

                const errorMessage = errorData.detail || `HTTP error! Status: ${response.status}`;
                throw new Error(`FastAPI update request failed: ${errorMessage}`);
            }

            const responseData = await response.json();
            console.log('ServiceNow ticket update successful:', responseData);
            return responseData;
        } catch (error) {
            console.error('Error in fastapiClient.updateServiceNowRequest:', error);
            throw error;
        }
    },

    sendEmailNotification: async (url, payload) => {
        try {
            console.log('Calling API to send email...');
            console.log('Update payload:', JSON.stringify(payload, null, 2));
            //const authString = btoa(`CloudAutomationNinja:P@$sW0rd#312`);
            //const authorizationHeader = `Basic ${authString}`;

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Authorization': 'Basic Q2xvdWRBdXRvbWF0aW9uTmluamE6UEAkc1cwcmQjMzEy'
                },
                body: JSON.stringify(payload),
            });

            if (!response.ok) {
                let errorData;
                try {
                    errorData = await response.json();
                } catch (jsonError) {
                    errorData = { detail: await response.text() };
                }

                const errorMessage = errorData.detail || `HTTP error! Status: ${response.status}`;
                throw new Error(`FastAPI update request failed: ${errorMessage}`);
            }

            const responseData = await response.json();
            console.log('ServiceNow ticket update successful:', responseData);
            return responseData;
        } catch (error) {
            console.error('Error in fastapiClient.updateServiceNowRequest:', error);
            throw error;
        }
    },
    /**
     * Formats a given form data object into a human-readable string.
     * @param {object} formData - The key-value pairs representing the submitted form data.
     * @returns {string} A formatted description string.
     */
    formatFormDataDescription: (formData) => {
        if (!formData) return 'No form data provided.';
        let description = 'Automation Request Details:\n\n';
        for (const key in formData) {
            if (Object.prototype.hasOwnProperty.call(formData, key)) {
                description += `${key.replace(/_/g, ' ')}: ${formData[key]}\n`;
            }
        }
        return description;
    }
};
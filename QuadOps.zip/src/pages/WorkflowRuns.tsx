import React, { useState, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { CheckCircle, XCircle, Clock, AlertCircle, Eye, Filter, Download, Ticket } from 'lucide-react';
import { WorkflowRun } from '../types';
import { supabase } from '../config/supabase';

const statusIcons = {
  success: CheckCircle,
  failed: XCircle,
  pending: Clock,
  running: AlertCircle,
};

const statusColors = {
  success: 'text-green-600 bg-green-100 dark:text-green-400 dark:bg-green-900/50',
  failed: 'text-red-600 bg-red-100 dark:text-red-400 dark:bg-red-900/50',
  pending: 'text-yellow-600 bg-yellow-100 dark:text-yellow-400 dark:bg-yellow-900/50',
  running: 'text-blue-600 bg-blue-100 dark:text-blue-400 dark:bg-blue-900/50',
};

export const WorkflowRuns: React.FC = () => {
  const [runs, setRuns] = useState<WorkflowRun[]>([]);
  const [filteredRuns, setFilteredRuns] = useState<WorkflowRun[]>([]);
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedTower, setSelectedTower] = useState<string>('all');
  const [selectedRun, setSelectedRun] = useState<WorkflowRun | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchWorkflowRuns();
  }, []);

  useEffect(() => {
    let filtered = runs;
    
    if (selectedStatus !== 'all') {
      filtered = filtered.filter(run => run.status === selectedStatus);
    }
    
    if (selectedTower !== 'all') {
      filtered = filtered.filter(run => run.tower === selectedTower);
    }
    
    setFilteredRuns(filtered);
  }, [runs, selectedStatus, selectedTower]);

  const fetchWorkflowRuns = async () => {
    try {
      const { data, error } = await supabase
        .from('workflow_runs')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRuns(data || []);
    } catch (error) {
      console.error('Error fetching workflow runs:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleViewDetails = (run: WorkflowRun) => {
    setSelectedRun(run);
    setShowModal(true);
  };

  const towers = [...new Set(runs.map(run => run.tower))];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Workflow Runs</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            View and manage all workflow executions
          </p>
        </div>
        <button className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 shadow-sm text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700">
          <Download className="h-4 w-4 mr-2" />
          Export
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-4">
          <Filter className="h-5 w-5 text-gray-400" />
          <div className="flex space-x-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Status</label>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="block w-full rounded-md border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              >
                <option value="all">All Statuses</option>
                <option value="success">Success</option>
                <option value="failed">Failed</option>
                <option value="running">Running</option>
                <option value="pending">Pending</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Tower</label>
              <select
                value={selectedTower}
                onChange={(e) => setSelectedTower(e.target.value)}
                className="block w-full rounded-md border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              >
                <option value="all">All Towers</option>
                {towers.map(tower => (
                  <option key={tower} value={tower}>{tower}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Workflow Runs Table */}
      <div className="bg-white dark:bg-gray-800 shadow-sm rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Workflow
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Tower
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Ticket
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Execution Time
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Created
                </th>
                <th className="relative px-6 py-3">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {filteredRuns.map((run) => {
                const StatusIcon = statusIcons[run.status];
                return (
                  <tr key={run.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900 dark:text-white">
                          {run.workflow_name}
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          {run.workflow_id}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {run.tower}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {run.ticket_number ? (
                        <div className="flex items-center text-sm text-gray-900 dark:text-white">
                          <Ticket className="h-4 w-4 mr-2 text-gray-400" />
                          {run.ticket_number}
                        </div>
                      ) : (
                        <span className="text-sm text-gray-400 dark:text-gray-500">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColors[run.status]}`}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {run.status}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {run.execution_time ? `${run.execution_time}s` : '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                      {formatDistanceToNow(new Date(run.created_at), { addSuffix: true })}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleViewDetails(run)}
                        className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Details Modal */}
      {showModal && selectedRun && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-2/3 max-w-2xl shadow-lg rounded-md bg-white dark:bg-gray-800">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Workflow Run Details
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Workflow Name</label>
                  <p className="text-sm text-gray-900 dark:text-white">{selectedRun.workflow_name}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Tower</label>
                  <p className="text-sm text-gray-900 dark:text-white">{selectedRun.tower}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Ticket Number</label>
                  <p className="text-sm text-gray-900 dark:text-white">
                    {selectedRun.ticket_number || 'No associated ticket'}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
                  <p className={`text-sm font-medium ${
                    selectedRun.status === 'success' ? 'text-green-600 dark:text-green-400' : 
                    selectedRun.status === 'failed' ? 'text-red-600 dark:text-red-400' : 'text-yellow-600 dark:text-yellow-400'
                  }`}>
                    {selectedRun.status.toUpperCase()}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Execution Time</label>
                  <p className="text-sm text-gray-900 dark:text-white">
                    {selectedRun.execution_time ? `${selectedRun.execution_time}s` : 'N/A'}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Created</label>
                  <p className="text-sm text-gray-900 dark:text-white">
                    {formatDistanceToNow(new Date(selectedRun.created_at), { addSuffix: true })}
                  </p>
                </div>
              </div>
              
              {selectedRun.error_message && (
                <div className="mt-4">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Error Message</label>
                  <p className="text-sm text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 p-2 rounded">
                    {selectedRun.error_message}
                  </p>
                </div>
              )}
              
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Form Data</label>
                <pre className="text-xs bg-gray-100 dark:bg-gray-700 p-3 rounded mt-1 text-gray-900 dark:text-white overflow-auto max-h-40">
                  {JSON.stringify(selectedRun.form_data, null, 2)}
                </pre>
              </div>
              
              <div className="mt-6 flex justify-end">
                <button
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
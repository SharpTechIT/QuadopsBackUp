import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://riwtnauneyebqhhpfjya.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJpd3RuYXVuZXllYnFoaHBmanlhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA0NDA1NzEsImV4cCI6MjA2NjAxNjU3MX0.xgyciQdfduR6SPBkUt1c6OapY_a8jHDIHzETRZW9U6E';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database schemas for reference
export const DATABASE_SCHEMAS = {
  users: `
    CREATE TABLE IF NOT EXISTS users (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      email TEXT UNIQUE NOT NULL,
      full_name TEXT NOT NULL,
      avatar_url TEXT,
      theme TEXT DEFAULT 'light' CHECK (theme IN ('light', 'dark')),
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
  `,
  tools: `
    CREATE TABLE IF NOT EXISTS tools (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      type TEXT NOT NULL CHECK (type IN ('itsm', 'version_control', 'notification')),
      name TEXT NOT NULL,
      provider TEXT NOT NULL,
      config JSONB NOT NULL DEFAULT '{}',
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'error')),
      user_id UUID REFERENCES users(id),
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW(),
      UNIQUE(type, user_id)
    );
  `,
  workflow_runs: `
    CREATE TABLE IF NOT EXISTS workflow_runs (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      workflow_id TEXT NOT NULL,
      workflow_name TEXT NOT NULL,
      tower TEXT NOT NULL,
      automation_type TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'success', 'failed')),
      form_data JSONB NOT NULL DEFAULT '{}',
      execution_time INTEGER,
      error_message TEXT,
      user_id UUID REFERENCES users(id),
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
  `,
  tickets: `
    CREATE TABLE IF NOT EXISTS tickets (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      ticket_number TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved', 'closed')),
      priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
      workflow_run_id UUID REFERENCES workflow_runs(id),
      user_id UUID REFERENCES users(id),
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
  `,
  automation_templates: `
    CREATE TABLE IF NOT EXISTS automation_templates (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tower TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT,
      form_schema JSONB NOT NULL DEFAULT '{}',
      api_endpoint TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
  `
};
import os
import json
import logging
from typing import Dict, List, Optional, Any
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
import tempfile
from pathlib import Path
import subprocess
from crewai.tools import tool
import requests
import time
import pandas as pd
from bs4 import BeautifulSoup
import shutil

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# =============================================================================
# CUSTOM TOOLS
# =============================================================================
WEBHOOK_URL = "http://127.0.0.1:8001"
import time
import re
import traceback
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup, NavigableString, Tag

# ADD THIS: Global session state to track user interactions
SESSION_INTERACTION_STATE = {}

# ADD THIS: File storage directory
GENERATED_FILES_DIR = "generated_terraform_files"


def ensure_files_directory():
    """Ensure the generated files directory exists"""
    if not os.path.exists(GENERATED_FILES_DIR):
        os.makedirs(GENERATED_FILES_DIR)
    return GENERATED_FILES_DIR


def save_terraform_files(session_id: str, terraform_config: dict) -> dict:
    """
    Save Terraform configuration files to disk and return file paths

    Args:
        session_id: Session identifier
        terraform_config: Dictionary containing main_tf, variables_tf, outputs_tf

    Returns:
        Dictionary with saved file paths
    """
    ensure_files_directory()

    session_dir = os.path.join(GENERATED_FILES_DIR, session_id)
    if not os.path.exists(session_dir):
        os.makedirs(session_dir)

    saved_files = {}

    # Define file mappings
    file_mappings = {
        'main_tf': 'main.tf',
        'variables_tf': 'variables.tf',
        'outputs_tf': 'outputs.tf'
    }

    for config_key, filename in file_mappings.items():
        content = terraform_config.get(config_key, '')
        if content:
            file_path = os.path.join(session_dir, filename)
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                saved_files[config_key] = {
                    'filename': filename,
                    'path': file_path,
                    'relative_path': f"{session_id}/{filename}"
                }
                print(f"Saved {filename} to {file_path}")
            except Exception as e:
                print(f"Error saving {filename}: {e}")

    return saved_files


def get_uls_after_h2(soup: BeautifulSoup, h2_id: str):
    """
    Find <h2 id="{h2_id}"> and return a list of HTML strings for any <ul> siblings
    that appear after it, stopping when another h1/h2 is encountered.
    """
    h2 = soup.find("h2", id=h2_id)
    if not h2:
        return []

    uls = []
    for sib in h2.find_next_siblings():
        if isinstance(sib, Tag) and sib.name in ("h1", "h2"):
            break
        # direct UL sibling
        if isinstance(sib, Tag) and sib.name == "ul":
            uls.append(sib.decode_contents())
        # or UL nested inside a wrapper
        elif isinstance(sib, Tag):
            for u in sib.find_all("ul", recursive=False):
                uls.append(u.decode_contents())
    return uls


def html_fragment_to_readable_text(html_fragment: str) -> str:
    """
    Convert an HTML fragment to a readable plain-text representation using BeautifulSoup.
    Preserves code blocks as fenced code and inline <code> as `code`.
    """
    soup = BeautifulSoup(html_fragment, "html.parser")

    # 1) Replace <pre> (code blocks) with fenced code markers
    for pre in soup.find_all("pre"):
        code_text = pre.get_text()
        fenced = soup.new_string("\n```\n" + code_text.rstrip() + "\n```\n")
        pre.replace_with(fenced)

    # 2) Replace inline <code> with backticks
    for code in soup.find_all("code"):
        # skip code that was inside pre (already replaced) - but if present, wrap anyway
        txt = code.get_text()
        backticked = soup.new_string(f"`{txt}`")
        code.replace_with(backticked)

    # 3) Replace links: show text (URL)
    for a in soup.find_all("a"):
        text = a.get_text(strip=True)
        href = a.get("href", "")
        # if link text is same as href, keep it; else show: text (href)
        replacement = text if not href else f"{text} ({href})"
        a.replace_with(soup.new_string(replacement))

    # 4) Get text with sensible separators
    text = soup.get_text(separator="\n", strip=True)

    # 5) Normalize blank lines: collapse 3+ newlines into 2
    text = re.sub(r"\n{3,}", "\n\n", text)

    # 6) Trim leading/trailing whitespace
    return text.strip()


def fetch_terraform_parts(url: str, headless: bool = True, timeout: int = 60, scroll_times: int = 5):
    """
    Fetch the page and return a dictionary containing requested parts:
      - alert_info: list of HTML fragments for .alert.alert-info
      - alert_warning: list of HTML fragments for .alert.alert-warning
      - code_wrappers: list of HTML fragments for .code-wrapper-with-cp-btn
      - argument_reference_uls: list of UL HTML fragment strings after h2#argument-reference
      - attributes_reference_uls: list of UL HTML fragment strings after h2#attributes-reference
    """
    opts = Options()
    if headless:
        try:
            opts.add_argument("--headless=new")
        except Exception:
            opts.add_argument("--headless")

    # Useful stability options
    opts.add_argument("--disable-gpu")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--disable-extensions")
    opts.add_argument("--ignore-certificate-errors")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116 Safari/537.36"
    )
    prefs = {"profile.managed_default_content_settings.images": 2}
    opts.add_experimental_option("prefs", prefs)

    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=opts)
    driver.set_page_load_timeout(timeout)

    try:
        driver.get(url)

        # Scroll repeatedly to encourage lazy-loading of content
        SCROLL_PAUSE = 0.5
        last_height = driver.execute_script("return document.body.scrollHeight")
        for _ in range(scroll_times):
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(SCROLL_PAUSE)
            new_height = driver.execute_script("return document.body.scrollHeight")
            if new_height == last_height:
                break
            last_height = new_height

        # short wait for content to render - adjust if needed
        wait = WebDriverWait(driver, 10)
        try:
            wait.until(EC.presence_of_element_located(
                (By.CSS_SELECTOR, "div.markdown, .alert.alert-info, .alert.alert-warning, .code-wrapper-with-cp-btn")
            ))
        except Exception:
            # not fatal; we'll still try to parse page source
            pass

        html = driver.page_source
        soup = BeautifulSoup(html, "html.parser")

        result = {
            "alert_info": [],
            "alert_warning": [],
            "code_wrappers": [],
            "argument_reference_uls": [],
            "attributes_reference_uls": [],
        }

        # 1) alert alert-info
        for node in soup.select(".alert.alert-info"):
            # keep the full HTML fragment
            result["alert_info"].append(node.decode_contents())

        # 2) alert alert-warning
        for node in soup.select(".alert.alert-warning"):
            result["alert_warning"].append(node.decode_contents())

        # 3) code-wrapper-with-cp-btn
        for node in soup.select(".code-wrapper-with-cp-btn"):
            result["code_wrappers"].append(node.decode_contents())

        # 4) ul tags after h2#argument-reference
        result["argument_reference_uls"] = get_uls_after_h2(soup, "argument-reference")

        # 5) ul tags after h2#attributes-reference
        result["attributes_reference_uls"] = get_uls_after_h2(soup, "attributes-reference")

        return result

    except Exception as e:
        traceback.print_exc()
        return {"error": str(e)}
    finally:
        driver.quit()


def _get_full_url(endpoint: str) -> str:
    """Helper function to ensure the URL is correctly formatted with the http schema."""
    base_url = WEBHOOK_URL
    if not base_url.startswith("http"):
        base_url = f"http://{base_url}"
    return f"{base_url.rstrip('/')}/{endpoint.lstrip('/')}"


import requests
import time


@tool("UserInteractionTool")
def UserInteractionTool(question: str, session_id: str) -> str:
    """
    Asks the user a question by sending it to the webhook and waits for an answer.
    This tool facilitates the interactive part of the conversation with the webapp.
    """
    global SESSION_INTERACTION_STATE

    # Create a unique key for this question-session combination
    question_hash = hash(question.strip().lower())
    session_key = f"{session_id}_{question_hash}"

    # Check if we've already asked this question and got an answer
    if session_key in SESSION_INTERACTION_STATE:
        previous_answer = SESSION_INTERACTION_STATE[session_key]
        print(f"AGENT INFO: Question already answered in this session. Returning cached answer: {previous_answer}")
        return previous_answer

    print(f"AGENT ASKING: {question}")
    try:
        # 1. Post the agent's question to the webhook for the UI to fetch.
        question_url = "http://127.0.0.1:3001/api/agent/message"
        response = requests.post(
            question_url,
            json={"sessionId": session_id, "text": question},
            timeout=5
        )

        if response.status_code != 200:
            return f"Failed to send question to user: {response.text}"

        # 2. Poll the webhook waiting for the user's answer.
        answer_url = "http://127.0.0.1:3001/api/agent/get-answer"
        clear_answer_url = "http://127.0.0.1:3001/api/agent/clear-user-answer"

        # --- Timeout Logic ---
        # Wait for up to 5 minutes (300 seconds) for a user response.
        max_wait_time = 300
        start_time = time.time()
        poll_interval = 2  # Check every 2 seconds

        print("Waiting for user response...")

        while time.time() - start_time < max_wait_time:
            # Wait a moment before checking again to avoid spamming the server.
            time.sleep(poll_interval)

            # Check for user's answer
            try:
                response = requests.get(
                    answer_url,
                    params={"sessionId": session_id},
                    timeout=5
                )

                if response.status_code == 200:
                    data = response.json()
                    if data.get("success") and data.get("answer"):
                        answer = data["answer"]
                        print(f"USER ANSWERED: {answer}")

                        # Clear the answer from the server once we've received it.
                        clear_response = requests.post(
                            clear_answer_url,
                            json={"sessionId": session_id},
                            timeout=5
                        )

                        if clear_response.status_code != 200:
                            print(f"Warning: Failed to clear answer: {clear_response.text}")

                        # Cache the answer to prevent duplicate questions
                        SESSION_INTERACTION_STATE[session_key] = answer

                        print(f"Returning Answer: {answer}")
                        return answer  # Return the answer to the agent
                else:
                    print(f"Error polling for answer: {response.status_code} - {response.text}")

            except requests.exceptions.RequestException as poll_error:
                print(f"Error while polling for answer: {poll_error}")
                # Continue polling unless it's a critical error

        # If the loop finishes without an answer, it has timed out.
        timeout_message = "User did not respond within the 5-minute time limit."
        print(f"AGENT INFO: {timeout_message}")
        return timeout_message

    except requests.exceptions.RequestException as e:
        error_message = f"Could not communicate with the webapp server: {e}"
        print(error_message)
        return error_message  # Return an error message to the agent
    except Exception as e:
        error_message = f"Unexpected error in UserInteractionTool: {e}"
        print(error_message)
        return error_message


# ADD THIS: Function to clear session state when starting new workflow
def clear_session_interaction_state(session_id: str = None):
    """Clear interaction state for a specific session or all sessions"""
    global SESSION_INTERACTION_STATE
    if session_id:
        # Clear only for specific session
        keys_to_remove = [key for key in SESSION_INTERACTION_STATE.keys() if key.startswith(f"{session_id}_")]
        for key in keys_to_remove:
            del SESSION_INTERACTION_STATE[key]
        print(f"Cleared interaction state for session: {session_id}")
    else:
        # Clear all
        SESSION_INTERACTION_STATE.clear()
        print("Cleared all interaction state")


@tool("read_git_terraform_csv")
def read_git_terraform_csv() -> str:
    """
    Reads a CSV file from the root directory containing Ansible Tower job templates
    and returns a list of available jobs as a JSON string.
    The CSV must contain 'job_name', 'description', 'required_inputs', and 'job_template_id'.
    """
    try:

        csv_path = "D:\\Python\\QuadOps - Terraform builder\\CrewAI-TerraformBuilder\\terraform_git_files.csv"
        # Assuming the CSV is in the root of the project, a relative path is fine
        df = pd.read_csv(csv_path)
        jobs_list = df.to_dict(orient='records')
        if not jobs_list:
            return json.dumps(
                {"status": "error", "message": "No matching file found in the CSV file or the file is empty."})
        return json.dumps({"status": "success", "fileList": jobs_list})
    except FileNotFoundError:
        return json.dumps(
            {"status": "error", "message": "The terraform_git_files.csv file was not found in the root directory."})
    except Exception as e:
        return json.dumps({"status": "error", "message": f"An error occurred while reading the CSV file: {str(e)}"})


@tool("WebSearchTool")
def WebSearchTool(provider: str, resource: str) -> dict[str, list]:
    """
        Fetches the official Terraform documentation for a given provider resource.

        This function constructs a Terraform Registry documentation URL based on the
        specified provider and resource, sends an HTTP GET request to that page,
        and extracts the main content of the documentation using BeautifulSoup.

        Args:
            provider (str): The Terraform provider name
                            (e.g., "azurerm", "aws", "google").
            resource (str): The resource name within the provider
                            (e.g., "virtual_machine", "s3_bucket").

        Returns:
            str: The extracted documentation content as dict[str, list], with sections
                 separated by newlines. If the request fails, returns an error
                 message with the HTTP status code. If no documentation content
                 is found, returns "No documentation found."

        Example:
            # WebSearchTool("azurerm", "virtual_machine")
            # Returns the dict[str, list] content of the AzureRM Virtual Machine
            # resource documentation from the Terraform Registry.
        """
    url = f"https://registry.terraform.io/providers/hashicorp/{provider}/latest/docs/resources/{resource}"
    result = {
        "alert_info": [],
        "alert_warning": [],
        "code_wrappers": [],
        "argument_reference_uls": [],
        "attributes_reference_uls": [],
    }
    parts = fetch_terraform_parts(url, headless=True, timeout=90, scroll_times=8)

    def print_section(title: str, items):
        print("\n" + "=" * 80)
        print(title)
        print("=" * 80 + "\n")
        if not items:
            print("(none found)\n")
            return
        for idx, html_frag in enumerate(items, start=1):
            print(f"--- ITEM {idx} ---\n")
            readable = html_fragment_to_readable_text(html_frag)
            print(readable)
            result[title] = readable
            print("\n")  # spacing between items

    print_section("alert_info", parts.get("alert_info", []))
    print_section("alert_warning", parts.get("alert_warning", []))
    print_section("code_wrappers", parts.get("code_wrappers", []))
    print_section("argument_reference_uls", parts.get("argument_reference_uls", []))
    print_section("attributes_reference_uls", parts.get("attributes_reference_uls", []))
    return result


@tool("TerraformExecutionTool")
def TerraformExecutionTool(script_path: str) -> str:
    """
    Executes `terraform plan` in the given directory.

    Args:
        script_path (str): Absolute path to the folder where `main.tf` exists.

    Returns:
        str: JSON string containing either the plan output (on success)
             or an error message (on failure).
    """
    initcommand = ["terraform", "init"]

    try:
        init = subprocess.run(
            initcommand,
            cwd=script_path,  # Run inside the given directory
            capture_output=True,
            text=True
        )
        print(init.stdout)
    except Exception as e:
        print("Terraform init failed with error {e}".format(e=e))

    command = ["terraform", "validate"]

    try:
        result = subprocess.run(
            command,
            cwd=script_path,  # Run inside the given directory
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            return json.dumps({
                "status": "success",
                "output": result.stdout
            })
        else:
            return json.dumps({
                "status": "error",
                "message": result.stderr
            })

    except Exception as e:
        return json.dumps({
            "status": "error",
            "message": f"Execution exception: {str(e)}"
        })


@tool("download_github_file")
def download_github_file(file_path: str, save_as: str):
    """
    Download a file from a GitHub repo (supports private repos with token).

    :param file_path: Path to the file in repo (e.g., "terraform/main.tf")
    :param save_as: Local filename to save (e.g., "main.tf")
    :return: True if successful, False otherwise
    """
    repo_owner = "SharpTechIT",
    repo_name = "QuadMindsAI",
    branch = "main"
    token = "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"
    url = f"https://raw.githubusercontent.com/{repo_owner}/{repo_name}/{branch}/{file_path}"

    headers = {}
    if token:
        headers["Authorization"] = f"token {token}"

    response = requests.get(url, headers=headers, stream=True)

    if response.status_code == 200:
        with open(save_as, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        print(f"✅ File downloaded: {save_as}")
        return True
    else:
        print(f"❌ Failed to download file. Status: {response.status_code}, URL: {url}")
        return False
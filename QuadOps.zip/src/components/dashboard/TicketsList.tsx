import React, { useState, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { ExternalLink, AlertTriangle, CheckCircle, Clock, XCircle, Check, X, Eye } from 'lucide-react';
import { Ticket } from '../../types';
import { supabase } from '../../config/supabase';
import { useAuth } from '../../hooks/useAuth';

interface TicketsListProps {
  tickets?: Ticket[];
  showViewAll?: boolean;
  onViewAll?: () => void;
}

const statusIcons = {
  open: AlertTriangle,
  in_progress: Clock,
  resolved: CheckCircle,
  closed: XCircle,
  pending_approval: Clock,
  approved: CheckCircle,
  rejected: XCircle,
};

const statusColors = {
  open: 'text-red-600 bg-red-100 dark:text-red-400 dark:bg-red-900/50',
  in_progress: 'text-blue-600 bg-blue-100 dark:text-blue-400 dark:bg-blue-900/50',
  resolved: 'text-green-600 bg-green-100 dark:text-green-400 dark:bg-green-900/50',
  closed: 'text-gray-600 bg-gray-100 dark:text-gray-400 dark:bg-gray-700',
  pending_approval: 'text-yellow-600 bg-yellow-100 dark:text-yellow-400 dark:bg-yellow-900/50',
  approved: 'text-green-600 bg-green-100 dark:text-green-400 dark:bg-green-900/50',
  rejected: 'text-red-600 bg-red-100 dark:text-red-400 dark:bg-red-900/50',
};

const priorityColors = {
  low: 'text-gray-600 dark:text-gray-400',
  medium: 'text-yellow-600 dark:text-yellow-400',
  high: 'text-orange-600 dark:text-orange-400',
  critical: 'text-red-600 dark:text-red-400',
};

export const TicketsList: React.FC<TicketsListProps> = ({ tickets: propTickets, showViewAll = true, onViewAll }) => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [showModal, setShowModal] = useState(false);
  const { isAdmin } = useAuth();

  useEffect(() => {
    if (propTickets) {
      setTickets(propTickets);
    } else {
      fetchTickets();
    }
  }, [propTickets]);

  const fetchTickets = async () => {
    try {
      const { data, error } = await supabase
        .from('tickets')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(5);
      
      if (error) throw error;
      setTickets(data || []);
    } catch (error) {
      console.error('Error fetching tickets:', error);
    }
  };

  const updateServiceNowTicket = async (ticket: Ticket) => {
    try {
      // Extract ServiceNow sys_id from automation_data
      const automationData = ticket.automation_data as any;
      const sysId = automationData?.servicenow_request?.sys_id;

      if (!sysId) {
        console.log('No ServiceNow sys_id found in ticket automation_data');
        return;
      }

      const snowData = {
        approval: "approved",
        requested_state: "approved"
      };

      console.log('Updating ServiceNow ticket with sys_id:', sysId);

      const response = await fetch('/api/servicenow/update-ticket', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sys_id: sysId,
          snow_data: snowData
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to update ServiceNow ticket');
      }

      const result = await response.json();
      console.log('ServiceNow ticket updated successfully:', result);

    } catch (error) {
      console.error('Error updating ServiceNow ticket:', error);
      // Don't fail the approval process if ServiceNow update fails
    }
  };

  const createWorkflowRun = async (ticket: Ticket) => {
    try {
      const automationData = ticket.automation_data as any;
      
      if (!automationData) {
        console.log('No automation data found in ticket');
        return null;
      }

      console.log('Creating workflow run for approved ticket...');

      const { data: workflowRun, error: workflowError } = await supabase
        .from('workflow_runs')
        .insert([{
          workflow_id: `${automationData.tower}-${automationData.automation_type}-${Date.now()}`,
          workflow_name: automationData.automation_name,
          tower: automationData.tower,
          automation_type: automationData.automation_type,
          status: 'pending',
          form_data: automationData.form_data,
          user_id: ticket.user_id,
          ticket_id: ticket.id,
          ticket_number: ticket.ticket_number
        }])
        .select()
        .single();

      if (workflowError) {
        console.error('Error creating workflow run:', workflowError);
        throw workflowError;
      }

      console.log('Workflow run created successfully:', workflowRun);
      return workflowRun;

    } catch (error) {
      console.error('Error creating workflow run:', error);
      throw error;
    }
  };

  const triggerGitAction = async (ticket: Ticket) => {
    try {
      const automationData = ticket.automation_data as any;
      
      if (!automationData) {
        console.log('No automation data found for git action trigger');
        return;
      }

      console.log('Triggering git action via FastAPI...');

      const payload = {
        automationData: automationData.form_data,
        tower: automationData.tower,
        automation_type: automationData.automation_type,
        ticket_number: ticket.ticket_number
      };

      const response = await fetch('/api/trigger-git-action', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to trigger git action');
      }

      const result = await response.json();
      console.log('Git action triggered successfully:', result);

    } catch (error) {
      console.error('Error triggering git action:', error);
      // Don't fail the approval process if git action fails
    }
  };

  const handleApproveTicket = async (ticketId: string) => {
    console.log('Starting approval process for ticket:', ticketId);
    
    try {
      const { data: updatedTickets, error: updateError } = await supabase
        .from('tickets')
        .update({ 
          status: 'approved',
          updated_at: new Date().toISOString()
        })
        .eq('id', ticketId)
        .select();

      if (updateError) {
        console.error('Update error:', updateError);
        throw updateError;
      }

      console.log('Update result:', updatedTickets);

      if (!updatedTickets || updatedTickets.length === 0) {
        throw new Error('No ticket was updated - this might be a permissions issue');
      }

      const updatedTicket = updatedTickets[0];
      console.log('Ticket approved successfully!');

      // Update ServiceNow ticket if it exists
      await updateServiceNowTicket(updatedTicket);

      // Create workflow run
      const workflowRun = await createWorkflowRun(updatedTicket);
      
      if (workflowRun) {
        console.log('Workflow run created, now triggering git action...');
        // Trigger git action
        await triggerGitAction(updatedTicket);
      }

      // Refresh tickets
      if (propTickets) {
        window.location.reload();
      } else {
        await fetchTickets();
      }
      
      alert('Ticket approved successfully! Workflow run created and git action triggered.');
    } catch (error) {
      console.error('Error approving ticket:', error);
      alert(`Error approving ticket: ${error instanceof Error ? error.message : 'Unknown error occurred'}`);
    }
  };

  const handleRejectTicket = async (ticketId: string) => {
    console.log('Starting rejection process for ticket:', ticketId);
    
    try {
      const { data: updatedTickets, error } = await supabase
        .from('tickets')
        .update({ 
          status: 'rejected',
          updated_at: new Date().toISOString()
        })
        .eq('id', ticketId)
        .select();

      if (error) {
        console.error('Update error:', error);
        throw error;
      }

      console.log('Update result:', updatedTickets);

      if (!updatedTickets || updatedTickets.length === 0) {
        throw new Error('No ticket was updated');
      }

      // Refresh tickets
      if (propTickets) {
        window.location.reload();
      } else {
        await fetchTickets();
      }
      
      alert('Ticket rejected successfully!');
    } catch (error) {
      console.error('Error rejecting ticket:', error);
      alert(`Error rejecting ticket: ${error instanceof Error ? error.message : 'Unknown error occurred'}`);
    }
  };

  const handleViewDetails = (ticket: Ticket) => {
    setSelectedTicket(ticket);
    setShowModal(true);
  };

  // Helper function to get ITSM reference from ticket
  const getItsmReference = (ticket: Ticket): string | null => {
    const references: string[] = [];

    // First check the direct itsm_reference field
    if (ticket.itsm_reference) {
      references.push(ticket.itsm_reference);
    }

    // Check automation_data for additional ITSM references
    const automationData = ticket.automation_data as any;
    if (automationData) {
      // Check for Jira ticket
      if (automationData.jira_ticket?.key) {
        references.push(automationData.jira_ticket.key);
      }
      
      // Check for ServiceNow ticket
      if (automationData.servicenow_request?.number) {
        references.push(automationData.servicenow_request.number);
      }

      // Check for multiple ITSM results
      if (automationData.itsm_results) {
        const results = automationData.itsm_results;
        
        // Add all successful ITSM references
        for (const result of results) {
          if (result.success && result.ticket_number) {
            references.push(result.ticket_number);
          }
        }
      }
    }

    // Remove duplicates and return comma-separated string
    const uniqueReferences = [...new Set(references)];
    return uniqueReferences.length > 0 ? uniqueReferences.join(', ') : null;
  };

  // Helper function to get ITSM type from ticket
  const getItsmType = (ticket: Ticket): string | null => {
    const types: string[] = [];

    // First check the direct itsm_type field
    if (ticket.itsm_type) {
      types.push(ticket.itsm_type);
    }

    // Check automation_data for additional ITSM types
    const automationData = ticket.automation_data as any;
    if (automationData) {
      // Check for Jira ticket
      if (automationData.jira_ticket?.key) {
        types.push('jira');
      }
      
      // Check for ServiceNow ticket
      if (automationData.servicenow_request?.number) {
        types.push('servicenow');
      }

      // Check for multiple ITSM results
      if (automationData.itsm_results) {
        const results = automationData.itsm_results;
        
        // Add all successful ITSM types
        for (const result of results) {
          if (result.success && result.provider) {
            types.push(result.provider.toLowerCase());
          }
        }
      }
    }

    // Remove duplicates and return comma-separated string
    const uniqueTypes = [...new Set(types)];
    return uniqueTypes.length > 0 ? uniqueTypes.join(', ') : null;
  };

  return (
    <>
      <div className="bg-white dark:bg-gray-800 shadow-sm rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white">Recent Tickets</h3>
            {showViewAll && onViewAll && (
              <button
                onClick={onViewAll}
                className="inline-flex items-center text-sm font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500 dark:hover:text-blue-300"
              >
                View all
                <ExternalLink className="ml-1 h-3 w-3" />
              </button>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Ticket
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    ITSM Reference
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Priority
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Created
                  </th>
                  <th className="relative px-6 py-3">
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {tickets.map((ticket) => {
                  const StatusIcon = statusIcons[ticket.status as keyof typeof statusIcons];
                  return (
                    <tr key={ticket.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            {ticket.ticket_number}
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs">
                            {ticket.title}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          {getItsmReference(ticket) ? (
                            <>
                              <div className="text-sm font-medium text-gray-900 dark:text-white">
                                {getItsmReference(ticket)}
                              </div>
                              <div className="text-xs text-gray-500 dark:text-gray-400 capitalize">
                                {getItsmType(ticket)}
                              </div>
                            </>
                          ) : (
                            <span className="text-sm text-gray-400 dark:text-gray-500">-</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColors[ticket.status as keyof typeof statusColors]}`}>
                          <StatusIcon className="h-3 w-3 mr-1" />
                          {ticket.status.replace('_', ' ')}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`text-sm font-medium ${priorityColors[ticket.priority]}`}>
                          {ticket.priority.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                        {formatDistanceToNow(new Date(ticket.created_at), { addSuffix: true })}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => handleViewDetails(ticket)}
                            className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300"
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                          {isAdmin && ticket.status === 'pending_approval' && (
                            <>
                              <button 
                                onClick={() => {
                                  console.log('Approve button clicked for ticket:', ticket.id);
                                  handleApproveTicket(ticket.id);
                                }}
                                className="text-green-600 dark:text-green-400 hover:text-green-900 dark:hover:text-green-300"
                                title="Approve"
                              >
                                <Check className="h-4 w-4" />
                              </button>
                              <button 
                                onClick={() => {
                                  console.log('Reject button clicked for ticket:', ticket.id);
                                  handleRejectTicket(ticket.id);
                                }}
                                className="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300"
                                title="Reject"
                              >
                                <X className="h-4 w-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Details Modal */}
      {showModal && selectedTicket && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-2/3 max-w-2xl shadow-lg rounded-md bg-white dark:bg-gray-800">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Ticket Details
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Ticket Number</label>
                  <p className="text-sm text-gray-900 dark:text-white">{selectedTicket.ticket_number}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">ITSM Reference</label>
                  <p className="text-sm text-gray-900 dark:text-white">
                    {getItsmReference(selectedTicket) ? (
                      <>
                        {getItsmReference(selectedTicket)}
                        <span className="text-xs text-gray-500 dark:text-gray-400 ml-2 capitalize">
                          ({getItsmType(selectedTicket)})
                        </span>
                      </>
                    ) : (
                      'No external reference'
                    )}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
                  <p className={`text-sm font-medium`}>
                    {selectedTicket.status.replace('_', ' ').toUpperCase()}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Priority</label>
                  <p className={`text-sm font-medium ${priorityColors[selectedTicket.priority]}`}>
                    {selectedTicket.priority.toUpperCase()}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Created</label>
                  <p className="text-sm text-gray-900 dark:text-white">
                    {formatDistanceToNow(new Date(selectedTicket.created_at), { addSuffix: true })}
                  </p>
                </div>
              </div>
              
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Title</label>
                <p className="text-sm text-gray-900 dark:text-white">{selectedTicket.title}</p>
              </div>
              
              {selectedTicket.automation_data && (
                <div className="mt-4">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Automation Data</label>
                  <pre className="text-xs bg-gray-100 dark:bg-gray-700 p-3 rounded mt-1 text-gray-900 dark:text-white overflow-auto max-h-40">
                    {JSON.stringify(selectedTicket.automation_data, null, 2)}
                  </pre>
                </div>
              )}
              
              <div className="mt-6 flex justify-end space-x-2">
                {isAdmin && selectedTicket.status === 'pending_approval' && (
                  <>
                    <button
                      onClick={() => {
                        handleApproveTicket(selectedTicket.id);
                        setShowModal(false);
                      }}
                      className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => {
                        handleRejectTicket(selectedTicket.id);
                        setShowModal(false);
                      }}
                      className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                    >
                      Reject
                    </button>
                  </>
                )}
                <button
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
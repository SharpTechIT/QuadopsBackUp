import { useAuth as useSupabaseAuth } from '../contexts/AuthContext';
import { useState, useEffect } from 'react';
import { supabase } from '../config/supabase';

interface UserRole {
  role: 'admin' | 'user';
}

export const useAuth = () => {
  const auth = useSupabaseAuth();
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [isLoadingRole, setIsLoadingRole] = useState(true);

  useEffect(() => {
    const fetchUserRole = async () => {
      if (!auth.user) {
        setUserRole(null);
        setIsLoadingRole(false);
        return;
      }

      try {
        // Check if user exists in user_roles table
        const { data, error } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', auth.user.id)
          .maybeSingle();

        console.log('User role data:', data);
        console.log('User role error:', error);

        if (error) {
          console.error('Error fetching user role:', error);
          // If there's an error, try to create a role for this user
          if (auth.user.email === 'admin@autoflow.com') {
            // Try to insert admin role for the default admin user
            const { data: insertData, error: insertError } = await supabase
              .from('user_roles')
              .insert([{ user_id: auth.user.id, role: 'admin' }])
              .select()
              .single();
            
            if (!insertError && insertData) {
              setUserRole({ role: 'admin' });
            } else {
              console.error('Error inserting admin role:', insertError);
              setUserRole({ role: 'user' });
            }
          } else {
            // Regular user, insert user role
            const { data: insertData, error: insertError } = await supabase
              .from('user_roles')
              .insert([{ user_id: auth.user.id, role: 'user' }])
              .select()
              .single();
            
            if (!insertError && insertData) {
              setUserRole({ role: 'user' });
            } else {
              console.error('Error inserting user role:', insertError);
              setUserRole({ role: 'user' });
            }
          }
        } else if (data) {
          setUserRole(data);
        } else {
          // User not found in user_roles, create appropriate role
          const roleToAssign = auth.user.email === 'admin@autoflow.com' ? 'admin' : 'user';
          
          const { data: insertData, error: insertError } = await supabase
            .from('user_roles')
            .insert([{ user_id: auth.user.id, role: roleToAssign }])
            .select()
            .single();
          
          if (!insertError && insertData) {
            setUserRole({ role: roleToAssign });
          } else {
            console.error('Error inserting role:', insertError);
            setUserRole({ role: 'user' });
          }
        }
      } catch (error) {
        console.error('Error in fetchUserRole:', error);
        setUserRole({ role: 'user' });
      } finally {
        setIsLoadingRole(false);
      }
    };

    fetchUserRole();
  }, [auth.user]);

  const isAdmin = userRole?.role === 'admin';

  return {
    ...auth,
    userRole: userRole?.role || 'user',
    isAdmin,
    isLoadingRole,
  };
};
from crewai import Task
import re
from crewai.tasks.task_output import TaskOutput
import json
import requests
from dotenv import load_dotenv

# Make sure you load the variables at the start of your app
load_dotenv()
import os

os.environ["PYTHONUTF8"] = "1"
from dotenv import load_dotenv

# Make sure you load the variables at the start of your app
load_dotenv()

from langchain_openai import AzureChatOpenAI

# Initialize the LLM
azure_llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_API_BASE"),
    api_version=os.getenv("AZURE_API_VERSION"),
    api_key=os.getenv("AZURE_API_KEY"),
    temperature=0.1
)

from .agents import search_agent, user_interaction_agent, cloud_architect_agent, terraform_code_generator_agent, \
    Quality_reviewer_agent, intent_classifier_agent

# Import the file saving function

import json
import re
import requests



def send_agent_conversation(task_output: TaskOutput):
    agent_role = task_output.agent
    agent_response = task_output.raw

    print("===" * 20)
    print(f"Agent output type: {type(agent_response)}")
    print(f"Agent name {agent_role}")
    print("===" * 20)

    session_id = ""

    try:
        # session_id extraction
        if isinstance(agent_response, str):
            if '"session_id"' in agent_response:
                session_match = re.search(r'"session_id":\s*"([^"]+)"', agent_response)
                if session_match:
                    session_id = session_match.group(1)
            elif "SESSION_ID:" in agent_response:
                session_match = re.search(r'SESSION_ID:\s*([^\s\n]+)', agent_response)
                if session_match:
                    session_id = session_match.group(1)

        print(f"--- [Callback] Extracted session_id: {session_id}")
        print(f"--- [Callback] Sending message from: {agent_role}...")





        if session_id:
            question_url = "http://127.0.0.1:3001/api/agent/message"

            clean_response = re.sub(r'SESSION_ID:\s*[^\s\n]+\n?', '', agent_response)
            clean_response = re.sub(r'"session_id":\s*"[^"]+",?\s*', '', clean_response)

            clean_resp = f"Agent: {agent_role} \n"
            if "Infrastructure Requirements Analyst" in agent_role:
                print("Infrastructure Requirements Analyst Agent is used")

                clean_resp = clean_response

            elif "Infrastructure Code Quality Assurance Specialist" in agent_role:
                print("Quality Reviewer Agent is used")
                clean_resp = clean_response
            elif "Senior Infrastructure-as-Code Engineer" in agent_role:
                print("Senior Infrastructure-as-Code Engineer Agent is used")
                clean_resp = clean_response
            elif "Terraform Searcher" in agent_role:
                print("Terraform Searcher Agent is used")
                clean_resp = clean_response
            elif "Senior Multi-Cloud Architect" in agent_role:
                print("Senior Multi-Cloud Architect Agent is used")
                clean_resp = clean_response

            if clean_resp:
                clean_response = clean_resp

            # Send file information along with the message if available
            payload = {"sessionId": session_id, "text": clean_response}

            api_response = requests.post(
                question_url,
                json=payload,
                timeout=5
            )
            api_response.raise_for_status()
            print(f"--- [Callback] ...Successfully sent message to UI for session: {session_id}")
        else:
            print(f"--- [Callback] ...WARNING: No session_id found in task output. Cannot send to UI.")

    except requests.exceptions.RequestException as e:
        print(f"--- [Callback] ...ERROR: Could not send message. Is the FastAPI backend running? \n   Details: {e}")
    except Exception as e:
        print(f"--- [Callback] ...ERROR: Failed to process task output: {e}")


def create_intent_classification_task(user_request, session_id):
    return Task(
        description=f"""
        SESSION_ID: {session_id}

        Analyze the following user request and classify it as either 'generic_question' or 'terraform_generation'.

        USER REQUEST: "{user_request}"

        Respond with only the classification in lowercase. For example: 'generic_question' or 'terraform_generation'.
        """,
        agent=intent_classifier_agent,
        expected_output="A string with the classification: 'generic_question' or 'terraform_generation'."
    )


def create_generic_question_tasks(user_request, session_id):
    """
    Tasks for answering generic architectural questions.
    """
    return [
        Task(
            description=f"""
            SESSION_ID: {session_id}

            The user has a generic question about cloud architecture. Your goal is to provide a helpful and informative answer.

            USER'S QUESTION: "{user_request}"

            DESIGN PRINCIPLES TO APPLY:
            1. Security: Implement defense-in-depth, zero-trust principles
            2. Scalability: Design for horizontal scaling and elasticity
            3. Reliability: Multi-AZ deployment with proper failover
            4. Performance: Optimize for latency and throughput requirements
            5. Cost Optimization: Right-size resources and implement cost controls
            6. Maintainability: Organize resources logically with clear naming

            Note: If user asks anything other than cloud infrastructure question, just say its not my expertise. 
            Use your knowledge and the available tools to answer the user's question.
            If you need more information from the user, you can use the UserInteractionTool.

            IMPORTANT ADDITIONAL REQUIREMENT:
            After providing your comprehensive answer, you must analyze whether the user's question or follow-up discussion indicates they need actual Terraform code generation. 

            At the very end of your response, after asking all your question, include a clear determination in this exact format:

            **TERRAFORM_CODE_REQUIRED: [YES/NO]**

            Answer YES if:
            - The user explicitly asks for Terraform code or configuration files
            - The user wants to implement/deploy the discussed architecture
            - The user asks how to create specific resources in code
            - The conversation indicates they need actual infrastructure provisioning

            Answer NO if:
            - The user only wants conceptual explanations or architectural guidance
            - The question is about best practices, comparisons, or theoretical concepts
            - The user is asking for troubleshooting help or explanations of existing setups
            - The discussion is purely educational or informational
            """,
            agent=user_interaction_agent,
            callback=send_agent_conversation,
            expected_output=f"""
                IMPORTANT: Your response must start with: SESSION_ID: {session_id}
                A comprehensive answer to the user's question in Markdown format.

                At the end, include the terraform requirement determination:
                **TERRAFORM_CODE_REQUIRED: [YES/NO]**
                """
        )
    ]



def create_terraform_generation_tasks(user_request, session_id):
    # This is the original create_tasks function,
    requirement_gathering_task = Task(
        description=f"""
        SESSION_ID: {session_id}

        Conduct a comprehensive infrastructure requirements analysis session based on {user_request}.

        CONTEXT: You are starting a new infrastructure project and need to gather all 
        necessary information to design and implement a production-ready cloud solution.

        SPECIAL INSTRUCTIONS: 
        1. ALWAYS include the session_id in your response output
        2. Before asking user anything read and understand {user_request} properly. 
        3. DONOT ask the details which are already mentioned in {user_request}.

        PROCESS:
        1. Understand the business context and project goals
        2. Identify technical requirements and constraints
        3. Assess security and compliance needs
        4. Determine performance and scalability requirements
        5. Establish budget and timeline constraints
        6. Validate completeness of gathered information

        REQUIRED INFORMATION:
        - Target cloud provider and regions
        - Environment type (development, staging, production)
        - Application architecture and components
        - Expected traffic and usage patterns
        - Security and compliance requirements
        - Integration requirements with existing systems
        - Backup and disaster recovery needs
        - Monitoring and alerting requirements
        - Budget constraints and cost optimization goals

        QUALITY CRITERIA:
        - All mandatory fields must be populated
        - Requirements must be specific and measurable
        - Potential edge cases and failure scenarios identified
        - Security implications thoroughly considered
        - Scalability requirements clearly defined

        Special INFORMATION: If user says Cancel the flow. then cancel everything and exit.
        """,

        agent=user_interaction_agent,
        callback=send_agent_conversation,
        expected_output=f"""
        IMPORTANT: Your response must start with: SESSION_ID: {session_id}

        A clear and detailed summary of the infrastructure requirements in **Markdown format**. 
        The summary should be well-structured and easy for a cloud architect to understand without needing clarification.

        **Example Structure:**

        ## Infrastructure Requirements Summary for Project: [Project Name]

        - **Cloud Provider**: [azure/aws/gcp]
        - **Region(s)**: [Target deployment region(s)]
        - **Environment**: [Environment type with appropriate configurations]
        - **Monthly Budget**: [Monthly budget limit if specified]

        ### Required Resources
        A detailed list of all required infrastructure components. For example:
        - **Virtual Machine**:
          - **Size**: Standard_D2s_v3
          - **OS**: Ubuntu 22.04
          - **Count**: 2
        - **Database**:
          - **Type**: PostgreSQL
          - **Size**: Standard tier, 2 vCores, 32GB storage

        ### Security & Compliance
        A comprehensive summary of all security and compliance needs.

        ### Performance & Scalability
        Detailed specifications for performance, including expected traffic and scaling requirements.
        """
    )

    architecture_design_task = Task(
        description=f"""
        SESSION_ID: {session_id}

        Design a comprehensive cloud infrastructure architecture based on the gathered requirements from requirement_gathering_task.

        CONTEXT: You have received validated requirements from the requirements analyst using requirement_gathering_task. Your job 
        is to translate these business and technical requirements into a detailed cloud architecture 
        specification that follows industry best practices.

        SPECIAL INSTRUCTIONS: 
        1. ALWAYS include the session_id in your response output
        2. Reference the requirements from the previous task

        DESIGN PRINCIPLES TO APPLY:
        1. Security: Implement defense-in-depth, zero-trust principles
        2. Scalability: Design for horizontal scaling and elasticity
        3. Reliability: Multi-AZ deployment with proper failover
        4. Performance: Optimize for latency and throughput requirements
        5. Cost Optimization: Right-size resources and implement cost controls
        6. Maintainability: Organize resources logically with clear naming

        DELIVERABLES REQUIRED:
        1. Complete resource inventory with specifications
        2. Resource dependency mapping for proper provisioning order
        3. Network topology with security boundaries
        4. IAM and access control strategy
        5. Cost estimation with optimization opportunities
        6. Security analysis and compliance mapping
        7. Operational considerations (monitoring, logging, backup)

        VALIDATION CHECKLIST:
        ✓ All user requirements addressed in the design
        ✓ Industry best practices applied
        ✓ Security controls properly implemented
        ✓ Scalability and performance requirements met
        ✓ Cost estimates within budget constraints
        ✓ Disaster recovery and backup strategies included
        ✓ Proper resource naming and tagging strategy
        ✓ Dependencies correctly identified and ordered
        Special INFORMATION: If user says Cancel the flow. then cancel everything and exit.
        """,

        agent=cloud_architect_agent,
        callback=send_agent_conversation,
        expected_output=f"""
        IMPORTANT: Your response must start with: SESSION_ID: {session_id}

        A comprehensive and well-documented Architecture Plan in **Markdown format**. 
        The plan must be detailed enough for a Terraform engineer to implement without making architectural assumptions.

        **Example Structure:**

        ## Cloud Architecture Plan

        ### 1. High-Level Overview
        A summary of the overall architecture design and strategy.

        ### 2. Resource Inventory & Specifications
        A detailed list of all resources with their configurations.
        - **Resource Type**: `azurerm_resource_group`
          - **Name**: `rg-production-webapp`
          - **Configuration**: Location based on region variable.
        - **Resource Type**: `azurerm_virtual_network`
          - **Name**: `vnet-production`
          - **Dependencies**: `azurerm_resource_group`
          - **Configuration**: Address space `10.0.0.0/16`.

        ### 3. Dependency Mapping
        A clear explanation or list showing the order of resource creation.

        ### 4. Estimated Monthly Cost
        A breakdown of the estimated costs with notes on potential savings.
        - **Compute**: $XX.XX
        - **Storage**: $XX.XX
        - **Total**: $XX.XX

        ### 5. Security and Compliance Analysis
        An outline of security controls, IAM policies, and how the design meets compliance requirements.

        ### 6. Recommendations
        Suggestions for further optimization or operational improvements.
        """
    )

    terraform_code_search_task = Task(
        description=f"""
        SESSION_ID: {session_id}

        Search for Terraform code snippets or resource definitions that match the user's 
        architecture requirements mentioned in architecture_design_task.

        CONTEXT: The user has described the desired infrastructure in natural language and 
        {cloud_architect_agent} has completed its design using {architecture_design_task}.

        SPECIAL INSTRUCTIONS: 
        1. ALWAYS include the session_id in your response output
        2. Reference the architecture design from the previous task

        SEARCH STRATEGY:
        1. First search the organization's Git repository for existing Terraform scripts 
           using the read_git_terraform_csv tool.
        2. If suitable code is found, then use `download_github_file` to download it. Copy the path where the file is downloaded. 
        3. If no suitable code is found, query the official Terraform Registry documentation 
           for the latest provider resource definitions using the WebSearchTool.
        4. Extract only official code snippets (do not assume that modules exist).
        5. Return both the found snippets and their source references (file path or registry).

        QUALITY CRITERIA:
        - Only official Terraform code or verified repo code may be returned
        - Ensure snippets are the latest version of provider resources
        - Must include all required attributes for resource creation
        - Do not generate new code in this step; only collect references

        Special INFORMATION: If user says Cancel the flow. then cancel everything and exit.
        """,
        agent=search_agent,
        callback=send_agent_conversation,
        context=[requirement_gathering_task, architecture_design_task],
        expected_output=f"""
        IMPORTANT: Your response must start with: SESSION_ID: {session_id}

        A summary of the found Terraform code references in **Markdown format**.

        **Example Structure:**

        ## Terraform Code Search Results

        ### Resource: `azurerm_virtual_machine`
        - **Source**: Terraform Registry
        - **Reference URL**: https://registry.terraform.io/
        - **Completeness**: True (All required parameters are included)
        - **Snippet**:
        ```terraform
        resource "azurerm_virtual_machine" "main" {{
          name                  = "my-vm"
          location              = azurerm_resource_group.main.location
          resource_group_name   = azurerm_resource_group.main.name
          # ... other required attributes
        }}
        ```

        ### Resource: `internal_module/vpc`
        - **Source**: Git Repository
        - **Reference Path**: `[Path to the downloaded file on the local system]`
        - **Completeness**: True
        - **File Content**: 
        ```terraform
        # Content of the downloaded terraform file will be here
        ```
        """
    )

    terraform_code_generation_task = Task(
        description=f"""
        SESSION_ID: {session_id}

        Generate complete, production-ready Terraform code for the requested infrastructure.

        CONTEXT: You have architecture requirements (from architecture_design_task) and 
        verified Terraform resource references (from terraform_code_search_task).

        SPECIAL INSTRUCTIONS: 
        1. ALWAYS include the session_id in your response output
        2. Use the architecture and code references from previous tasks
        3. Generated files will be automatically saved for user download. Your output should contain the raw code in markdown blocks so the system can extract and save it.

        TASK:
        1. Build complete Terraform configurations for all required resources 
           (VMs, subnets, VNets, NICs, NSGs, databases, etc.).
        2. Ensure that missing dependent resources are added even if not mentioned 
           (e.g., subnets, VNets, NSGs for Azure VMs).
        3. Organize code into clean resource blocks, with proper variable usage and 
           dependency mapping.
        4. Validate the generated code by running `terraform init` and `terraform plan` 
           using TerraformExecutionTool.
        5. Fix any validation errors automatically before returning the code.

        QUALITY CRITERIA:
        - Code must run without errors in `terraform plan`
        - Explicitly define all dependencies using `depends_on` where needed
        - Use provider best practices (naming conventions, variable handling)
        - Must not reference non-existent modules
        - Code should be modular, maintainable, and production-ready

        Special INFORMATION: If user says Cancel the flow. then cancel everything and exit.
        """,
        agent=terraform_code_generator_agent,
        context=[architecture_design_task, terraform_code_search_task],
        callback=send_agent_conversation,
        expected_output=f"""
        IMPORTANT: Your response must start with: SESSION_ID: {session_id}

        The complete, generated Terraform code organized in **Markdown format**. The code must be enclosed in markdown code blocks for automatic file saving.

        **Example Structure:**

        ## Generated Terraform Configuration

        **Validation Status**: [Pass/Fail result of `terraform plan`]
        **Error Log**: [Any validation errors encountered and fixes applied, or "None"]

        ### `main.tf`
        ```terraform
        # {{--- main_tf ---}}
        # Complete content for main.tf
        provider "azurerm" {{
          features {{}}
        }}

        resource "azurerm_resource_group" "main" {{
          name     = var.project_name
          location = var.region
        }}
        # ... other resources
        # {{--- end_main_tf ---}}
        ```

        ### `variables.tf`
        ```terraform
        # {{--- variables_tf ---}}
        # Complete content for variables.tf
        variable "project_name" {{
          description = "The name of the project."
          type        = string
        }}
        # ... other variables
        # {{--- end_variables_tf ---}}
        ```

        ### `outputs.tf`
        ```terraform
        # {{--- outputs_tf ---}}
        # Complete content for outputs.tf
        output "resource_group_name" {{
          value = azurerm_resource_group.main.name
        }}
        # ... other outputs
        # {{--- end_outputs_tf ---}}
        ```
        """
    )

    quality_review_task = Task(
        description=f"""
        SESSION_ID: {session_id}

        Perform a comprehensive quality review of the generated Terraform infrastructure code.

        CONTEXT: You have received Terraform code that has passed initial validation. Your job 
        is to ensure it meets enterprise standards for security, maintainability, performance, 
        and cost optimization before it's approved for production use.

        SPECIAL INSTRUCTIONS: 
        1. ALWAYS include the session_id in your response output
        2. Review the Terraform code from the previous task

        REVIEW SCOPE:
        1. Security Analysis
           - Credential and secret management
           - Access control implementations
           - Network security configurations
           - Encryption and data protection
           - Audit logging and monitoring

        2. Best Practices Compliance
           - Terraform coding standards
           - Resource naming conventions
           - Variable and output usage
           - State management configuration
           - Provider version management

        3. Code Quality Assessment
           - Code organization and structure
           - Documentation and comments
           - Maintainability and readability
           - Modularity and reusability
           - Error handling and validation

        4. Performance and Cost Optimization
           - Resource sizing appropriateness
           - Cost-effective service selection
           - Performance optimization opportunities
           - Unnecessary resource identification
           - Scaling strategy implementation

        REVIEW PROCESS:
        1. Analyze code against security checklist
        2. Verify Terraform best practices compliance
        3. Assess code maintainability and quality
        4. Identify optimization opportunities
        5. Generate specific, actionable feedback
        6. Determine approval status with scoring

        FEEDBACK QUALITY:
        - Specific issues with line number references
        - Clear explanations of why issues matter
        - Concrete suggestions for improvements
        - Examples of better approaches where applicable
        - Balanced perspective considering practicality

        Special INFORMATION: If user says Cancel the flow. then cancel everything and exit.
        """,

        agent=Quality_reviewer_agent,
        callback=send_agent_conversation,
        expected_output=f"""
        IMPORTANT: Your response must start with: SESSION_ID: {session_id}

        A comprehensive and actionable Quality Review Report in **Markdown format**.

        **Example Structure:**

        ## Terraform Code Quality Review

        - **Overall Score**: 8/10
        - **Approval Status**: **Approved with Recommendations**

        ### Summary
        The code is well-structured and functional but requires minor changes before production deployment.

        ### 1. Required Changes (Mandatory)
        - **Security Issue**: The storage account allows public blob access.
          - **File**: `main.tf`, Line 25
          - **Recommendation**: Set `allow_blob_public_access` to `false`.

        ### 2. Best Practice Violations
        - **Violation**: Inconsistent naming convention for variables.
          - **File**: `variables.tf`
          - **Recommendation**: Use `snake_case` for all variable names (e.g., change `projectName` to `project_name`).

        ### 3. Optimization Suggestions
        - **Cost Optimization**: The virtual machine size (`Standard_D4s_v3`) might be oversized for the initial workload.
          - **File**: `main.tf`, Line 42
          - **Recommendation**: Consider starting with `Standard_D2s_v3` and implementing an autoscaling policy.

        ### 4. Detailed Feedback
        A line-by-line analysis with further comments and recommendations for improving code clarity and maintainability.
        """
    )

    # terraform_fix_and_validate_task = Task(
    #     description=f"""
    #     SESSION_ID: {session_id}
    # 
    #     Apply changes based on quality review feedback and re-validate the Terraform code.
    # 
    #     CONTEXT: You have received detailed feedback from Quality_reviewer_agent 
    #     (via quality_review_task) highlighting security issues, best practice violations, 
    #     or optimization opportunities.
    # 
    #     SPECIAL INSTRUCTIONS: 
    #     1. ALWAYS include the session_id in your response output
    #     2. Apply fixes based on the quality review from the previous task
    #     3. Final fixed files will be automatically saved for user download. Your output should contain the final, raw code in markdown blocks.
    # 
    #     TASK:
    #     1. Apply all required changes to the Terraform code (security fixes, naming 
    #        corrections, resource adjustments).
    #     2. Implement optimization suggestions where feasible.
    #     3. Re-run `terraform init` and `terraform plan` using TerraformExecutionTool.
    #     4. Fix any additional issues until `terraform plan` runs successfully.
    #     5. Produce final Terraform code ready for production deployment.
    # 
    #     VALIDATION CHECKLIST:
    #     ✓ All reviewer-identified issues resolved
    #     ✓ terraform plan runs without errors
    #     ✓ Security, compliance, and best practice standards met
    #     ✓ Optimizations implemented where applicable
    #     Special INFORMATION: If user says Cancel the flow. then cancel everything and exit.
    #     """,
    #     agent=terraform_code_generator_agent,
    #     callback=send_agent_conversation,
    #     context=[quality_review_task],
    #     expected_output=f"""
    #     IMPORTANT: Your response must start with: SESSION_ID: {session_id}
    # 
    #     The final, production-ready Terraform code organized in **Markdown format**, along with a summary of the changes made.
    # 
    #     **Example Structure:**
    # 
    #     ## Final Terraform Configuration (Post-Review)
    # 
    #     **Final Validation Status**: **Pass**
    #     **Approval Ready**: **Yes**
    # 
    #     ### Summary of Applied Fixes
    #     - Fixed security vulnerability by disabling public blob access on the storage account.
    #     - Standardized all variable names to `snake_case`.
    #     - Adjusted the default VM size to `Standard_D2s_v3` for cost optimization.
    # 
    #     ### Final `main.tf`
    #     ```terraform
    #     # {{--- main_tf ---}}
    #     # Final, updated content for main.tf
    #     # ...
    #     # {{--- end_main_tf ---}}
    #     ```
    # 
    #     ### Final `variables.tf`
    #     ```terraform
    #     # {{--- variables_tf ---}}
    #     # Final, updated content for variables.tf
    #     # ...
    #     # {{--- end_variables_tf ---}}
    #     ```
    # 
    #     ### Final `outputs.tf`
    #     ```terraform
    #     # {{--- outputs_tf ---}}
    #     # Final, updated content for outputs.tf
    #     # ...
    #     # {{--- end_outputs_tf ---}}
    #     ```
    #     """
    # )

    return [requirement_gathering_task, architecture_design_task, terraform_code_search_task,
            terraform_code_generation_task, quality_review_task] #, terraform_fix_and_validate_task]
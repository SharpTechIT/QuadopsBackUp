const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? 'https://riwtnauneyebqhhpfjya.supabase.co',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJpd3RuYXVuZXllYnFoaHBmanlhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA0NDA1NzEsImV4cCI6MjA2NjAxNjU3MX0.xgyciQdfduR6SPBkUt1c6OapY_a8jHDIHzETRZW9U6E'
    )

    const { ticketId, status } = await req.json()

    if (!ticketId || !status) {
      return new Response(
        JSON.stringify({ error: 'Missing ticketId or status' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Validate status
    if (!['approved', 'rejected'].includes(status)) {
      return new Response(
        JSON.stringify({ error: 'Invalid status. Must be approved or rejected' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Update ticket status
    const { data: updatedTickets, error: updateError } = await supabaseClient
      .from('tickets')
      .update({ 
        status: status,
        updated_at: new Date().toISOString()
      })
      .eq('id', ticketId)
      .select()

    if (updateError) {
      throw updateError
    }

    // Check if any rows were updated
    if (!updatedTickets || updatedTickets.length === 0) {
      return new Response(
        JSON.stringify({ error: 'Ticket not found or already processed' }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    const ticket = updatedTickets[0]

    // If approved, create workflow run
    if (status === 'approved' && ticket.automation_data) {
      const automationData = ticket.automation_data
      
      const { error: workflowError } = await supabaseClient
        .from('workflow_runs')
        .insert([{
          workflow_id: `${automationData.tower}-${automationData.automation_type}-${Date.now()}`,
          workflow_name: automationData.automation_name,
          tower: automationData.tower,
          automation_type: automationData.automation_type,
          status: 'pending',
          form_data: automationData.form_data,
          user_id: ticket.user_id
        }])

      if (workflowError) {
        console.error('Error creating workflow run:', workflowError)
        // Don't fail the approval, just log the error
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Ticket ${status} successfully`,
        ticket: ticket
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})
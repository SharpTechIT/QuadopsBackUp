import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { ChevronRight, ArrowLeft, Send, AlertCircle, CheckCircle, Info } from 'lucide-react';
import { supabase } from '../config/supabase';
import { useAuth } from '../hooks/useAuth';
import { SearchableSelect } from '../components/forms/SearchableSelect';

const towerNames: Record<string, string> = {
    'active-directory': 'Active Directory',
    'exchange': 'Exchange',
    'windows': 'Windows',
    'linux': 'Linux',
    'database': 'Database',
    'network': 'Network',
    'azure': 'Azure',
    'o365': 'O365',
    'aws': 'AWS',
    'gcp': 'Google Cloud',
};

interface FormField {
    name: string;
    label: string;
    type: string;
    required?: boolean;
    options?: string[];
    data_source_id?: string;
    hidden_on_load?: boolean;
    conditional_display?: {
        depends_on_field: string;
        condition_type: 'equals' | 'not_equals' | 'contains' | 'regex';
        condition_value: string;
        regex_pattern?: string;
    };
}

interface AutomationTemplate {
    id: string;
    name: string;
    description: string;
    tower: string;
    automation_type: string;
    is_active: boolean;
    form_schema: {
        fields: FormField[];
    };
}

const CustomModal: React.FC<{
    message: string;
    type: 'success' | 'error' | 'warning';
    onClose: () => void;
    onConfirm?: () => void;
}> = ({ message, type, onClose, onConfirm }) => {
    let bgColor, textColor, borderColor, Icon;

    switch (type) {
        case 'success':
            bgColor = 'bg-green-100 dark:bg-green-900';
            textColor = 'text-green-800 dark:text-green-200';
            borderColor = 'border-green-400 dark:border-green-600';
            Icon = CheckCircle;
            break;
        case 'warning':
            bgColor = 'bg-yellow-100 dark:bg-yellow-900';
            textColor = 'text-yellow-800 dark:text-yellow-200';
            borderColor = 'border-yellow-400 dark:border-yellow-600';
            Icon = Info;
            break;
        case 'error':
        default: // Default to error if type is not recognized
            bgColor = 'bg-red-100 dark:bg-red-900';
            textColor = 'text-red-800 dark:text-red-200';
            borderColor = 'border-red-400 dark:border-red-600';
            Icon = AlertCircle;
            break;
    }

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className={`rounded-lg shadow-lg p-6 max-w-sm w-full ${bgColor} border ${borderColor} dark:border-gray-700`}>
                <div className="text-center">
                    {Icon && <Icon className={`h-10 w-10 mx-auto mb-3 ${textColor}`} />}
                    <h3 className={`text-lg font-semibold mb-2 ${textColor}`}>
                        {type.charAt(0).toUpperCase() + type.slice(1)}!
                    </h3>
                    <p className={`text-sm ${textColor} mb-4`}>{message}</p>
                    <button
                        onClick={() => {
                            onClose();
                            if (onConfirm) onConfirm();
                        }}
                        className={`px-4 py-2 rounded-md font-semibold text-white ${type === 'success' ? 'bg-green-600 hover:bg-green-700' :
                                type === 'warning' ? 'bg-yellow-600 hover:bg-yellow-700' :
                                    'bg-red-600 hover:bg-red-700'
                            }`}
                    >
                        Okay
                    </button>
                </div>
            </div>
        </div>
    );
};

export const AutomationForm: React.FC = () => {
    const { towerId, automationId } = useParams<{ towerId: string; automationId: string }>();
    const navigate = useNavigate();
    const { user } = useAuth();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [formSchema, setFormSchema] = useState<AutomationTemplate | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [modalMessage, setModalMessage] = useState('');
    const [modalType, setModalType] = useState<'success' | 'error' | 'warning'>('success');
    const [dynamicOptions, setDynamicOptions] = useState<Record<string, any[]>>({});
    const [ setWorkflowConfig] = useState<any>(null);
    

    const towerName = towerNames[towerId!] || towerId;

    const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm();

    // Watch all form values for conditional display
    const watchedValues = watch();

    // Define evaluateCondition first using useCallback
    const evaluateCondition = useCallback((
        fieldValue: any,
        conditionType: string,
        conditionValue: string,
        regexPattern?: string
    ): boolean => {
        if (!fieldValue && fieldValue !== 0 && fieldValue !== false) return false;

        const stringValue = String(fieldValue).toLowerCase();
        const conditionValueLower = conditionValue.toLowerCase();

        switch (conditionType) {
            case 'equals':
                return stringValue === conditionValueLower;
            case 'not_equals':
                return stringValue !== conditionValueLower;
            case 'contains':
                return stringValue.includes(conditionValueLower);
            case 'regex':
                try {
                    const pattern = regexPattern || conditionValue;
                    const regex = new RegExp(pattern, 'i');
                    return regex.test(stringValue);
                } catch (e) {
                    console.error('Invalid regex pattern:', regexPattern || conditionValue);
                    return false;
                }
            default:
                return false;
        }
    }, []);

    // Now use evaluateCondition in useMemo - it's already defined above
    const fieldVisibility = useMemo(() => {
        if (!formSchema) return {};

        const visibility: Record<string, boolean> = {};

        formSchema.form_schema.fields.forEach(field => {
            // Fields are visible by default unless hidden_on_load is true
            let isVisible = !field.hidden_on_load;

            // Check conditional display rules
            if (field.conditional_display?.depends_on_field) {
                const dependsOnValue = watchedValues[field.conditional_display.depends_on_field];
                isVisible = evaluateCondition(
                    dependsOnValue,
                    field.conditional_display.condition_type,
                    field.conditional_display.condition_value,
                    field.conditional_display.regex_pattern
                );
            }

            visibility[field.name] = isVisible;
        });

        return visibility;
    }, [formSchema, watchedValues, evaluateCondition]);

    useEffect(() => {
        fetchFormDataAndApiConfig();
    }, [towerId, automationId]);

    /**
     * Fetches the form schema from Supabase and the FastAPI API configuration.
     */
    const fetchFormDataAndApiConfig = async () => {
        setIsLoading(true);
        try {
            // Fetch automation template (form schema)
            const { data: templateData, error: templateError } = await supabase
                .from('automation_templates')
                .select('*')
                .eq('tower', towerId)
                .eq('automation_type', automationId)
                .eq('is_active', true)
                .single();

            if (templateError) throw templateError;
            setFormSchema(templateData as AutomationTemplate);

            // Load data source mappings and fetch dynamic options
            if (templateData) {
                await loadDataSourceMappings(templateData.id);
                await loadWorkflowConfiguration(templateData.id);
                await loadItsmTools();
            }

        } catch (error: any) {
            console.error('Error fetching form schema or API config:', error.message);
            setModalMessage(`Error loading automation form or API configuration: ${error.message}`);
            setModalType('error');
            setShowModal(true);
            setFormSchema(null); // Ensure formSchema is null if there's an error
        } finally {
            setIsLoading(false);
        }
    };

    const loadWorkflowConfiguration = async (templateId: string) => {
        try {
            const { data: config, error } = await supabase
                .from('workflow_configurations')
                .select(`
                    *,
                    itsm_tool:itsm_tool_id(id, name, provider, config, status),
                    version_control_tool:version_control_tool_id(id, name, provider, config, status)
                `)
                .eq('automation_template_id', templateId)
                .eq('is_active', true)
                .single();

            if (error && error.code !== 'PGRST116') {
                console.error('Error loading workflow configuration:', error);
                return;
            }

            setWorkflowConfig(config);
            console.log('Loaded workflow configuration:', config);
        } catch (error) {

            console.error('Error in loadWorkflowConfiguration:', error);
        }
    };

    const loadItsmTools = async () => {
        try {
            const { data: tools, error } = await supabase
                .from('tools')
                .select('*')
                .eq('type', 'itsm')
                .eq('status', 'active')
                .order('name', { ascending: true });

            if (error) {
                console.error('Error loading ITSM tools:', error);
                return;
            }

            
            console.log('Loaded ITSM tools:', tools);
        } catch (error) {
            console.error('Error in loadItsmTools:', error);
        }
    };

    const loadDataSourceMappings = async (templateId: string) => {
        try {
            // Get data source mappings for this template
            const { data: mappings, error } = await supabase
                .from('data_source_fields')
                .select('field_name, data_source_id')
                .eq('automation_template_id', templateId);

            if (error) throw error;

            // Load options for fields with data sources
            const optionsPromises = mappings?.map(async (mapping) => {
                try {
                    const response = await fetch(`/api/data-sources/${mapping.data_source_id}/options`);
                    const result = await response.json();

                    if (result.success) {
                        return { fieldName: mapping.field_name, options: result.data };
                    }
                } catch (error) {
                    console.error(`Error loading options for field ${mapping.field_name}:`, error);
                }
                return { fieldName: mapping.field_name, options: [] };
            }) || [];

            const optionsResults = await Promise.all(optionsPromises);

            // Build dynamic options object
            const dynamicOpts: Record<string, any[]> = {};
            optionsResults.forEach(result => {
                dynamicOpts[result.fieldName] = result.options;
            });

            setDynamicOptions(dynamicOpts);

        } catch (error) {
            console.error('Error loading data source mappings:', error);
        }
    };

    /**
     * Generates a unique ticket number.
     * @returns {string} The generated ticket number.
     */
    const generateTicketNumber = (): string => {
        const timestamp = Date.now().toString().slice(-6);
        return `REQ-${new Date().getFullYear()}-${timestamp}`;
    };


    /**
     * Creates ITSM requests in the determined ITSM systems
     *
     * @param {object} automationData - The automation data
     * @returns {Promise<any[]>} Array of ITSM request results
     */
   
    /**
     * Creates a ServiceNow Service Request
     */
    
    const createServiceNowRequestViaAPI = async (automationData: any): Promise<any | null> => {
        try {
            console.log('Preparing payload for ServiceNow API...');

            const payloadForAPI = {
                short_description: `${automationData.automation_name} - ${automationData.tower}`,
                description: formatFormDataDescription(automationData.form_data),
                ...automationData.form_data // Include all form data fields
            };

            console.log('Calling backend API to create ServiceNow request...');
            console.log('Payload:', payloadForAPI);

            const response = await fetch('/api/servicenow/create_service_request', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payloadForAPI),
            });

            console.log('Response status:', response.status);
            console.log('Response headers:', response.headers);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('API response error:', errorText);
                throw new Error(`API request failed: ${response.status} - ${errorText}`);
            }

            const responseData = await response.json();
            console.log('ServiceNow request via API successful:', responseData);

            // Extract the actual ServiceNow response data
            if (responseData.success && responseData.data) {
                return responseData.data.servicenow_response.result;
            } else {
                throw new Error('Invalid response format from API');
            }

        } catch (error) {
            console.error('Error creating ServiceNow request via API:', error);
            throw error;
        }
    };



    /**
     * Formats form data into a readable description
     */
    const formatFormDataDescription = (formData: any): string => {
        if (!formData) return 'No form data provided.';
        let description = 'Automation Request Details:\n\n';
        for (const key in formData) {
            if (Object.prototype.hasOwnProperty.call(formData, key)) {
                description += `${key.replace(/_/g, ' ')}: ${formData[key]}\n`;
            }
        }
        return description;
    };

    /**
     * Handles the form submission.
     * @param {object} data - The validated form data from react-hook-form.
     */
    const onSubmit = async (data: any) => {

        setIsSubmitting(true);
        let successMessage = '';
        let finalModalType: 'success' | 'error' | 'warning' = 'success';

        try {
            const ticketNumber = generateTicketNumber();
            const automationData = {
                tower: towerId,
                automation_type: automationId,
                automation_name: formSchema!.name,
                form_data: data,
            };

            console.log('Starting overall ticket creation process...');
            console.log('Automation data:', automationData);

            let serviceNowRequestResult = null;
            let serviceNowError: Error | null = null;

            // Attempt ServiceNow request creation via API
            try {
                console.log('Attempting ServiceNow request creation via API...');
                serviceNowRequestResult = await createServiceNowRequestViaAPI(automationData);

                if (serviceNowRequestResult) {
                    console.log('ServiceNow request created via API:', serviceNowRequestResult);
                    successMessage += `ServiceNow request ${serviceNowRequestResult.number || serviceNowRequestResult.sys_id} created successfully. `;
                }
            } catch (error: any) {
                console.warn('Failed to create ServiceNow request via API:', error.message);
                serviceNowError = error;
                successMessage += `Warning: ServiceNow request failed (${error.message}). `;
                finalModalType = 'warning';
            }

            // Create internal ticket
            console.log('Creating internal ticket...');
            const { data: ticket, error: ticketError } = await supabase
                .from('tickets')
                .insert([{
                    ticket_number: ticketNumber,
                    title: `${formSchema!.name} - Approval Required`,
                    status: 'pending_approval',
                    priority: 'medium',
                    itsm_reference: serviceNowRequestResult?.number,
                    itsm_type: "servicenow",
                    automation_data: {
                        ...automationData,
                        servicenow_request: serviceNowRequestResult ? {
                            request_id: serviceNowRequestResult.sys_id,
                            request_number: serviceNowRequestResult.number,
                            state: serviceNowRequestResult.state,
                            sys_id: serviceNowRequestResult.sys_id
                        } : null,
                        servicenow_error: serviceNowError ? serviceNowError.message : null
                    },
                    user_id: user?.id,
                }])
                .select()
                .single();

            if (ticketError) {
                throw new Error(`Failed to create internal ticket: ${ticketError.message}`);
            }

            console.log('Internal ticket created successfully:', ticket);
            successMessage = `Request submitted successfully! Internal Ticket ${ticketNumber} has been created and is pending approval. ${successMessage}`;
            setModalMessage(successMessage);
            setModalType(finalModalType);
            setShowModal(true);

        } catch (error: any) {
            console.error('Critical error during submission process:', error);
            setModalMessage(`Critical error submitting request: ${error.message || 'Please try again.'}`);
            setModalType('error');
            setShowModal(true);
        } finally {
            setIsSubmitting(false);
        }
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    if (!formSchema) {
        return (
            <div className="text-center py-12">
                <h2 className="text-lg font-medium text-gray-900 dark:text-white">Form not found</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                    The requested automation form could not be loaded. Please check the URL or configuration.
                </p>
                {showModal && (
                    <CustomModal
                        message={modalMessage}
                        type={modalType}
                        onClose={() => setShowModal(false)}
                    />
                )}
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Custom Modal for alerts */}
            {showModal && (
                <CustomModal
                    message={modalMessage}
                    type={modalType}
                    onClose={() => setShowModal(false)}
                    onConfirm={() => navigate('/tickets')}
                />
            )}

            {/* Breadcrumb */}
            <nav className="flex" aria-label="Breadcrumb">
                <ol className="flex items-center space-x-4">
                    <li>
                        <Link to="/agents" className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                            Bots
                        </Link>
                    </li>
                    <li>
                        <ChevronRight className="h-4 w-4 text-gray-400" />
                    </li>
                    <li>
                        <Link to={`/agents/${towerId}`} className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                            {towerName}
                        </Link>
                    </li>
                    <li>
                        <ChevronRight className="h-4 w-4 text-gray-400" />
                    </li>
                    <li>
                        <span className="text-gray-900 dark:text-white font-medium">{formSchema.name}</span>
                    </li>
                </ol>
            </nav>

            {/* Header */}
            <div className="flex items-center space-x-4">
                <Link
                    to={`/agents/${towerId}`}
                    className="p-2 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700"
                >
                    <ArrowLeft className="h-4 w-4" />
                </Link>
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{formSchema.name}</h1>
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                        {formSchema.description || 'Fill out the form below to submit this automation request for approval'}
                    </p>
                </div>
            </div>

            {/* Form */}
            <div className="bg-white dark:bg-gray-800 shadow-sm rounded-lg border border-gray-200 dark:border-gray-700">
                <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {formSchema.form_schema?.fields?.map((field: FormField) => {
                            // Skip rendering if field is not visible
                            if (!fieldVisibility[field.name]) {
                                return null;
                            }

                            // Use dynamic options if available, otherwise fall back to static options
                            const fieldOptions = Array.isArray(dynamicOptions[field.name])
                                ? dynamicOptions[field.name]
                                : Array.isArray(field.options)
                                    ? field.options.map(opt => ({ value: opt, label: opt }))
                                    : [];

                            return (
                                <div key={field.name} className={field.type === 'textarea' ? 'md:col-span-2' : ''}>
                                    <label htmlFor={field.name} className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                        {field.label}
                                        {field.required && <span className="text-red-500 ml-1">*</span>}
                                        {dynamicOptions[field.name] && (
                                            <span className="ml-2 text-xs text-blue-600 dark:text-blue-400">(Dynamic)</span>
                                        )}
                                        {field.conditional_display?.depends_on_field && (
                                            <span className="ml-2 text-xs text-purple-600 dark:text-purple-400">(Conditional)</span>
                                        )}
                                    </label>

                                    {field.type === 'select' ? (
                                        <SearchableSelect
                                            options={fieldOptions}
                                            value={watchedValues[field.name] || ''}
                                            onChange={(value) => setValue(field.name, value)}
                                            placeholder={`Select ${field.label}`}
                                            name={field.name}
                                            required={field.required}
                                            className="w-full"
                                        />
                                    ) : field.type === 'textarea' ? (
                                        <textarea
                                            id={field.name}
                                            rows={3}
                                            {...register(field.name, { required: field.required })}
                                            className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                            placeholder={`Enter ${field.label.toLowerCase()}`}
                                        />
                                    ) : (
                                        <input
                                            type={field.type}
                                            id={field.name}
                                            {...register(field.name, { required: field.required })}
                                            className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                            placeholder={`Enter ${field.label.toLowerCase()}`}
                                        />
                                    )}

                                    {errors[field.name] && (
                                        <p className="mt-1 text-sm text-red-600 dark:text-red-400">This field is required</p>
                                    )}
                                </div>
                            );
                        })}
                    </div>

                    <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200 dark:border-gray-700">
                        <button
                            type="submit"
                            disabled={isSubmitting}
                            className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                        >
                            {isSubmitting ? (
                                <>
                                    <div className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full"></div>
                                    Submitting...
                                </>
                            ) : (
                                <>
                                    <Send className="h-4 w-4 mr-2" />
                                    Submit for Approval
                                </>
                            )}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};
import { supabase } from '../config/supabase';
import { ChatMessage } from '../types';

/**
 * This service acts as an adapter between the chat components and the specific Supabase schema.
 * It maps the concept of "Chat Sessions" to "Agent Incidents" and "Messages" to "Agent Conversations".
 */

// Fetch all chat sessions (mapped from agent_incidents) for the logged-in user.
// NOTE: This assumes you have Row Level Security (RLS) policies in place on the 
// agent_incidents table to ensure users can only see their own incidents.
export const getChatSessions = async () => {
  const { data, error } = await supabase
    .from('chat_sessions')
    .select('id, title, created_at')
    .order('created_at', { ascending: false });

  if (error) {
    console.error("Error fetching chat sessions (incidents):", error);
    throw error;
  }
  return data || [];
};

// Fetch all messages for a given session (mapped from agent_conversations).
export const getMessagesForSession = async (sessionId: string): Promise<ChatMessage[]> => {
  const { data, error } = await supabase
    .from('chat_messages')
    .select('id, text:text, sender:sender, timestamp:created_at')
    .eq('session_id', sessionId)
    .order('created_at', { ascending: true });

  if (error) {
    console.error("Error fetching messages for session:", error);
    throw error;
  }

  // Adapt the fetched data to the ChatMessage type used by the frontend components.
  const adaptedMessages = (data || []).map(msg => ({
    ...msg,
    // Normalize sender: the DB might store specific agent names, but the UI just needs 'user' or 'agent'.
    sender: msg.sender === 'user' ? 'user' : 'agent',
  }));

  return adaptedMessages as ChatMessage[];
};

// Create a new chat session (as an agent_incident).
export const createChatSession = async (title: string) => {
  // Generate a unique incident number for the new chat.
  
  const { data, error } = await supabase
    .from('chat_sessions')
    .insert({
      title: title
    })
    .select()
    .single();

  if (error) {
    console.error("Error creating new incident:", error);
    throw error;
  }
  return data;
};

// Add a message to a chat session (as an agent_conversation).
export const addMessage = async (sessionId: string, sender: 'user' | 'agent', text: string) => {
  const { data, error } = await supabase
    .from('chat_messages')
    .insert({
      session_id: sessionId,
      sender: sender, // Maps directly to 'user' or 'agent'.
      text: text,
    })
    .select()
    .single();
  
  if (error) {
    console.error("Error adding message to conversation:", error);
    throw error;
  }
  return data;
};


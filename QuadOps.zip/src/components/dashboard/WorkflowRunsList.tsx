import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import { CheckCircle, XCircle, Clock, AlertCircle, Eye, ExternalLink } from 'lucide-react';
import { WorkflowRun } from '../../types';

interface WorkflowRunsListProps {
  runs: WorkflowRun[];
  onViewDetails: (run: WorkflowRun) => void;
  showViewAll?: boolean;
  onViewAll?: () => void;
}

const statusIcons = {
  success: CheckCircle,
  failed: XCircle,
  pending: Clock,
  running: AlertCircle,
};

const statusColors = {
  success: 'text-green-600 bg-green-100 dark:text-green-400 dark:bg-green-900/50',
  failed: 'text-red-600 bg-red-100 dark:text-red-400 dark:bg-red-900/50',
  pending: 'text-yellow-600 bg-yellow-100 dark:text-yellow-400 dark:bg-yellow-900/50',
  running: 'text-blue-600 bg-blue-100 dark:text-blue-400 dark:bg-blue-900/50',
};

export const WorkflowRunsList: React.FC<WorkflowRunsListProps> = ({ 
  runs, 
  onViewDetails, 
  showViewAll = true, 
  onViewAll 
}) => {
  return (
    <div className="bg-white dark:bg-gray-800 shadow-sm rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
      <div className="px-4 py-5 sm:p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white">Recent Workflow Runs</h3>
          {showViewAll && onViewAll && (
            <button
              onClick={onViewAll}
              className="inline-flex items-center text-sm font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500 dark:hover:text-blue-300"
            >
              View all
              <ExternalLink className="ml-1 h-3 w-3" />
            </button>
          )}
        </div>
        <div className="flow-root">
          <ul className="-my-5 divide-y divide-gray-200 dark:divide-gray-700">
            {runs.map((run) => {
              const StatusIcon = statusIcons[run.status];
              return (
                <li key={run.id} className="py-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex-shrink-0">
                      <div className={`p-2 rounded-full ${statusColors[run.status]}`}>
                        <StatusIcon className="h-4 w-4" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                        {run.workflow_name}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {run.tower} • {formatDistanceToNow(new Date(run.created_at), { addSuffix: true })}
                      </p>
                    </div>
                    <div className="flex-shrink-0">
                      <button
                        onClick={() => onViewDetails(run)}
                        className="inline-flex items-center px-2.5 py-1.5 border border-gray-300 dark:border-gray-600 shadow-sm text-xs font-medium rounded text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      >
                        <Eye className="h-3 w-3 mr-1" />
                        View
                      </button>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </div>
  );
};
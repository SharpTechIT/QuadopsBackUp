// ChatWindow.tsx
import React, { useState, useEffect, useRef } from 'react';
import { Send, ChevronsRight } from 'lucide-react';
import { ChatMessage as ChatMessageType } from '../../types';
import { ChatMessage } from './ChatMessage';
import { getMessagesForSession, createChatSession, addMessage } from '../../api/supabaseService';


interface ChatWindowProps {
    onToggleSidebar: () => void;
    sessionId: string | null;
    onNewSession: (newSessionId: string) => void;
}

export const ChatWindow: React.FC<ChatWindowProps> = ({ onToggleSidebar, sessionId, onNewSession }) => {
    const [messages, setMessages] = useState<ChatMessageType[]>([]);
    const [inputValue, setInputValue] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isWaitingForAgent, setIsWaitingForAgent] = useState(false);
    const [isRealtimeConnected, setIsRealtimeConnected] = useState(false);
    const chatContainerRef = useRef<HTMLDivElement>(null);

    // Polling state
    const [usePolling, setUsePolling] = useState(true); // Force polling
    const pollingInterval = useRef<NodeJS.Timeout | null>(null);

    // Auto-scroll to bottom
    useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
    }, [messages]);

    // Load messages on session change
    useEffect(() => {
        const loadMessages = async () => {
            if (sessionId) {
                setIsLoading(true);
                try {
                    const loadedMessages = await getMessagesForSession(sessionId);
                    setMessages(loadedMessages);
                    
                    // Check if we should be waiting for agent response
                    const lastUserMessage = [...loadedMessages].reverse().find(msg => msg.sender === 'user');
                    const lastAgentMessage = [...loadedMessages].reverse().find(msg => msg.sender === 'agent');
                    
                    // Only set waiting if user's last message is more recent than agent's
                    if (lastUserMessage && (!lastAgentMessage || new Date(lastUserMessage.timestamp) > new Date(lastAgentMessage.timestamp))) {
                        setIsWaitingForAgent(true);
                    } else {
                        setIsWaitingForAgent(false);
                    }
                } catch (error) {
                    console.error('Failed to load messages:', error);
                    setMessages([]);
                    setIsWaitingForAgent(false);
                } finally {
                    setIsLoading(false);
                }
            } else {
                setMessages([]);
                setIsWaitingForAgent(false);
            }
        };
        loadMessages();
    }, [sessionId]);

    // Polling logic - ONLY this will run, no WebSocket
    useEffect(() => {
        if (!sessionId) {
            setIsRealtimeConnected(false);
            if (pollingInterval.current) {
                clearInterval(pollingInterval.current);
                pollingInterval.current = null;
            }
            return;
        }

        console.log('Setting up polling for session:', sessionId);
        setUsePolling(true);

        const startPolling = () => {
            const poll = async () => {
                try {
                    const latestMessages = await getMessagesForSession(sessionId);
                    
                    setMessages((prev) => {
                        // Use message count comparison to detect changes more reliably
                        if (latestMessages.length === prev.length) {
                            // No new messages, but check if content changed
                            const hasContentChanges = latestMessages.some((msg, index) => {
                                const prevMsg = prev[index];
                                return !prevMsg || prevMsg.id !== msg.id || prevMsg.text !== msg.text;
                            });
                            
                            if (!hasContentChanges) {
                                return prev; // No changes
                            }
                        }

                        console.log(`Polling detected changes: ${latestMessages.length} messages (was ${prev.length})`);

                        // Remove temp messages when we have real messages
                        const realMessages = latestMessages.filter(msg => !msg.id.startsWith('temp-'));
                        
                        // Update waiting state based on message flow
                        const lastUserMessage = [...realMessages].reverse().find(msg => msg.sender === 'user');
                        const lastAgentMessage = [...realMessages].reverse().find(msg => msg.sender === 'agent');
                        
                        // Stop waiting if agent has responded after user's last message
                        if (lastUserMessage && lastAgentMessage && 
                            new Date(lastAgentMessage.timestamp) > new Date(lastUserMessage.timestamp)) {
                            setIsWaitingForAgent(false);
                        }

                        return realMessages;
                    });
                } catch (error) {
                    console.error('Polling failed:', error);
                    setIsRealtimeConnected(false);
                }
            };

            // Poll every 2 seconds
            pollingInterval.current = setInterval(poll, 2000);
            console.log('Polling started - checking every 2 seconds');
        };

        startPolling();
        setIsRealtimeConnected(true); // Consider polling as connected

        return () => {
            if (pollingInterval.current) {
                console.log('Stopping polling');
                clearInterval(pollingInterval.current);
                pollingInterval.current = null;
            }
            setIsRealtimeConnected(false);
        };
    }, [sessionId]);

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!inputValue.trim() || isLoading) return;

        const userMessageText = inputValue;
        setInputValue('');
        
        let currentSessionId = sessionId;

        // Handle session creation first, before setting loading state
        if (!currentSessionId) {
            try {
                const newSession = await createChatSession(userMessageText.substring(0, 40));
                currentSessionId = newSession.id;
                if (typeof currentSessionId === 'string') {
                    onNewSession(currentSessionId);
                } else {
                    console.error('Created session but ID is not a string');
                    setInputValue(userMessageText); // Restore input value
                    return;
                }
            } catch (error) {
                console.error('Error creating session:', error);
                setInputValue(userMessageText); // Restore input value
                return;
            }
        }

        if (!currentSessionId) {
            console.error('Session ID is null after attempting to create a session.');
            setInputValue(userMessageText); // Restore input value
            return;
        }

        // Now set loading state after we're sure we have a session
        setIsLoading(true);

        // Add optimistic user message
        const tempId = `temp-user-${Date.now()}`;
        const tempUserMessage: ChatMessageType = {
            id: tempId,
            text: userMessageText,
            sender: 'user',
            timestamp: new Date().toISOString(),
        };
        setMessages((prev) => [...prev, tempUserMessage]);

        try {
            console.log('Saving message to database...');
            await addMessage(currentSessionId, 'user', userMessageText);

            // Determine if this is a response to an agent question
            const lastMessage = messages[messages.length - 1];
            const isResponseToAgent =
                lastMessage &&
                lastMessage.sender === 'agent' &&
                (lastMessage.text.includes('?') ||
                    lastMessage.text.toLowerCase().includes('please') ||
                    lastMessage.text.toLowerCase().includes('what') ||
                    lastMessage.text.toLowerCase().includes('how') ||
                    lastMessage.text.toLowerCase().includes('which') ||
                    lastMessage.text.toLowerCase().includes('would you'));

            console.log('Calling external API...');
            
            let apiSuccess = false;
            try {
                if (isResponseToAgent) {
                    const response = await fetch('http://quadops.eastus.cloudapp.azure.com/api/agent/user-response', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ sessionId: currentSessionId, answer: userMessageText }),
                    });
                    apiSuccess = response.ok;
                } else {
                    console.log(JSON.stringify({ user_query: userMessageText, sessionId: currentSessionId }));
                    const response = await fetch('http://52.147.203.234:8000/invoke-agent', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ user_query: userMessageText, sessionId: currentSessionId }),
                    });
                    apiSuccess = response.ok;
                }
            } catch (apiError) {
                console.error('API call failed:', apiError);
                apiSuccess = false;
            }
            
            if (apiSuccess) {
                // Set waiting for agent ONLY after successful API call
                setIsWaitingForAgent(true);
            } else {
                throw new Error('External API call failed');
            }
            
        } catch (error) {
            console.error('Error during message send:', error);
            
            // Remove the temp message and add error message
            setMessages((prev) => {
                const withoutTemp = prev.filter(msg => msg.id !== tempId);
                const errorMessage: ChatMessageType = {
                    id: `agent-error-${Date.now()}`,
                    text: 'Sorry, I encountered an error. Please try again.',
                    sender: 'agent',
                    timestamp: new Date().toISOString(),
                };
                return [...withoutTemp, errorMessage];
            });
            
            setIsWaitingForAgent(false);
        } finally {
            // Always reset loading state
            console.log('Resetting loading state');
            setIsLoading(false);
        }
    };

    const getPlaceholderText = () => {
        const lastMessage = messages[messages.length - 1];
        const isAgentQuestion =
            lastMessage &&
            lastMessage.sender === 'agent' &&
            (lastMessage.text.includes('?') || 
             lastMessage.text.toLowerCase().includes('please') ||
             lastMessage.text.toLowerCase().includes('what') ||
             lastMessage.text.toLowerCase().includes('how') ||
             lastMessage.text.toLowerCase().includes('which') ||
             lastMessage.text.toLowerCase().includes('would you'));
        return isAgentQuestion ? "Answer the agent's question..." : 'Ask your infrastructure question...';
    };

    const getLoadingIndicator = () => {
        if (isWaitingForAgent) {
            return (
                <div className="flex justify-start">
                    <div className="flex items-center space-x-2 ml-11 px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-700">
                        <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-blue-600"></div>
                        <span className="text-sm text-gray-500 dark:text-gray-400">Agent is thinking...</span>
                    </div>
                </div>
            );
        }

        return null;
    };

    return (
        <div className="flex-1 flex flex-col bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
            {/* Header */}
            <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                <div className="flex items-center space-x-2">
                    <h2 className="text-lg font-medium text-gray-900 dark:text-white">Infra Architect Agent</h2>
                    {/* Connection status indicator */}
                    <div className={`w-2 h-2 rounded-full ${isRealtimeConnected ? 'bg-green-500' : 'bg-red-500'}`}
                        title={usePolling ? 'Polling mode active' : 'Disconnected'} />
                    {usePolling && (
                        <span className="text-xs text-blue-600 dark:text-blue-400">Polling</span>
                    )}
                </div>
                <button
                    onClick={onToggleSidebar}
                    className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                    <ChevronsRight className="h-5 w-5 text-gray-500" />
                </button>
            </div>

            {/* Messages */}
            <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((msg) => (
                    <ChatMessage key={msg.id} message={msg} />
                ))}
                {getLoadingIndicator()}
            </div>

            {/* Input */}
            <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                <form onSubmit={handleSendMessage} className="flex space-x-2">
                    <input
                        type="text"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        placeholder={getPlaceholderText()}
                        className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        disabled={isLoading}
                    />
                    <button
                        type="submit"
                        className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                        disabled={isLoading || !inputValue.trim()}
                    >
                        <Send className="h-5 w-5" />
                    </button>
                </form>
            </div>
        </div>
    );
};

export default ChatWindow;
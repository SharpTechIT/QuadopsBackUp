##########################################
# AWS Provider Configuration
##########################################
provider "aws" {
  region  = var.aws_region
  profile = var.aws_profile
}

##########################################
# Locals - Naming Conventions
##########################################
locals {
  resource_prefix = "${var.project_name}-${var.environment}"
  
  # VPC ID selection: New or Existing
  vpc_id = var.vpc_selection_type == "new" ? aws_vpc.this[0].id : var.existing_vpc_id
  
  # Subnet ID selection: New or Existing
  subnet_id = var.subnet_selection_type == "new" ? aws_subnet.this[0].id : var.existing_subnet_id
  
  # Security Group ID selection: New or Existing
  sg_id = var.sg_selection_type == "new" ? aws_security_group.this[0].id : var.existing_sg_id
}

##########################################
# VPC - Conditional Creation
##########################################
resource "aws_vpc" "this" {
  count                = var.vpc_selection_type == "new" ? 1 : 0
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true

  tags = {
    Name        = "${local.resource_prefix}-vpc"
    Environment = var.environment
  }
}

##########################################
# Subnet - Conditional Creation
##########################################
resource "aws_subnet" "this" {
  count                   = var.subnet_selection_type == "new" ? 1 : 0
  vpc_id                  = local.vpc_id
  cidr_block              = var.subnet_cidr
  map_public_ip_on_launch = false

  tags = {
    Name        = "${local.resource_prefix}-subnet"
    Environment = var.environment
  }
}

##########################################
# Security Group - Conditional Creation
##########################################
resource "aws_security_group" "this" {
  count  = var.sg_selection_type == "new" ? 1 : 0
  name   = "${local.resource_prefix}-sg"
  vpc_id = local.vpc_id

  ingress {
    from_port   = var.db_port
    to_port     = var.db_port
    protocol    = "tcp"
    cidr_blocks = var.allowed_cidr_blocks
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name        = "${local.resource_prefix}-sg"
    Environment = var.environment
  }
}

##########################################
# RDS Subnet Group
##########################################
resource "aws_db_subnet_group" "this" {
  name       = "${local.resource_prefix}-subnet-group"
  subnet_ids = [local.subnet_id]

  tags = {
    Name        = "${local.resource_prefix}-subnet-group"
    Environment = var.environment
  }
}

##########################################
# AWS RDS Instance
##########################################
resource "aws_db_instance" "this" {
  identifier              = "${local.resource_prefix}-rds"
  engine                  = var.db_engine
  engine_version          = var.db_engine_version
  instance_class          = var.db_instance_class
  allocated_storage       = var.allocated_storage
  username                = var.db_username
  password                = var.db_password
  db_subnet_group_name    = aws_db_subnet_group.this.name
  vpc_security_group_ids  = [local.sg_id]
  skip_final_snapshot     = var.skip_final_snapshot
  backup_retention_period = var.backup_retention
  backup_window           = var.backup_window
  port                    = var.db_port
  publicly_accessible     = false
  storage_encrypted       = true

  tags = {
    Name        = "${local.resource_prefix}-rds"
    Environment = var.environment
  }
}

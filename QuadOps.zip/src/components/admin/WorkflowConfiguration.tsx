import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Plus, Edit, Trash2, Save, X } from 'lucide-react';
import { supabase } from '../../config/supabase';
import { Tool } from '../../types';

interface WorkflowConfig {
  id?: string;
  configuration_name: string;
  automation_template_id: string;
  itsm_tool_id: string;
  version_control_tool_id: string;
  workflow_id: string;
  is_active: boolean;
}

interface AutomationTemplate {
  id: string;
  name: string;
  tower: string;
  automation_type: string;
}

interface WorkflowConfigurationProps {
  automationTemplates: AutomationTemplate[];
}

export const WorkflowConfiguration: React.FC<WorkflowConfigurationProps> = ({ automationTemplates }) => {
  const [configs, setConfigs] = useState<any[]>([]);
  const [tools, setTools] = useState<Tool[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [editingConfig, setEditingConfig] = useState<WorkflowConfig | null>(null);
  const [showForm, setShowForm] = useState(false);

  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<WorkflowConfig>();

  useEffect(() => {
    fetchConfigurations();
    fetchTools();
  }, []);

  const fetchConfigurations = async () => {
    try {
      const { data, error } = await supabase
        .from('workflow_configurations')
        .select(`
          *,
          automation_template:automation_template_id(id, name, tower, automation_type),
          itsm_tool:itsm_tool_id(id, name, provider),
          version_control_tool:version_control_tool_id(id, name, provider)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setConfigs(data || []);
    } catch (error) {
      console.error('Error fetching workflow configurations:', error);
    }
  };

  const fetchTools = async () => {
    try {
      const { data, error } = await supabase
        .from('tools')
        .select('*')
        .eq('status', 'active');

      if (error) throw error;
      setTools(data || []);
    } catch (error) {
      console.error('Error fetching tools:', error);
    }
  };

  const onSubmit = async (data: WorkflowConfig) => {
    setIsLoading(true);
    try {
      if (editingConfig) {
        const { error } = await supabase
          .from('workflow_configurations')
          .update({
            ...data,
            updated_at: new Date().toISOString(),
          })
          .eq('id', editingConfig.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('workflow_configurations')
          .insert([data]);

        if (error) throw error;
      }

      await fetchConfigurations();
      handleCancel();
    } catch (error) {
      console.error('Error saving workflow configuration:', error);
      alert('Error saving configuration. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEdit = (config: any) => {
    setEditingConfig(config);
    setValue('configuration_name', config.configuration_name);
    setValue('automation_template_id', config.automation_template_id);
    setValue('itsm_tool_id', config.itsm_tool_id);
    setValue('version_control_tool_id', config.version_control_tool_id);
    setValue('workflow_id', config.workflow_id);
    setValue('is_active', config.is_active);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this configuration?')) return;

    try {
      const { error } = await supabase
        .from('workflow_configurations')
        .delete()
        .eq('id', id);

      if (error) throw error;
      await fetchConfigurations();
    } catch (error) {
      console.error('Error deleting workflow configuration:', error);
    }
  };

  const handleCancel = () => {
    setEditingConfig(null);
    setShowForm(false);
    reset();
  };

  const itsmTools = tools.filter(tool => tool.type === 'itsm');
  const versionControlTools = tools.filter(tool => tool.type === 'version_control');

  return (
    <div className="bg-white dark:bg-gray-800 shadow-sm rounded-lg border border-gray-200 dark:border-gray-700">
      <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">Workflow Configuration</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Configure AI agents with ITSM and version control tools
            </p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Configuration
          </button>
        </div>
      </div>

      {showForm && (
        <div className="p-6 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Configuration Name
                </label>
                <input
                  {...register('configuration_name', { required: 'Configuration name is required' })}
                  type="text"
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Enter configuration name"
                />
                {errors.configuration_name && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.configuration_name.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Bot (AI Agent)
                </label>
                <select
                  {...register('automation_template_id', { required: 'Bot selection is required' })}
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                >
                  <option value="">Select Bot</option>
                  {automationTemplates.map(template => (
                    <option key={template.id} value={template.id}>
                      {template.name} ({template.tower})
                    </option>
                  ))}
                </select>
                {errors.automation_template_id && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.automation_template_id.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  ITSM Tool
                </label>
                <select
                  {...register('itsm_tool_id', { required: 'ITSM tool is required' })}
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                >
                  <option value="">Select ITSM Tool</option>
                  {itsmTools.map(tool => (
                    <option key={tool.id} value={tool.id}>
                      {tool.name} ({tool.provider})
                    </option>
                  ))}
                </select>
                {errors.itsm_tool_id && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.itsm_tool_id.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Version Control Tool
                </label>
                <select
                  {...register('version_control_tool_id', { required: 'Version control tool is required' })}
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                >
                  <option value="">Select Version Control Tool</option>
                  {versionControlTools.map(tool => (
                    <option key={tool.id} value={tool.id}>
                      {tool.name} ({tool.provider})
                    </option>
                  ))}
                </select>
                {errors.version_control_tool_id && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.version_control_tool_id.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Workflow ID
                </label>
                <input
                  {...register('workflow_id', { required: 'Workflow ID is required' })}
                  type="text"
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Enter workflow ID"
                />
                {errors.workflow_id && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.workflow_id.message}</p>
                )}
              </div>
            </div>

            <div className="flex items-center">
              <input
                {...register('is_active')}
                type="checkbox"
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                defaultChecked={true}
              />
              <label className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                Active
              </label>
            </div>

            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={handleCancel}
                className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 shadow-sm text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"
              >
                <X className="h-4 w-4 mr-2" />
                Cancel
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
              >
                {isLoading ? (
                  <div className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full"></div>
                ) : (
                  <Save className="h-4 w-4 mr-2" />
                )}
                {editingConfig ? 'Update' : 'Save'} Configuration
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Configuration
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Bot (AI Agent)
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                ITSM Tool
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Version Control
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Workflow ID
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Status
              </th>
              <th className="relative px-6 py-3">
                <span className="sr-only">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {configs.map((config) => (
              <tr key={config.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">
                    {config.configuration_name}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {config.automation_template?.name || 'Not configured'}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {config.automation_template?.tower}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {config.itsm_tool?.name || 'Not configured'}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {config.itsm_tool?.provider}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {config.version_control_tool?.name || 'Not configured'}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {config.version_control_tool?.provider}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                  {config.workflow_id}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                    config.is_active 
                      ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-400'
                      : 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-400'
                  }`}>
                    {config.is_active ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleEdit(config)}
                      className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(config.id)}
                      className="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
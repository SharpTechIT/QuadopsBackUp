import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronRight, ArrowLeft } from 'lucide-react';
import { AutomationGrid } from '../components/agents/AutomationGrid';

const towerNames: Record<string, string> = {
  'active-directory': 'Active Directory',
  'exchange': 'Exchange',
  'windows': 'Windows',
  'linux': 'Linux',
  'database': 'Database',
  'network': 'Network',
  'azure': 'Azure',
  'o365': 'O365',
  'aws': 'AWS',
  'gcp': 'Google Cloud',
};

export const TowerAutomations: React.FC = () => {
  const { towerId } = useParams<{ towerId: string }>();
  const towerName = towerNames[towerId!] || towerId;

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <nav className="flex" aria-label="Breadcrumb">
        <ol className="flex items-center space-x-4">
          <li>
            <Link to="/agents" className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
              Bots
            </Link>
          </li>
          <li>
            <ChevronRight className="h-4 w-4 text-gray-400" />
          </li>
          <li>
            <span className="text-gray-900 dark:text-white font-medium">{towerName}</span>
          </li>
        </ol>
      </nav>

      {/* Header */}
      <div className="flex items-center space-x-4">
        <Link
          to="/agents"
          className="p-2 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700"
        >
          <ArrowLeft className="h-4 w-4" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{towerName} Automations</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Select an automation to configure and execute
          </p>
        </div>
      </div>
      
      <AutomationGrid towerId={towerId!} />
    </div>
  );
};
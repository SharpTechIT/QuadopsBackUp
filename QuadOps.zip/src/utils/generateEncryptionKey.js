// Utility script to generate a secure encryption key for production
const crypto = require('crypto');

/**
 * Generates a secure 256-bit encryption key for production use
 */
function generateEncryptionKey() {
  const key = crypto.randomBytes(32).toString('hex');
  console.log('Generated Encryption Key (save this securely):');
  console.log(key);
  console.log('');
  console.log('Add this to your production.env file:');
  console.log(`ENCRYPTION_KEY=${key}`);
  console.log('');
  console.log('⚠️  IMPORTANT SECURITY NOTES:');
  console.log('1. Keep this key secret and secure');
  console.log('2. Never commit this key to version control');
  console.log('3. Use different keys for different environments');
  console.log('4. Store securely (e.g., Azure Key Vault, AWS Secrets Manager)');
  console.log('5. If you lose this key, encrypted data cannot be recovered');
  
  return key;
}

// Run the generator
if (require.main === module) {
  generateEncryptionKey();
}

module.exports = { generateEncryptionKey };
import React from 'react';
import { TowerGrid } from '../components/agents/TowerGrid';

export const AIAgents: React.FC = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">BOTs Library</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Select a technology tower to view available automations
        </p>
      </div>
      
      <TowerGrid />
    </div>
  );
};
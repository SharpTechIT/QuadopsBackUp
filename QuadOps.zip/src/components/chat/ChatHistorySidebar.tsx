import React, { useEffect, useState } from 'react';
import { ChevronsLeft, MessageSquare, PlusCircle } from 'lucide-react';
import { getChatSessions } from '../../api/supabaseService';

interface ChatHistorySidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSession: (sessionId: string) => void;
  onNewChat: () => void;
  refreshTrigger: boolean;
  activeSessionId: string | null;
}

interface Session {
  id: string;
  title: string;
}

export const ChatHistorySidebar: React.FC<ChatHistorySidebarProps> = ({ isOpen, onClose, onSelectSession, onNewChat, refreshTrigger, activeSessionId }) => {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchSessions = async () => {
      try {
        setIsLoading(true);
        const data = await getChatSessions();
        setSessions(data || []);
      } catch (error) {
        console.error("Error fetching chat sessions:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchSessions();
  }, [refreshTrigger]);

  return (
    <div
      className={`
        transition-all duration-300 ease-in-out flex flex-col flex-shrink-0
        bg-gray-50 dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700
        ${isOpen ? 'w-64' : 'w-0'}
      `}
    >
      <div className={`overflow-hidden h-full flex flex-col ${isOpen ? 'opacity-100' : 'opacity-0'} transition-opacity duration-200`}>
        <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white whitespace-nowrap">Chat History</h3>
          <button onClick={onClose} className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700">
            <ChevronsLeft className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="p-2 border-b border-gray-200 dark:border-gray-700">
          <button onClick={onNewChat} className="w-full flex items-center justify-center p-2 rounded-md bg-blue-600 text-white hover:bg-blue-700">
            <PlusCircle className="h-4 w-4 mr-2" />
            <span className="text-sm font-medium">New Chat</span>
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-2">
          {isLoading ? (
            <div className="text-center p-4 text-gray-500">Loading...</div>
          ) : (
            sessions.map((session) => (
              <div 
                key={session.id} 
                className={`flex items-center p-2 rounded-md cursor-pointer ${activeSessionId === session.id ? 'bg-blue-100 dark:bg-blue-900' : 'hover:bg-gray-200 dark:hover:bg-gray-700'}`}
                onClick={() => onSelectSession(session.id)}
              >
                <MessageSquare className="h-4 w-4 mr-2 text-gray-500" />
                <span className="text-sm text-gray-700 dark:text-gray-300 truncate">
                  {session.title}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
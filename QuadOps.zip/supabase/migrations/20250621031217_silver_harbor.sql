/*
  # Fix user_roles INSERT policy to allow initial role assignment

  1. Changes
    - Drop the overly restrictive INSERT policy that prevents initial role assignment
    - Create a new INSERT policy that allows users to insert their own role
    - This enables the initial admin user setup and new user role assignments

  2. Security
    - Users can only insert roles for themselves (user_id = auth.uid())
    - Maintains security while allowing initial role assignment
    - Other policies remain unchanged for UPDATE, DELETE, and SELECT operations
*/

-- Drop the problematic INSERT policy
DROP POLICY IF EXISTS "Only admins can insert user roles" ON user_roles;

-- Create a new INSERT policy that allows users to insert their own role
CREATE POLICY "Users can insert their own role"
  ON user_roles
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());
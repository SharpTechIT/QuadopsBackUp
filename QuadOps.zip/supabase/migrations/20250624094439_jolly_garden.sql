/*
  # Data Sources for AI Agent Dynamic Fields

  1. New Tables
    - `data_sources` - Store database connection and query information
    - `data_source_fields` - Map form fields to data sources for dynamic dropdowns

  2. Security
    - Enable RLS on new tables
    - Add policies for admin access

  3. Features
    - Support for multiple database types (PostgreSQL, MySQL, SQL Server, etc.)
    - Configurable queries for dynamic data
    - Field mapping for form generation
    - Caching support for performance
*/

-- Data sources table
CREATE TABLE IF NOT EXISTS data_sources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  type TEXT NOT NULL CHECK (type IN ('postgresql', 'mysql', 'sqlserver', 'oracle', 'sqlite', 'api', 'static')),
  connection_config JSONB NOT NULL DEFAULT '{}',
  query_config JSONB NOT NULL DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Data source field mappings table
CREATE TABLE IF NOT EXISTS data_source_fields (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  automation_template_id UUID REFERENCES automation_templates(id) ON DELETE CASCADE,
  field_name TEXT NOT NULL,
  data_source_id UUID REFERENCES data_sources(id) ON DELETE CASCADE,
  value_column TEXT NOT NULL,
  label_column TEXT,
  filter_config JSONB DEFAULT '{}',
  cache_duration INTEGER DEFAULT 300, -- 5 minutes default
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(automation_template_id, field_name)
);

-- Data source cache table for performance
CREATE TABLE IF NOT EXISTS data_source_cache (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  data_source_id UUID REFERENCES data_sources(id) ON DELETE CASCADE,
  cache_key TEXT NOT NULL,
  cached_data JSONB NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(data_source_id, cache_key)
);

-- Enable RLS
ALTER TABLE data_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE data_source_fields ENABLE ROW LEVEL SECURITY;
ALTER TABLE data_source_cache ENABLE ROW LEVEL SECURITY;

-- Data sources policies
CREATE POLICY "data_sources_all_policy"
  ON data_sources
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

-- Data source fields policies
CREATE POLICY "data_source_fields_all_policy"
  ON data_source_fields
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

-- Data source cache policies
CREATE POLICY "data_source_cache_all_policy"
  ON data_source_cache
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_data_sources_type ON data_sources(type);
CREATE INDEX IF NOT EXISTS idx_data_sources_active ON data_sources(is_active);
CREATE INDEX IF NOT EXISTS idx_data_source_fields_template ON data_source_fields(automation_template_id);
CREATE INDEX IF NOT EXISTS idx_data_source_fields_source ON data_source_fields(data_source_id);
CREATE INDEX IF NOT EXISTS idx_data_source_cache_expires ON data_source_cache(expires_at);
CREATE INDEX IF NOT EXISTS idx_data_source_cache_source ON data_source_cache(data_source_id);

-- Insert sample data sources
INSERT INTO data_sources (name, description, type, connection_config, query_config) VALUES
('Azure Resource Groups', 'List of Azure Resource Groups', 'postgresql', 
 '{"host": "localhost", "port": 5432, "database": "azure_inventory", "username": "readonly_user"}',
 '{"query": "SELECT name as value, name as label, location, subscription_id FROM resource_groups WHERE is_active = true ORDER BY name", "timeout": 30}'),
('VM Sizes', 'Available Azure VM Sizes', 'static', '{}',
 '{"data": [
   {"value": "Standard_B1s", "label": "Standard_B1s (1 vCPU, 1 GB RAM)"},
   {"value": "Standard_B2s", "label": "Standard_B2s (2 vCPU, 4 GB RAM)"},
   {"value": "Standard_D2s_v3", "label": "Standard_D2s_v3 (2 vCPU, 8 GB RAM)"},
   {"value": "Standard_D4s_v3", "label": "Standard_D4s_v3 (4 vCPU, 16 GB RAM)"}
 ]}'),
('Azure Locations', 'Azure Datacenter Locations', 'static', '{}',
 '{"data": [
   {"value": "eastus", "label": "East US"},
   {"value": "westus2", "label": "West US 2"},
   {"value": "northeurope", "label": "North Europe"},
   {"value": "westeurope", "label": "West Europe"},
   {"value": "southeastasia", "label": "Southeast Asia"}
 ]}')
ON CONFLICT DO NOTHING;
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  Mail, 
  Monitor, 
  Terminal, 
  Database, 
  Network, 
  Cloud,
  User2Icon
} from 'lucide-react';
import { supabase } from '../../config/supabase';

const towerConfig = [
  {
    id: 'active-directory',
    name: 'Active Directory',
    description: 'User and group management',
    icon: Users,
    color: 'bg-blue-500',
  },
  {
    id: 'exchange',
    name: 'Exchange',
    description: 'Email and mailbox management',
    icon: Mail,
    color: 'bg-green-500',
  },
  {
    id: 'windows',
    name: 'Windows',
    description: 'Windows VM management',
    icon: Monitor,
    color: 'bg-indigo-500',
  },
  {
    id: 'linux',
    name: 'Linux',
    description: 'Linux VM management',
    icon: Terminal,
    color: 'bg-orange-500',
  },
  {
    id: 'database',
    name: 'Database',
    description: 'Database operations',
    icon: Database,
    color: 'bg-purple-500',
  },
  {
    id: 'network',
    name: 'Network',
    description: 'Cisco network devices',
    icon: Network,
    color: 'bg-red-500',
  },
  {
    id: 'azure',
    name: 'Azure',
    description: 'Microsoft Azure services',
    icon: Cloud,
    color: 'bg-blue-600',
  },
  {
    id: 'o365',
    name: 'O365',
    description: 'Microsoft Entra ID Services',
    icon: User2Icon,
    color: 'bg-blue-600',
  },
  {
    id: 'aws',
    name: 'AWS',
    description: 'Amazon Web Services',
    icon: Cloud,
    color: 'bg-yellow-600',
  },
  {
    id: 'gcp',
    name: 'Google Cloud',
    description: 'Google Cloud Platform',
    icon: Cloud,
    color: 'bg-green-600',
  },
];

export const TowerGrid: React.FC = () => {
  const navigate = useNavigate();
  const [automationCounts, setAutomationCounts] = useState<Record<string, number>>({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchAutomationCounts();
  }, []);

  const fetchAutomationCounts = async () => {
    try {
      const { data, error } = await supabase
        .from('automation_templates')
        .select('tower')
        .eq('is_active', true);

      if (error) throw error;

      // Count automations per tower
      const counts: Record<string, number> = {};
      data?.forEach((template) => {
        counts[template.tower] = (counts[template.tower] || 0) + 1;
      });

      setAutomationCounts(counts);
    } catch (error) {
      console.error('Error fetching automation counts:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {towerConfig.map((tower) => (
        <div
          key={tower.id}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200 cursor-pointer hover:scale-105"
          onClick={() => navigate(`/agents/${tower.id}`)}
        >
          <div className="p-6">
            <div className="flex items-center">
              <div className={`p-3 rounded-lg ${tower.color} text-white`}>
                <tower.icon className="h-6 w-6" />
              </div>
              <div className="ml-4 flex-1">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">{tower.name}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">{tower.description}</p>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between">
              <span className="text-sm text-gray-500 dark:text-gray-400">
                {isLoading ? (
                  <div className="animate-pulse bg-gray-200 dark:bg-gray-600 h-4 w-20 rounded"></div>
                ) : (
                  `${automationCounts[tower.id] || 0} automations`
                )}
              </span>
              <span className="text-sm font-medium text-blue-600 dark:text-blue-400">View all →</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
import crypto from 'crypto';

// Encryption configuration
const ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH = 32; // 256 bits
const IV_LENGTH = 16; // 128 bits
const TAG_LENGTH = 16; // 128 bits
const SALT_LENGTH = 32; // 256 bits

// Get encryption key from environment or generate one
const getEncryptionKey = (): Buffer => {
  const envKey = process.env.ENCRYPTION_KEY;
  if (envKey) {
    return Buffer.from(envKey, 'hex');
  }
  
  // In development, use a fixed key (NOT for production!)
  const devKey = 'autoflow_dev_key_32_chars_long!!';
  return crypto.scryptSync(devKey, 'salt', KEY_LENGTH);
};

/**
 * Encrypts a password using AES-256-GCM
 * @param password - The plain text password to encrypt
 * @returns Encrypted password string in format: salt:iv:tag:encrypted
 */
export const encryptPassword = (password: string): string => {
  if (!password) return '';
  
  try {
    // Generate random salt and IV
    const salt = crypto.randomBytes(SALT_LENGTH);
    const iv = crypto.randomBytes(IV_LENGTH);
    
    // Derive key from master key and salt
    const masterKey = getEncryptionKey();
    const key = crypto.scryptSync(masterKey, salt, KEY_LENGTH);
    
    // Create cipher using createCipheriv for GCM mode
    const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
    
    // Encrypt the password
    let encrypted = cipher.update(password, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    // Get authentication tag
    const tag = cipher.getAuthTag();
    
    // Combine all components: salt:iv:tag:encrypted
    const result = [
      salt.toString('hex'),
      iv.toString('hex'),
      tag.toString('hex'),
      encrypted
    ].join(':');
    
    return result;
  } catch (error) {
    console.error('Error encrypting password:', error);
    throw new Error('Failed to encrypt password');
  }
};

/**
 * Decrypts a password using AES-256-GCM
 * @param encryptedPassword - The encrypted password string
 * @returns Decrypted plain text password
 */
export const decryptPassword = (encryptedPassword: string): string => {
  if (!encryptedPassword) return '';
  
  try {
    // Split the encrypted string
    const parts = encryptedPassword.split(':');
    if (parts.length !== 4) {
      throw new Error('Invalid encrypted password format');
    }
    
    const [saltHex, ivHex, tagHex, encrypted] = parts;
    
    // Convert hex strings back to buffers
    const salt = Buffer.from(saltHex, 'hex');
    const iv = Buffer.from(ivHex, 'hex');
    const tag = Buffer.from(tagHex, 'hex');
    
    // Derive the same key using salt
    const masterKey = getEncryptionKey();
    const key = crypto.scryptSync(masterKey, salt, KEY_LENGTH);
    
    // Create decipher using createDecipheriv for GCM mode
    const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
    decipher.setAuthTag(tag);
    
    // Decrypt the password
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (error) {
    console.error('Error decrypting password:', error);
    throw new Error('Failed to decrypt password');
  }
};

/**
 * Checks if a string appears to be encrypted
 * @param value - The string to check
 * @returns True if the string appears to be encrypted
 */
export const isEncrypted = (value: string): boolean => {
  if (!value) return false;
  
  // Check if it matches our encryption format: salt:iv:tag:encrypted
  const parts = value.split(':');
  return parts.length === 4 && 
         parts[0].length === SALT_LENGTH * 2 && // salt hex length
         parts[1].length === IV_LENGTH * 2 &&   // iv hex length
         parts[2].length === TAG_LENGTH * 2;    // tag hex length
};

/**
 * Generates a secure encryption key for production use
 * @returns Hex string of the generated key
 */
export const generateEncryptionKey = (): string => {
  return crypto.randomBytes(KEY_LENGTH).toString('hex');
};

/**
 * Encrypts sensitive fields in a configuration object
 * @param config - Configuration object
 * @param sensitiveFields - Array of field names to encrypt
 * @returns Configuration object with encrypted sensitive fields
 */
export const encryptSensitiveFields = (config: any, sensitiveFields: string[]): any => {
  if (!config || typeof config !== 'object') return config;
  
  const encryptedConfig = { ...config };
  
  for (const field of sensitiveFields) {
    if (encryptedConfig[field] && typeof encryptedConfig[field] === 'string') {
      // Only encrypt if not already encrypted
      if (!isEncrypted(encryptedConfig[field])) {
        encryptedConfig[field] = encryptPassword(encryptedConfig[field]);
      }
    }
  }
  
  return encryptedConfig;
};

/**
 * Decrypts sensitive fields in a configuration object
 * @param config - Configuration object with encrypted fields
 * @param sensitiveFields - Array of field names to decrypt
 * @returns Configuration object with decrypted sensitive fields
 */
export const decryptSensitiveFields = (config: any, sensitiveFields: string[]): any => {
  if (!config || typeof config !== 'object') return config;
  
  const decryptedConfig = { ...config };
  
  for (const field of sensitiveFields) {
    if (decryptedConfig[field] && typeof decryptedConfig[field] === 'string') {
      // Only decrypt if it appears to be encrypted
      if (isEncrypted(decryptedConfig[field])) {
        try {
          decryptedConfig[field] = decryptPassword(decryptedConfig[field]);
        } catch (error) {
          console.error(`Failed to decrypt field ${field}:`, error);
          // Keep the encrypted value if decryption fails
        }
      }
    }
  }
  
  return decryptedConfig;
};
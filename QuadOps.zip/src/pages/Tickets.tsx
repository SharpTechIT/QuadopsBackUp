import React, { useState, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { AlertTriangle, CheckCircle, Clock, XCircle, Filter, Download, Check, X, Eye, Lock } from 'lucide-react';
import { Ticket } from '../types';
import { supabase } from '../config/supabase';
import { useAuth } from '../hooks/useAuth';

const statusIcons = {
    open: AlertTriangle,
    in_progress: Clock,
    resolved: CheckCircle,
    closed: XCircle,
    pending_approval: Clock,
    approved: CheckCircle,
    rejected: XCircle,
};

const statusColors = {
    open: 'text-red-600 bg-red-100 dark:text-red-400 dark:bg-red-900/50',
    in_progress: 'text-blue-600 bg-blue-100 dark:text-blue-400 dark:bg-blue-900/50',
    resolved: 'text-green-600 bg-green-100 dark:text-green-400 dark:bg-green-900/50',
    closed: 'text-gray-600 bg-gray-100 dark:text-gray-400 dark:bg-gray-700',
    pending_approval: 'text-yellow-600 bg-yellow-100 dark:text-yellow-400 dark:bg-yellow-900/50',
    approved: 'text-green-600 bg-green-100 dark:text-green-400 dark:bg-green-900/50',
    rejected: 'text-red-600 bg-red-100 dark:text-red-400 dark:bg-red-900/50',
};

const priorityColors = {
    low: 'text-gray-600 dark:text-gray-400',
    medium: 'text-yellow-600 dark:text-yellow-400',
    high: 'text-orange-600 dark:text-orange-400',
    critical: 'text-red-600 dark:text-red-400',
};

export const Tickets: React.FC = () => {
    const [tickets, setTickets] = useState<Ticket[]>([]);
    const [filteredTickets, setFilteredTickets] = useState<Ticket[]>([]);
    const [selectedStatus, setSelectedStatus] = useState<string>('all');
    const [selectedPriority, setSelectedPriority] = useState<string>('all');
    const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
    const [showModal, setShowModal] = useState(false);
    const { isAdmin } = useAuth();

    useEffect(() => {
        fetchTickets();
    }, []);

    useEffect(() => {
        let filtered = tickets;

        if (selectedStatus !== 'all') {
            filtered = filtered.filter(ticket => ticket.status === selectedStatus);
        }

        if (selectedPriority !== 'all') {
            filtered = filtered.filter(ticket => ticket.priority === selectedPriority);
        }

        setFilteredTickets(filtered);
    }, [tickets, selectedStatus, selectedPriority]);

    const fetchTickets = async () => {
        try {
            const { data, error } = await supabase
                .from('tickets')
                .select('*')
                .order('created_at', { ascending: false });

            if (error) throw error;
            setTickets(data || []);
        } catch (error) {
            console.error('Error fetching tickets:', error);
        }
    };


    const updateServiceNowTicket = async (ticket: Ticket) => {
        try {
            // Extract ServiceNow sys_id from automation_data
            const automationData = ticket.automation_data as any;
            const sysId = automationData?.servicenow_request?.sys_id;

            if (!sysId) {
                console.log('No ServiceNow sys_id found in ticket automation_data');
                return;
            }
            if (ticket.status == "approved") {
                const snowData = {
                    approval: "approved",
                    requested_state: "approved"
                };
                console.log('Updating ServiceNow ticket with sys_id:', sysId);

                const response = await fetch('/api/servicenow/update-ticket', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        sys_id: sysId,
                        snow_data: snowData
                    }),
                });
                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || 'Failed to update ServiceNow ticket');
                }

                const result = await response.json();
                console.log('ServiceNow ticket updated successfully:', result);
            }
            else if (ticket.status == "rejected") {
                const snowData = {
                    approval: "requested",
                    requested_state: "approved"
                };
                console.log('Updating ServiceNow ticket with sys_id:', sysId);

                const response = await fetch('/api/servicenow/update-ticket', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        sys_id: sysId,
                        snow_data: snowData
                    }),
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || 'Failed to update ServiceNow ticket');
                }

                const result = await response.json();
                console.log('ServiceNow ticket updated successfully:', result);
            }

        } catch (error) {
            console.error('Error updating ServiceNow ticket:', error);
            // Don't fail the approval process if ServiceNow update fails
        }
    };

    const handleApproveTicket = async (ticketId: string) => {
        try {
            // Update ticket status to approved
            const { data: updatedTickets, error: updateError } = await supabase
                .from('tickets')
                .update({
                    status: 'approved',
                    updated_at: new Date().toISOString()
                })
                .eq('id', ticketId)
                .select();

            if (updateError) throw updateError;

            // Check if any rows were updated
            if (!updatedTickets || updatedTickets.length === 0) {
                throw new Error('Ticket not found or already processed');
            }

            const ticket = updatedTickets[0];

            // Update ServiceNow ticket if it exists
            await updateServiceNowTicket(ticket);

            // If approved and has automation data, create workflow run
            if (ticket && ticket.automation_data) {
                const automationData = ticket.automation_data as any;

                const { error: workflowError } = await supabase
                    .from('workflow_runs')
                    .insert([{
                        workflow_id: `${automationData.tower}-${automationData.automation_type}-${Date.now()}`,
                        workflow_name: automationData.automation_name,
                        tower: automationData.tower,
                        automation_type: automationData.automation_type,
                        status: 'pending',
                        form_data: automationData.form_data,
                        user_id: ticket.user_id,
                        ticket_id: ticket.id,
                        ticket_number: ticket.ticket_number
                    }]);

                if (workflowError) {
                    console.error('Error creating workflow run:', workflowError);
                    // Don't fail the approval, just log the error
                }
                else {
                    // Fetch the automation template ID
                    const { data: automationTemplates, error: templateError } = await supabase
                        .from('automation_templates')
                        .select('id') // Only select the 'id' field as it's all you need
                        .eq('name', automationData.automation_name);

                    if (templateError) {
                        console.error('Error fetching automation template:', templateError);
                        // Handle error (e.g., throw, return, or log and proceed with null ID)
                        return; // Exit if template fetching fails critically
                    }

                    const workflowTemplateId = automationTemplates && automationTemplates.length > 0
                        ? automationTemplates[0].id
                        : null; // Assign null if no template found

                    if (!workflowTemplateId) {
                        console.warn('Automation template not found for name:', automationData.automation_name, '. Skipping FastAPI call.');
                        // If the workflow ID is crucial for the FastAPI call, you might want to return or throw here.
                        return;
                    }

                    const payloadForFastAPI = {
                        workflowID: workflowTemplateId, // This will now correctly be the template ID
                        automationData: automationData.form_data,
                        servicenowData: automationData?.servicenow_request
                    };
                    console.log('Calling FastAPI to trigger github action...');
                    const response = await fetch('/api/trigger-git-action', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(payloadForFastAPI),
                    });
                    console.log('GIT request via FastAPI successful:', response);
                }
            }

            await fetchTickets();
            alert('Ticket approved successfully!');
        } catch (error) {
            console.error('Error approving ticket:', error);
            alert(`Error approving ticket: ${error instanceof Error ? error.message : 'Unknown error occurred'}`);
        }
    };

    const handleRejectTicket = async (ticketId: string) => {
        try {
            // Update ticket status to rejected
            const { data: updatedTickets, error } = await supabase
                .from('tickets')
                .update({
                    status: 'rejected',
                    updated_at: new Date().toISOString()
                })
                .eq('id', ticketId)
                .select();

            if (error) throw error;

            // Check if any rows were updated
            if (!updatedTickets || updatedTickets.length === 0) {
                throw new Error('Ticket not found or already processed');
            }

            const ticket = updatedTickets[0];

            // Update ServiceNow ticket if it exists
            await updateServiceNowTicket(ticket);

            await fetchTickets();
            alert('Ticket rejected successfully!');
        } catch (error) {
            console.error('Error rejecting ticket:', error);
            alert(`Error rejecting ticket: ${error instanceof Error ? error.message : 'Unknown error occurred'}`);
        }
    };

    const handleCloseTicket = async (ticketId: string) => {
        if (!window.confirm('Are you sure you want to close this ticket? This action cannot be undone.')) {
            return;
        }

        try {
            // Update ticket status to closed
            const { data: updatedTickets, error } = await supabase
                .from('tickets')
                .update({
                    status: 'closed',
                    updated_at: new Date().toISOString()
                })
                .eq('id', ticketId)
                .select();

            if (error) throw error;

            // Check if any rows were updated
            if (!updatedTickets || updatedTickets.length === 0) {
                throw new Error('Ticket not found');
            }

            await fetchTickets();
            alert('Ticket closed successfully!');
        } catch (error) {
            console.error('Error closing ticket:', error);
            alert(`Error closing ticket: ${error instanceof Error ? error.message : 'Unknown error occurred'}`);
        }
    };

    const handleViewDetails = (ticket: Ticket) => {
        setSelectedTicket(ticket);
        setShowModal(true);
    };

    const canCloseTicket = (ticket: Ticket) => {
        return ticket.status !== 'closed' && (isAdmin || ticket.status === 'resolved');
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Tickets</h1>
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                        View and manage all ITSM tickets
                    </p>
                </div>
                <button className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 shadow-sm text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700">
                    <Download className="h-4 w-4 mr-2" />
                    Export
                </button>
            </div>

            {/* Filters */}
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-4">
                    <Filter className="h-5 w-5 text-gray-400" />
                    <div className="flex space-x-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Status</label>
                            <select
                                value={selectedStatus}
                                onChange={(e) => setSelectedStatus(e.target.value)}
                                className="block w-full rounded-md border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                            >
                                <option value="all">All Statuses</option>
                                <option value="pending_approval">Pending Approval</option>
                                <option value="approved">Approved</option>
                                <option value="rejected">Rejected</option>
                                <option value="open">Open</option>
                                <option value="in_progress">In Progress</option>
                                <option value="resolved">Resolved</option>
                                <option value="closed">Closed</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Priority</label>
                            <select
                                value={selectedPriority}
                                onChange={(e) => setSelectedPriority(e.target.value)}
                                className="block w-full rounded-md border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                            >
                                <option value="all">All Priorities</option>
                                <option value="low">Low</option>
                                <option value="medium">Medium</option>
                                <option value="high">High</option>
                                <option value="critical">Critical</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            {/* Tickets Table */}
            <div className="bg-white dark:bg-gray-800 shadow-sm rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead className="bg-gray-50 dark:bg-gray-700">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Ticket
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    ITSM Reference
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Status
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Priority
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Created
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Updated
                                </th>
                                <th className="relative px-6 py-3">
                                    <span className="sr-only">Actions</span>
                                </th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            {filteredTickets.map((ticket) => {
                                const StatusIcon = statusIcons[ticket.status as keyof typeof statusIcons];
                                return (
                                    <tr key={ticket.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div>
                                                <div className="text-sm font-medium text-gray-900 dark:text-white">
                                                    {ticket.ticket_number}
                                                </div>
                                                <div className="text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs">
                                                    {ticket.title}
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div>
                                                {ticket.itsm_reference ? (
                                                    <>
                                                        <div className="text-sm font-medium text-gray-900 dark:text-white">
                                                            {ticket.itsm_reference}
                                                        </div>
                                                        <div className="text-xs text-gray-500 dark:text-gray-400 capitalize">
                                                            {ticket.itsm_type}
                                                        </div>
                                                    </>
                                                ) : (
                                                    <span className="text-sm text-gray-400 dark:text-gray-500">-</span>
                                                )}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColors[ticket.status as keyof typeof statusColors]}`}>
                                                <StatusIcon className="h-3 w-3 mr-1" />
                                                {ticket.status.replace('_', ' ')}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className={`text-sm font-medium ${priorityColors[ticket.priority]}`}>
                                                {ticket.priority.toUpperCase()}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                            {formatDistanceToNow(new Date(ticket.created_at), { addSuffix: true })}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                            {formatDistanceToNow(new Date(ticket.updated_at), { addSuffix: true })}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <div className="flex space-x-2">
                                                <button
                                                    onClick={() => handleViewDetails(ticket)}
                                                    className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300"
                                                    title="View Details"
                                                >
                                                    <Eye className="h-4 w-4" />
                                                </button>
                                                {isAdmin && ticket.status === 'pending_approval' && (
                                                    <>
                                                        <button
                                                            onClick={() => handleApproveTicket(ticket.id)}
                                                            className="text-green-600 dark:text-green-400 hover:text-green-900 dark:hover:text-green-300"
                                                            title="Approve"
                                                        >
                                                            <Check className="h-4 w-4" />
                                                        </button>
                                                        <button
                                                            onClick={() => handleRejectTicket(ticket.id)}
                                                            className="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300"
                                                            title="Reject"
                                                        >
                                                            <X className="h-4 w-4" />
                                                        </button>
                                                    </>
                                                )}
                                                {canCloseTicket(ticket) && (
                                                    <button
                                                        onClick={() => handleCloseTicket(ticket.id)}
                                                        className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-300"
                                                        title="Close Ticket"
                                                    >
                                                        <Lock className="h-4 w-4" />
                                                    </button>
                                                )}
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Details Modal */}
            {showModal && selectedTicket && (
                <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
                    <div className="relative top-20 mx-auto p-5 border w-2/3 max-w-2xl shadow-lg rounded-md bg-white dark:bg-gray-800">
                        <div className="mt-3">
                            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                                Ticket Details
                            </h3>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Ticket Number</label>
                                    <p className="text-sm text-gray-900 dark:text-white">{selectedTicket.ticket_number}</p>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">ITSM Reference</label>
                                    <p className="text-sm text-gray-900 dark:text-white">
                                        {selectedTicket.itsm_reference ? (
                                            <>
                                                {selectedTicket.itsm_reference}
                                                <span className="text-xs text-gray-500 dark:text-gray-400 ml-2 capitalize">
                                                    ({selectedTicket.itsm_type})
                                                </span>
                                            </>
                                        ) : (
                                            'No external reference'
                                        )}
                                    </p>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
                                    <p className={`text-sm font-medium`}>
                                        {selectedTicket.status.replace('_', ' ').toUpperCase()}
                                    </p>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Priority</label>
                                    <p className={`text-sm font-medium ${priorityColors[selectedTicket.priority]}`}>
                                        {selectedTicket.priority.toUpperCase()}
                                    </p>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Created</label>
                                    <p className="text-sm text-gray-900 dark:text-white">
                                        {formatDistanceToNow(new Date(selectedTicket.created_at), { addSuffix: true })}
                                    </p>
                                </div>
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Title</label>
                                    <p className="text-sm text-gray-900 dark:text-white">{selectedTicket.title}</p>
                                </div>
                            </div>
                            <div className="mt-4">
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Work Notes</label>
                                <p className="text-sm text-gray-900 dark:text-white">{selectedTicket.work_notes}</p>
                            </div>


                            {(selectedTicket as any).automation_data && (
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Automation Data</label>
                                    <pre className="text-xs bg-gray-100 dark:bg-gray-700 p-3 rounded mt-1 text-gray-900 dark:text-white overflow-auto max-h-40">
                                        {JSON.stringify((selectedTicket as any).automation_data, null, 2)}
                                    </pre>
                                </div>
                            )}

                            <div className="mt-6 flex justify-end space-x-2">
                                {isAdmin && selectedTicket.status === 'pending_approval' && (
                                    <>
                                        <button
                                            onClick={() => {
                                                handleApproveTicket(selectedTicket.id);
                                                setShowModal(false);
                                            }}
                                            className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                                        >
                                            Approve
                                        </button>
                                        <button
                                            onClick={() => {
                                                handleRejectTicket(selectedTicket.id);
                                                setShowModal(false);
                                            }}
                                            className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                                        >
                                            Reject
                                        </button>
                                    </>
                                )}
                                {canCloseTicket(selectedTicket) && (
                                    <button
                                        onClick={() => {
                                            handleCloseTicket(selectedTicket.id);
                                            setShowModal(false);
                                        }}
                                        className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
                                    >
                                        Close Ticket
                                    </button>
                                )}
                                <button
                                    onClick={() => setShowModal(false)}
                                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                                >
                                    Close
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
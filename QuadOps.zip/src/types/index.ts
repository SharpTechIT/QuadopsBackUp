export interface Tool {
  id: string;
  type: 'itsm' | 'version_control' | 'notification' | 'cloud_provider';
  name: string;
  provider: string;
  config: Record<string, any>;
  status: 'active' | 'inactive' | 'error';
  created_at: string;
  updated_at: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'agent';
  timestamp: string;
}

export interface WorkflowRun {
  id: string;
  workflow_id: string;
  workflow_name: string;
  tower: string;
  automation_type: string;
  status: 'pending' | 'running' | 'success' | 'failed';
  form_data: Record<string, any>;
  created_at: string;
  updated_at: string;
  execution_time?: number;
  error_message?: string;
  ticket_id?: string;
  ticket_number?: string;
}

export interface Ticket {
  id: string;
  ticket_number: string;
  title: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed' | 'pending_approval' | 'approved' | 'rejected';
  priority: 'low' | 'medium' | 'high' | 'critical';
  workflow_run_id?: string;
  user_id?: string;
  automation_data?: Record<string, any>;
  itsm_reference?: string;
  itsm_type?: 'servicenow' | 'jira' | 'other';
  created_at: string;
  updated_at: string;
  work_notes: string;
}

export interface AutomationTemplate {
  id: string;
  tower: string;
  subcategory_id?: string;
  name: string;
  description: string;
  form_schema: Record<string, any>;
  api_endpoint: string;
}

export interface TowerSubcategory {
  id: string;
  tower: string;
  name: string;
  description?: string;
  icon_name: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface DashboardMetrics {
  total_workflows: number;
  successful_workflows: number;
  failed_workflows: number;
  pending_workflows: number;
  total_tickets: number;
  open_tickets: number;
  resolved_tickets: number;
}

export interface User {
  id: string;
  email: string;
  full_name: string;
  avatar_url?: string;
  theme: 'light' | 'dark';
  created_at: string;
  updated_at: string;
}

export interface DataSource {
  id: string;
  name: string;
  description: string;
  type: 'postgresql' | 'mysql' | 'sqlserver' | 'oracle' | 'sqlite' | 'api' | 'static' | 'azure_api' | 'aws_api' | 'gcp_api';
  connection_config: Record<string, any>;
  query_config: Record<string, any>;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface DataSourceField {
  id: string;
  automation_template_id: string;
  field_name: string;
  data_source_id: string;
  value_column: string;
  label_column: string;
  filter_config: Record<string, any>;
  cache_duration: number;
  created_at: string;
  updated_at: string;
}

export interface CloudProvider {
  id: string;
  name: string;
  provider: 'azure' | 'aws' | 'gcp';
  config: {
    tenant_id?: string;
    client_id?: string;
    client_secret?: string;
    subscription_id?: string;
    access_key_id?: string;
    secret_access_key?: string;
    region?: string;
    project_id?: string;
    service_account_key?: string;
  };
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// src/types/index.ts

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'agent';
  timestamp: string;
  metadata?: string | Record<string, any>; // Add metadata field for file information
}

export interface ChatSession {
  id: string;
  title: string;
  created_at: string;
  updated_at?: string;
}

export interface FileInfo {
  filename: string;
  path: string;
  relative_path: string;
}

export interface TerraformFiles {
  main_tf?: FileInfo;
  variables_tf?: FileInfo;
  outputs_tf?: FileInfo;
}
############################################
# AWS Provider Configuration
############################################
provider "aws" {
  region  = var.aws_region
  profile = var.aws_profile
}

############################################
# Create New VPC (if selected)
############################################
resource "aws_vpc" "this" {
  count             = var.vpc_selection_type == "new" ? 1 : 0
  cidr_block        = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true

  tags = {
    Name        = "${var.project_name}-${var.environment}-vpc"
    Environment = var.environment
  }
}

############################################
# Data Source for Existing VPC
############################################
data "aws_vpc" "existing" {
  count = var.vpc_selection_type == "existing" ? 1 : 0
  id    = var.existing_vpc_id
}

############################################
# Locals to Coalesce New/Existing VPC
############################################
locals {
  vpc_id = coalesce(
    try(aws_vpc.this[0].id, null),
    try(data.aws_vpc.existing[0].id, null)
  )
}

############################################
# Public Subnet Creation (Optional)
############################################
resource "aws_subnet" "public" {
  count                   = var.subnet_selection_type == "new" ? length(var.public_subnet_cidrs) : 0
  vpc_id                  = local.vpc_id
  cidr_block              = var.public_subnet_cidrs[count.index]
  map_public_ip_on_launch = true
  availability_zone       = var.availability_zones[count.index]

  tags = {
    Name        = "${var.project_name}-${var.environment}-public-${count.index + 1}"
    Environment = var.environment
  }
}

############################################
# Data Source for Existing Public Subnets
############################################
data "aws_subnet" "existing_public" {
  count = var.subnet_selection_type == "existing" ? length(var.existing_public_subnet_ids) : 0
  id    = var.existing_public_subnet_ids[count.index]
}

############################################
# Local for Public Subnet IDs
############################################
locals {
  public_subnet_ids = coalescelist(
    try(aws_subnet.public[*].id, []),
    try(data.aws_subnet.existing_public[*].id, [])
  )
}

############################################
# Internet Gateway (New or Existing)
############################################
resource "aws_internet_gateway" "this" {
  count  = var.igw_selection_type == "new" ? 1 : 0
  vpc_id = local.vpc_id

  tags = {
    Name        = "${var.project_name}-${var.environment}-igw"
    Environment = var.environment
  }
}

data "aws_internet_gateway" "existing" {
  count = var.igw_selection_type == "existing" ? 1 : 0
  id    = var.existing_igw_id
}

locals {
  igw_id = coalesce(
    try(aws_internet_gateway.this[0].id, null),
    try(data.aws_internet_gateway.existing[0].id, null)
  )
}

############################################
# Public Route Table
############################################
resource "aws_route_table" "public" {
  count  = var.vpc_selection_type == "new" ? 1 : 0
  vpc_id = local.vpc_id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = local.igw_id
  }

  tags = {
    Name        = "${var.project_name}-${var.environment}-public-rt"
    Environment = var.environment
  }
}

resource "aws_route_table_association" "public" {
  count          = length(local.public_subnet_ids)
  subnet_id      = local.public_subnet_ids[count.index]
  route_table_id = try(aws_route_table.public[0].id, null)
}

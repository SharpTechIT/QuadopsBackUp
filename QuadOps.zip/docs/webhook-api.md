# Webhook API Documentation

This document describes the authenticated webhook endpoints that external ITSM systems (ServiceNow, Jira) can call to approve or reject tickets in the AutoFlow system.

## Base URL
```
http://localhost:3001/api/webhook
```

## Authentication

**All webhook endpoints require authentication.** See [Webhook Authentication Guide](./webhook-authentication.md) for detailed authentication instructions.

### Quick Authentication Examples:

**API Key (Recommended):**
```bash
-H "X-API-Key: ak_your_api_key_here"
```

**Bearer Token:**
```bash
-H "Authorization: Bearer admin@autoflow.com"
```

## Endpoints

### 1. ServiceNow Approval Webhook
**Endpoint:** `POST /api/webhook/servicenow/approval`

**Description:** Called by ServiceNow when a request is approved or rejected.

**Authentication:** Required (API Key or Bearer Token)

**Request Body:**
```json
{
  "itsm_reference": "REQ0010001",
  "status": "approved",
  "comments": "Request approved by manager",
  "approved_by": "admin@company.com"
}
```

**Required Fields:**
- `itsm_reference` (string): The ServiceNow request number
- `status` (string): Either "approved" or "rejected"

**Optional Fields:**
- `comments` (string): Approval/rejection comments
- `approved_by` (string): Email of the person who approved/rejected

**Example Request:**
```bash
curl -X POST http://localhost:3001/api/webhook/servicenow/approval \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ak_your_api_key_here" \
  -d '{
    "itsm_reference": "REQ0010001",
    "status": "approved",
    "comments": "Request approved by manager",
    "approved_by": "admin@company.com"
  }'
```

**Response:**
```json
{
  "success": true,
  "message": "Ticket approved successfully",
  "data": {
    "ticket_number": "REQ-2024-123456",
    "itsm_reference": "REQ0010001",
    "status": "approved",
    "updated_at": "2024-01-15T10:30:00Z",
    "approved_by": "admin@autoflow.com"
  }
}
```

### 2. Jira Approval Webhook
**Endpoint:** `POST /api/webhook/jira/approval`

**Description:** Called by Jira when a ticket is approved or rejected.

**Authentication:** Required (API Key or Bearer Token)

**Request Body:**
```json
{
  "itsm_reference": "PROJ-123",
  "status": "rejected",
  "comments": "Insufficient information provided",
  "approved_by": "manager@company.com"
}
```

**Fields:** Same as ServiceNow webhook

**Example Request:**
```bash
curl -X POST http://localhost:3001/api/webhook/jira/approval \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ak_your_api_key_here" \
  -d '{
    "itsm_reference": "PROJ-123",
    "status": "rejected",
    "comments": "Insufficient information provided"
  }'
```

### 3. Generic ITSM Webhook
**Endpoint:** `POST /api/webhook/itsm/approval`

**Description:** Generic endpoint that can handle both ServiceNow and Jira webhooks.

**Authentication:** Required (API Key or Bearer Token)

**Request Body:**
```json
{
  "itsm_type": "servicenow",
  "itsm_reference": "REQ0010001",
  "status": "approved",
  "comments": "Request approved",
  "approved_by": "admin@company.com"
}
```

**Additional Required Field:**
- `itsm_type` (string): Either "servicenow" or "jira"

**Example Request:**
```bash
curl -X POST http://localhost:3001/api/webhook/itsm/approval \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ak_your_api_key_here" \
  -d '{
    "itsm_type": "servicenow",
    "itsm_reference": "REQ0010001",
    "status": "approved"
  }'
```

## Error Responses

### 401 Unauthorized
```json
{
  "success": false,
  "error": "Authentication required. Provide Authorization header or X-API-Key header."
}
```

### 403 Forbidden
```json
{
  "success": false,
  "error": "Insufficient permissions. Only admin users can approve/reject tickets via webhook."
}
```

### 400 Bad Request
```json
{
  "success": false,
  "error": "Missing required fields: itsm_reference and status are required"
}
```

### 404 Not Found
```json
{
  "success": false,
  "error": "No ticket found with ServiceNow reference: REQ0010001"
}
```

### 409 Conflict
```json
{
  "success": false,
  "error": "Ticket REQ0010001 is already approved"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "error": "Internal server error"
}
```

## ServiceNow Integration

### Business Rule Configuration
Create a Business Rule in ServiceNow that triggers when a request is approved/rejected:

```javascript
(function executeRule(current, previous) {
    // Only trigger on status changes to approved/rejected
    if (current.approval.changesTo('approved') || current.approval.changesTo('rejected')) {
        
        var status = current.approval == 'approved' ? 'approved' : 'rejected';
        var comments = current.comments || '';
        var approvedBy = current.sys_updated_by || '';
        
        // Prepare webhook payload
        var payload = {
            itsm_reference: current.number.toString(),
            status: status,
            comments: comments,
            approved_by: approvedBy
        };
        
        // Call AutoFlow webhook with authentication
        var request = new sn_ws.RESTMessageV2();
        request.setEndpoint('https://your-autoflow-domain.com:3001/api/webhook/servicenow/approval');
        request.setHttpMethod('POST');
        request.setRequestHeader('Content-Type', 'application/json');
        request.setRequestHeader('X-API-Key', 'ak_your_servicenow_api_key_here');
        request.setRequestBody(JSON.stringify(payload));
        
        var response = request.execute();
        
        // Log the response
        gs.log('AutoFlow webhook response: ' + response.getBody(), 'AutoFlow Integration');
    }
})(current, previous);
```

### Webhook URL for ServiceNow
Configure ServiceNow to call:
```
https://your-autoflow-domain.com:3001/api/webhook/servicenow/approval
```

**Important:** Include the `X-API-Key` header with a valid API key.

## Jira Integration

### Automation Rule Configuration
Create an Automation Rule in Jira that triggers on status transitions:

1. **Trigger:** Issue transitioned
2. **Condition:** Status changed to "Approved" or "Rejected"
3. **Action:** Send web request

**Web Request Configuration:**
- URL: `https://your-autoflow-domain.com:3001/api/webhook/jira/approval`
- HTTP Method: POST
- Headers: 
  - `Content-Type: application/json`
  - `X-API-Key: ak_your_jira_api_key_here`
- Body:
```json
{
  "itsm_reference": "{{issue.key}}",
  "status": "{{#issue.status}}{{#equals name 'Approved'}}approved{{/equals}}{{#equals name 'Rejected'}}rejected{{/equals}}{{/issue.status}}",
  "comments": "{{issue.fields.comment.comments.last.body}}",
  "approved_by": "{{issue.fields.assignee.emailAddress}}"
}
```

## Testing

### Health Check
```bash
curl http://localhost:3001/api/webhook/health
```

### Test ServiceNow Webhook (Authenticated)
```bash
curl -X POST http://localhost:3001/api/webhook/servicenow/approval \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ak_test_admin_key_12345678901234567890123456789012" \
  -d '{
    "itsm_reference": "REQ0010001",
    "status": "approved",
    "comments": "Test approval",
    "approved_by": "test@company.com"
  }'
```

### Test Jira Webhook (Authenticated)
```bash
curl -X POST http://localhost:3001/api/webhook/jira/approval \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ak_test_admin_key_12345678901234567890123456789012" \
  -d '{
    "itsm_reference": "PROJ-123",
    "status": "rejected",
    "comments": "Test rejection",
    "approved_by": "test@company.com"
  }'
```

### Test Without Authentication (Should Fail)
```bash
curl -X POST http://localhost:3001/api/webhook/servicenow/approval \
  -H "Content-Type: application/json" \
  -d '{
    "itsm_reference": "REQ0010001",
    "status": "approved"
  }'
```

Expected response: 401 Unauthorized

## Security Features

- **Authentication Required:** All webhook endpoints require valid authentication
- **Admin-Only Access:** Only users with admin role can approve/reject tickets
- **Audit Logging:** All webhook requests are logged for compliance
- **API Key Management:** Secure API key creation and management
- **Request Validation:** Thorough validation of all incoming data
- **User Tracking:** All approvals are tracked with authenticated user information

## Workflow

1. User submits automation request in AutoFlow
2. AutoFlow creates internal ticket and ServiceNow/Jira request
3. ITSM reference is stored in the ticket
4. Approver reviews and approves/rejects in ServiceNow/Jira
5. ServiceNow/Jira calls AutoFlow webhook with authentication
6. AutoFlow validates authentication and permissions
7. AutoFlow updates ticket status and logs the action
8. AutoFlow creates workflow run (if approved)
9. Automation workflow executes (if approved)

For detailed authentication setup, see the [Webhook Authentication Guide](./webhook-authentication.md).
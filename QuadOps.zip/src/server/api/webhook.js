/**
 * Webhook API for external ITSM systems (ServiceNow, Jira) to update ticket status
 */

/**
 * Handles ServiceNow webhook for ticket approval/rejection
 * Expected payload:
 * {
 *   "itsm_reference": "REQ0010001",
 *   "status": "approved" | "rejected",
 *   "comments": "Optional approval comments",
 *   "approved_by": "admin@company.com"
 * }
 */
// Adjust path if necessary
import { fastApiClient } from '../api/fastapiClient.js'

export async function handleServiceNowWebhook(req, res) {
  try {
    const { itsm_reference, status, comments, approved_by } = req.body;

    // Validate required fields
    if (!itsm_reference || !status) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: itsm_reference and status are required'
      });
    }

    // Validate status
    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid status. Must be "approved" or "rejected"'
      });
    }

    console.log(`ServiceNow webhook received :: ${itsm_reference} -> ${status}`);

    // Import Supabase client (dynamic import to avoid module issues)
    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://riwtnauneyebqhhpfjya.supabase.co';
    const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJpd3RuYXVuZXllYnFoaHBmanlhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA0NDA1NzEsImV4cCI6MjA2NjAxNjU3MX0.xgyciQdfduR6SPBkUt1c6OapY_a8jHDIHzETRZW9U6E';
    
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Find the ticket by ITSM reference
    const { data: tickets, error: findError } = await supabase
      .from('tickets')
      .select('*')
      .eq('itsm_reference', itsm_reference)
      .eq('itsm_type', 'servicenow');

    if (findError) {
      console.error('Error finding ticket:', findError);
      return res.status(500).json({
        success: false,
        error: 'Database error while finding ticket'
      });
    }

    if (!tickets || tickets.length === 0) {
      return res.status(404).json({
        success: false,
        error: `No ticket found with ServiceNow reference: ${itsm_reference}`
      });
    }

    const ticket = tickets[0];

    // Check if ticket is already processed
    if (ticket.status === 'approved' || ticket.status === 'rejected') {
      return res.status(409).json({
        success: false,
        error: `Ticket ${itsm_reference} is already ${ticket.status}`
      });
    }

    // Update ticket status
    const updateData = {
      status: status,
      updated_at: new Date().toISOString()
    };

    // Add approval metadata if provided
    if (comments || approved_by) {
      const existingAutomationData = ticket.automation_data || {};
      updateData.automation_data = {
        ...existingAutomationData,
        approval_metadata: {
          approved_by: approved_by,
          approval_comments: comments,
          approval_timestamp: new Date().toISOString(),
          approval_source: 'servicenow_webhook'
        }
      };
    }

    const { data: updatedTickets, error: updateError } = await supabase
      .from('tickets')
      .update(updateData)
      .eq('id', ticket.id)
      .select();

    if (updateError) {
      console.error('Error updating ticket:', updateError);
      return res.status(500).json({
        success: false,
        error: 'Database error while updating ticket'
      });
    }

    const updatedTicket = updatedTickets[0];

    // If approved, create workflow run
    if (status === 'approved' && ticket.automation_data) {
      const automationData = ticket.automation_data;
      console.log("Coming to approved ticket")
      const { data: workflowRun, error: workflowError } = await supabase
        .from('workflow_runs')
        .insert([{
          workflow_id: `${automationData.tower}-${automationData.automation_type}-${Date.now()}`,
          workflow_name: automationData.automation_name,
          tower: automationData.tower,
          automation_type: automationData.automation_type,
          status: 'pending',
          form_data: automationData.form_data,
          user_id: ticket.user_id,
          ticket_id: ticket.id,
          ticket_number: ticket.ticket_number
        }]);
        console.log(`Workflow run created : ${workflowRun}`)
        

      
      if (workflowError) {
        console.error('Error creating workflow run:', workflowError);
        // Don't fail the approval, just log the error
      } else {
        console.log(`Workflow run created for approved ticket: ${ticket.ticket_number}`);
          const { data: automationTemplates, error: templateError } = await supabase
              .from('automation_templates')
              .select('id') // Only select the 'id' field as it's all you need
              .eq('name', automationData.automation_name);

          if (templateError) {
              console.error('Error fetching automation template:', templateError);
              // Handle error (e.g., throw, return, or log and proceed with null ID)
              return; // Exit if template fetching fails critically
          }

          const workflowTemplateId = automationTemplates && automationTemplates.length > 0
              ? automationTemplates[0].id
              : null; // Assign null if no template found

          if (!workflowTemplateId) {
              console.warn('Automation template not found for name:', automationData.automation_name, '. Skipping FastAPI call.');
              // If the workflow ID is crucial for the FastAPI call, you might want to return or throw here.
              return;
          }
         
          const payloadForFastAPI = {
              workflowID: workflowTemplateId, 
              automationData: automationData.form_data,
              servicenowData: automationData?.servicenow_request
        };
        console.log(`Calling FastAPI to create ServiceNow request..Payload : ${payloadForFastAPI}.`);

          const fastApiResponse = await fastApiClient.triggerGitAction(
          'http://localhost:8000/trigger-git-action',
          payloadForFastAPI
        );
        // workflowRunId = workflowRun.id;

        // // Update ticket with workflow_run_id
        // await supabase
        //   .from('tickets')
        //   .update({ workflow_run_id: workflowRunId })
        //   .eq('id', ticket.id);
      }
    }

    console.log(`Ticket ${ticket.ticket_number} (${itsm_reference}) ${status} successfully`);

    return res.status(200).json({
      success: true,
      message: `Ticket ${status} successfully`,
      data: {
        ticket_number: updatedTicket.ticket_number,
        itsm_reference: itsm_reference,
        status: status,
        updated_at: updatedTicket.updated_at,
      }
    });

  } catch (error) {
    console.error('Error in ServiceNow webhook handler:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
}


export async function handleUpdateServiceNowWebhook(req, res) {
  try {
    const { itsm_reference, status, itsm_reference_sys_id, comments } = req.body;

    // Validate required fields
    if (!itsm_reference || !status) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: itsm_reference and status are required'
      });
    }

    // Validate status
    if (!['closed_complete', 'closed_incomplete'].includes(status)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid status. Must be "closed_complete" or "closed_incomplete"'
      });
    }

    console.log(`ServiceNow webhook received :: ${itsm_reference} -> ${status}`);

    // Import Supabase client (dynamic import to avoid module issues)
    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://riwtnauneyebqhhpfjya.supabase.co';
    const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJpd3RuYXVuZXllYnFoaHBmanlhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA0NDA1NzEsImV4cCI6MjA2NjAxNjU3MX0.xgyciQdfduR6SPBkUt1c6OapY_a8jHDIHzETRZW9U6E';
    
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Find the ticket by ITSM reference
    const { data: tickets, error: findError } = await supabase
      .from('tickets')
      .select('*')
      .eq('itsm_reference', itsm_reference)
      .eq('itsm_type', 'servicenow');

      
      
    if (findError) {
      console.error('Error finding ticket:', findError);
      return res.status(500).json({
        success: false,
        error: 'Database error while finding ticket'
      });
    }

    if (!tickets || tickets.length === 0) {
      return res.status(404).json({
        success: false,
        error: `No ticket found with ServiceNow reference: ${itsm_reference}`
      });
    }

    const ticket = tickets[0];
    
    // Check if ticket is already processed
    if (ticket.status === 'closed_incomplete' || ticket.status === 'closed_complete') {
      return res.status(409).json({
        success: false,
        error: `Ticket ${itsm_reference} is already ${ticket.status}`
      });
    }

    

    // If approved, update workflow run
    if (status === 'closed_complete' && ticket.automation_data) {
       const automationFormData = ticket.automationData
      const updateData = {
        status: "resolved",
        work_notes:comments,
        updated_at: new Date().toISOString()
      };


      const { data: updatedTickets, error: updateError } = await supabase
        .from('tickets')
        .update(updateData)
        .eq('id', ticket.id)
        .select();
      console.log(updatedTickets);
      if (updateError) {
        console.error('Error updating ticket:', updateError);
        return res.status(500).json({
          success: false,
          error: 'Database error while updating ticket'
        });
      }
      
      const { data: updatedWorkflow, error: updateErrors } = await supabase
      .from('workflow_runs')
      .update({
        status: "success"
      })
      .eq('ticket_id', ticket.id)
      .select();
      
      const payloadForFastAPI = {
        sys_id: itsm_reference_sys_id,
        snow_data: {"request_state":"closed_complete", "state":3, "close_notes":comments}
      };
      console.log('Calling FastAPI to create ServiceNow request...');
      console.log(updatedWorkflow);
      console.log(updateErrors);
      const fastApiResponse = await fastApiClient.updateServiceNowRequest(
        'http://localhost:8000/update-servicenow-request',
        payloadForFastAPI
      );
        const { data: tickets, error: findError } = await supabase
            .from('tickets')
            .select('*')
            .eq('itsm_reference', itsm_reference)
            .eq('itsm_type', 'servicenow');
        console.log("################### ");
        console.log(tickets);
        const ticket_s = tickets[0];
        console.log("################### ");
        let mailBodyData;
        mailBodyData = ticket_s.automation_data
        console.log(mailBodyData);
        const { data: useremails, error: emailError } = await supabase
            .from('users')
            .select('*')
            .eq('id', ticket_s.user_id);
        let receptEmail="";
        console.log("########################");
        console.log(useremails)
        if(emailError){
          receptEmail = "sharptech@878tdk.onmicrosoft.com"
        }
        else{
          const userEmail = useremails[0];
          console.log(userEmail);
          receptEmail = userEmail.email;
        }
        const mail_payload = {
            mail_id: receptEmail,
            mail_body: mailBodyData
        }
        console.log('Sending mail with payload', mail_payload);
        const result = await fastApiClient.sendEmailNotification(
            'http://localhost:8000/send-email-notification',
            mail_payload);

        console.log(result);
      console.log('ServiceNow request via FastAPI successful:', fastApiResponse);
      
    }
    else if (status === 'closed_incomplete' && ticket.automation_data) {
      const updateData = {
        status: "closed",
        work_notes:comments,
        updated_at: new Date().toISOString()
      };


      const { data: updatedTickets, error: updateError } = await supabase
        .from('tickets')
        .update(updateData)
        .eq('id', ticket.id)
        .select();
      console.log(updatedTickets);
      if (updateError) {
        console.error('Error updating ticket:', updateError);
        return res.status(500).json({
          success: false,
          error: 'Database error while updating ticket'
        });
      }
      const { data: updatedWorkflow, error: updateErrors } = await supabase
      .from('workflow_runs')
      .update({
        status: "failed",
        error_message: comments
      })
      .eq('ticket_id', ticket.id)
      .select();
      
      const payloadForFastAPI = {
        sys_id: itsm_reference_sys_id,
        snow_data: {"request_state":"closed_incomplete", "state":4, "close_notes":comments}
      };
      console.log('Calling FastAPI to create ServiceNow request...');
      console.log(updatedWorkflow);
      console.log(updateErrors);
      console.log("################### Payload ############################");
      console.log(payloadForFastAPI)
      console.log("################### Payload ############################");
      
      const fastApiResponse = await fastApiClient.updateServiceNowRequest(
        'http://localhost:8000/update-servicenow-request',
        payloadForFastAPI
      );

      console.log('ServiceNow request via FastAPI successful:', fastApiResponse);
      
    }
    


    console.log(`Ticket ${ticket.ticket_number} (${itsm_reference}) ${status} successfully`);

    return res.status(200).json({
      success: true,
      message: `Ticket ${status} successfully`,
      data: {
        ticket_number: ticket.ticket_number,
        itsm_reference: itsm_reference,
        status: status,
        updated_at: ticket.updated_at,
      }
    });

  } catch (error) {
    console.error('Error in ServiceNow webhook handler:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
}

/**
 * Handles Jira webhook for ticket approval/rejection
 * Similar to ServiceNow but for Jira ticket references
 */
export async function handleJiraWebhook(req, res) {
  try {
    const { itsm_reference, status, comments, approved_by } = req.body;

    // Validate required fields
    if (!itsm_reference || !status) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: itsm_reference and status are required'
      });
    }

    // Validate status
    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid status. Must be "approved" or "rejected"'
      });
    }

    console.log(`Jira webhook received: ${itsm_reference} -> ${status}`);

    // Import Supabase client
    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://riwtnauneyebqhhpfjya.supabase.co';
    const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJpd3RuYXVuZXllYnFoaHBmanlhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA0NDA1NzEsImV4cCI6MjA2NjAxNjU3MX0.xgyciQdfduR6SPBkUt1c6OapY_a8jHDIHzETRZW9U6E';
    
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Find the ticket by ITSM reference
    const { data: tickets, error: findError } = await supabase
      .from('tickets')
      .select('*')
      .eq('itsm_reference', itsm_reference)
      .eq('itsm_type', 'jira');

    if (findError) {
      console.error('Error finding ticket:', findError);
      return res.status(500).json({
        success: false,
        error: 'Database error while finding ticket'
      });
    }

    if (!tickets || tickets.length === 0) {
      return res.status(404).json({
        success: false,
        error: `No ticket found with Jira reference: ${itsm_reference}`
      });
    }

    const ticket = tickets[0];

    // Check if ticket is already processed
    if (ticket.status === 'approved' || ticket.status === 'rejected') {
      return res.status(409).json({
        success: false,
        error: `Ticket ${itsm_reference} is already ${ticket.status}`
      });
    }

    // Update ticket status
    const updateData = {
      status: status,
      updated_at: new Date().toISOString()
    };

    // Add approval metadata if provided
    if (comments || approved_by) {
      const existingAutomationData = ticket.automation_data || {};
      updateData.automation_data = {
        ...existingAutomationData,
        approval_metadata: {
          approved_by: approved_by,
          approval_comments: comments,
          approval_timestamp: new Date().toISOString(),
          approval_source: 'jira_webhook'
        }
      };
    }

    const { data: updatedTickets, error: updateError } = await supabase
      .from('tickets')
      .update(updateData)
      .eq('id', ticket.id)
      .select();

    if (updateError) {
      console.error('Error updating ticket:', updateError);
      return res.status(500).json({
        success: false,
        error: 'Database error while updating ticket'
      });
    }

    const updatedTicket = updatedTickets[0];

    // If approved, create workflow run
    if (status === 'approved' && ticket.automation_data) {
      const automationData = ticket.automation_data;
      
      const { error: workflowError } = await supabase
        .from('workflow_runs')
        .insert([{
          workflow_id: `${automationData.tower}-${automationData.automation_type}-${Date.now()}`,
          workflow_name: automationData.automation_name,
          tower: automationData.tower,
          automation_type: automationData.automation_type,
          status: 'pending',
          form_data: automationData.form_data,
          user_id: ticket.user_id
        }]);

      if (workflowError) {
        console.error('Error creating workflow run:', workflowError);
        // Don't fail the approval, just log the error
      } else {
        console.log(`Workflow run created for approved ticket: ${ticket.ticket_number}`);
      }
    }

    console.log(`Ticket ${ticket.ticket_number} (${itsm_reference}) ${status} successfully`);

    return res.status(200).json({
      success: true,
      message: `Ticket ${status} successfully`,
      data: {
        ticket_number: updatedTicket.ticket_number,
        itsm_reference: itsm_reference,
        status: status,
        updated_at: updatedTicket.updated_at
      }
    });

  } catch (error) {
    console.error('Error in Jira webhook handler:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
}